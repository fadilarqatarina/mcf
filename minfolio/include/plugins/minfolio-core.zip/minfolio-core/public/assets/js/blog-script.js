
(function($) {

	// USE STRICT
	"use strict";    

    const initBlogPostCarousel = function( postCarousel ) {

		const options = { ...$( postCarousel ).data( 'flickity-options' ) };	
        
        $( postCarousel ).on( 'ready.flickity', () => {
            $( postCarousel ).addClass( 'clbr-post-slider-initialized' );
        });
				
        $( postCarousel ).flickity( options );        

	}
   
    $( document ).on( 'ready', function () {

        const postCarousel = $( '.clbr-post-carousel.basic' );                    
                
        postCarousel.each( function() {                    
        	initBlogPostCarousel( this );
        });

		if( $( 'body.single .socials-share-links' ).length > 0 ) {
            $( 'body.single .socials-share-links a' ).socialshare();                                
        }

    });    

})(jQuery);    