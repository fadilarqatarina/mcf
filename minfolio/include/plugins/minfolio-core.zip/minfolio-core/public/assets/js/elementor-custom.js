class ClbrMotionParallaxHandler extends elementorModules.frontend.handlers.Base {

	onInit( ...args ) {

        super.onInit( ...args );      	

		if( this.getElementSettings( 'clbr_parallax_switch' ) ) {
     	   this.initParallax();
		}		

    }

	 onElementChange( propertyName ) {
        
        switch ( propertyName ) {

            case 'clbr_parallax_switch':            
               
				if( this.getElementSettings( 'clbr_parallax_switch' ) ) {
     	   			this.initParallax();
				}
				else {
					this.$element.jarallax( 'destroy' );
				}            
            
	 	}	
        
    }	

	initParallax() {		

		this.$element.jarallax({
            speed: this.getElementSettings[ 'clbr_parallax_bg_speed' ],
			videoSrc: ( this.getElementSettings[ 'background_background' ] === 'video' ) ? this.getElementSettings[ 'background_video_link' ] : '',
        });

	}
	
}

jQuery( window ).on( 'elementor/frontend/init', () => {
	
	elementorFrontend.hooks.addAction( 'frontend/element_ready/section', ( $element ) => {
		elementorFrontend.elementsHandler.addHandler( ClbrMotionParallaxHandler, { $element } );
	});	

	elementorFrontend.hooks.addAction( 'frontend/element_ready/global', ( $element ) => {
			
		if ( window.elementorFrontend ) {

            elementorFrontend.hooks.addFilter( 'frontend/handlers/menu_anchor/scroll_top_distance', function( scrollTop ) {
                return scrollTop - 30;
            });

        }

	});

} );
