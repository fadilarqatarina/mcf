
    class ClbrVideoModalWidgetHandler extends elementorModules.frontend.handlers.Base {

         onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initVideoModalPopup();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-video-modal a'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }

        initVideoModalPopup() {

            this.elements.$container.magnificPopup({
				disableOn: 700,
				type: 'iframe',                         
				mainClass: 'mfp-fade',   
				removalDelay: 160,
				preloader: false,
				fixedContentPos: false,
			});

        }

    }

    class ClbrTestimonialWidgetHandler extends elementorModules.frontend.handlers.Base {

        onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initFlickity();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-testimonial-carousel'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }

        onElementChange( propertyName ) {
        
            switch ( propertyName ) {

                case 'no_of_slides':
                case 'no_of_slides_laptop':
                case 'no_of_slides_tablet':
                case 'no_of_slides_mobile_extra':
                case 'no_of_slides_mobile':
                case 'space_between_slides':        
                case 'space_between_slides_laptop':
                case 'space_between_slides_tablet':
                case 'space_between_slides_mobile_extra':
                case 'space_between_slides_mobile':
                    this.resize();
                    
            }
        
        }	

        initFlickity() {

            const options = { ...this.elements.$container.data( 'flickity-options' ) };	
            
            this.elements.$container.on( 'ready.flickity', () => {
                this.elements.$container.addClass( 'clbr-testimonial-slider-initialized' );
            });
            
            this.elements.$container.flickity( options );     	
        }

        resize() {      

            const flickityObj = Flickity.data( this.elements.$container[0] );            

            if ( ! flickityObj ) {
                return
            }

            flickityObj.$element.flickity( 'resize' );        

        }	

    }

    class ClbrPortfolioSectionWidgetHandler extends elementorModules.frontend.handlers.Base {

        onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initCubePortfolio();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-portfolio-section'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }

        initCubePortfolio() {           
           
            const options = { ...this.elements.$container.data( 'cbp-options' ) };		           

			// Portfolio 
			this.elements.$container.cubeportfolio( options, () => {
				this.initModalPopup( this.elements.$container );								
			});      
			
			this.elements.$container.on( 'lazyLoad.cbp', ( event, el ) => {              
				
				var dataSrcSet = el.getAttribute( 'data-cbp-srcset' );
				var dataSizes  = el.getAttribute( 'data-sizes' );

				if( dataSrcSet != null ) {
					el.srcset = dataSrcSet;
					el.removeAttribute( 'data-cbp-srcset' );                    
				}
				
				if( dataSizes != null ) {
					el.sizes = dataSizes;
					el.removeAttribute( 'data-sizes' );                    
				}
				
			});
			
			this.elements.$container.on( 'onAfterLoadMore.cbp', () => { 

                const loadMoreLink = this.elements.$container.closest( '.cbp-l-loadMore-link' );               
				
				this.initModalPopup( this.elements.$container );
								
				if( loadMoreLink.hasClass( 'cbp-l-loadMore-stop' ) ) {
					loadMoreLink.find( '.cbp-l-loadMore-noMoreLoading' ).html( this.elements.$container.data( 'button-text' ) );                          
				}
				
			}); 

        }

        initModalPopup() {

            this.elements.$container.find( '.lightbox-video, .lightbox-audio' ).magnificPopup({
				disableOn: 700,
				type: 'iframe',                         
				mainClass: 'mfp-fade',   
				removalDelay: 160,
				preloader: false,
				fixedContentPos: false,
			});

        }


    }

    class ClbrPortfolioCarouselWidgetHandler extends elementorModules.frontend.handlers.Base {

         onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initFlickity();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-portfolio-carousel'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }

        onElementChange( propertyName ) {
        
            switch ( propertyName ) {

                case 'carousel_height':
                case 'no_of_slides':
                case 'no_of_slides_laptop':
                case 'no_of_slides_tablet':
                case 'no_of_slides_mobile_extra':
                case 'no_of_slides_mobile':
                case 'space_between_slides':        
                case 'space_between_slides_laptop':
                case 'space_between_slides_tablet':
                case 'space_between_slides_mobile_extra':
                case 'space_between_slides_mobile':
                    this.resize();
                    
            }
        
        }	

        initFlickity() {

            const options = { ...this.elements.$container.data( 'flickity-options' ) };		

            this.elements.$container.on( 'ready.flickity', () => {

                this.elements.$container.addClass( 'clbr-portfolio-carousel-initialized' );

                options.prevNextButtons && this.wrapNavMarkup();    

            });
            
            this.elements.$container.flickity( options );     	
            
        }

        resize() {      

            const flickityObj = Flickity.data( this.elements.$container[0] );            

            if ( ! flickityObj ) {
                return
            }

            flickityObj.$element.flickity( 'resize' );        

        }	

        wrapNavMarkup() {

            const flickityObj = Flickity.data( this.elements.$container[0] );            

            if ( ! flickityObj ) {
                return
            }

            const prevButton = jQuery( flickityObj.prevButton.element );
            const nextButton = jQuery( flickityObj.nextButton.element );                

            const prevSVG = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 476.213 476.213" style="enable-background:new 0 0 476.213 476.213;" xml:space="preserve">
								<polygon points="345.606,107.5 324.394,128.713 418.787,223.107 0,223.107 0,253.107 418.787,253.107 324.394,347.5 345.606,368.713 476.213,238.106 "></polygon>
							</svg>`;

            const nextSVG = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 476.213 476.213" style="enable-background:new 0 0 476.213 476.213;" xml:space="preserve">
								<polygon points="345.606,107.5 324.394,128.713 418.787,223.107 0,223.107 0,253.107 418.787,253.107 324.394,347.5 345.606,368.713 476.213,238.106 "></polygon>
							</svg>`;


            prevButton.children().replaceWith( prevSVG );
            nextButton.children().replaceWith( nextSVG );
               
            const navBtnWrap = jQuery( '<div class="flickity-button-wrap wrap"></div>' );
            navBtnWrap.append( prevButton.add( nextButton ) );                    

            navBtnWrap.appendTo( this.elements.$container );                      

        }

    }

    class ClbrHeroSliderWidgetHandler extends elementorModules.frontend.handlers.Base {

         onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initFlickity();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-hero-slider'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }      

        initFlickity() {

            const options = { ...this.elements.$container.data( 'flickity-options' ) };		

            this.elements.$container.on( 'ready.flickity', () => {

                this.elements.$container.addClass( 'clbr-hero-slider-initialized' );

                if( this.elements.$container.data( 'parallax' ) === 'yes' ) {

					const heroSlides = this.elements.$container.find( '.carousel-cell' );	
                    const parallaxSpeed = this.elements.$container.data( 'parallax-speed' );				

					heroSlides.each(function() {

						console.log(this);

						$( this ).jarallax({
							speed: parallaxSpeed
						})

					});					

				}

            });
            
            this.elements.$container.flickity( options );     	
        }
        
    }

    class ClbrGoogleMapWidgetHandler extends elementorModules.frontend.handlers.Base {

        onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initGoogleMap();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-google-map'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }

        initGoogleMap() {

            const map_type = this.elements.$container.data( 'map-type' );              
                                
            if ( map_type === 'basic' ) {
                this.createBasicMap();
            }             

            if ( map_type === 'marker' ) {
                this.createMarkerMap();
            } 

        }    

        createBasicMap() {

            const map_id = this.elements.$container.data( 'id' ),                                    
                map_lat = this.elements.$container.data( 'map-lat' ) || 51.503324,
                map_lng = this.elements.$container.data( 'map-lng' ) || -0.119543,              
                map_basic_marker_title = this.elements.$container.data( 'map-basic-marker-title' ),
                map_basic_marker_content = this.elements.$container.data( 'map-basic-marker-content' ),
                map_basic_marker_icon_enable = this.elements.$container.data( 'map-basic-marker-icon-enable' ),
                map_basic_marker_icon = this.elements.$container.data( 'map-basic-marker-icon' ),
                map_basic_marker_icon_width = this.elements.$container.data( 'map-basic-marker-icon-width' ),
                map_basic_marker_icon_height = this.elements.$container.data( 'map-basic-marker-icon-height' ),
                map_zoom = this.elements.$container.data( 'map-zoom' ) || 14,                
                map_theme = JSON.parse( decodeURIComponent( ( this.elements.$container.data( 'map-theme' ) + '').replace(/\+/g, "%20") ) ),
                map_streeview_control = this.elements.$container.data( 'map-streeview-control' ),
                map_type_control = this.elements.$container.data( 'map-type-control' ),
                map_zoom_control = this.elements.$container.data( 'map-zoom-control' ),
                map_fullscreen_control = this.elements.$container.data( 'map-fullscreen-control' ),
                map_scroll_zoom = this.elements.$container.data( 'map-scroll-zoom' );

            let gMaps = null;                

            gMaps = new GMaps({
                el: '#clbr-google-map-' + map_id,
                lat: map_lat,
                lng: map_lng,
                zoom: map_zoom,
                streetViewControl: map_streeview_control,
                mapTypeControl: map_type_control,
                zoomControl: map_zoom_control,
                fullscreenControl: map_fullscreen_control,
                scrollwheel: map_scroll_zoom
            });

            if( map_theme !== '' ) {

                gMaps.addStyle({
                    styledMapName: 'Styled Map',
                    styles: JSON.parse( map_theme ),
                    mapTypeId: 'map_style'
                });
    
                gMaps.setStyle( 'map_style' );
            }

            let marker_content = null;
            let marker_icon = null;

            if( map_basic_marker_content !== '' ) {
                marker_content = {
                    content: map_basic_marker_content
                }
            }

            if ( map_basic_marker_icon_enable == 'yes' ) {                            

                if( map_basic_marker_icon !== '' ) {

                    marker_icon = {
                        url: map_basic_marker_icon,
                        scaledSize: new google.maps.Size( map_basic_marker_icon_width, map_basic_marker_icon_height )
                    }
                }
            }

            gMaps.addMarker({
                lat: map_lat,
                lng: map_lng,
                title: map_basic_marker_title,
                infoWindow: marker_content,
                icon: marker_icon
            });                   

        }
        
        createMarkerMap() {

            const map_id = this.elements.$container.data( 'id' ),                                
                map_zoom = this.elements.$container.data( 'map-zoom' ) || 14,
                map_markers = this.elements.$container.data( 'map-markers' ),               
                map_theme = JSON.parse( decodeURIComponent( ( this.elements.$container.data( 'map-theme' ) + '').replace(/\+/g, "%20") ) ),
                map_streeview_control = this.elements.$container.data( 'map-streeview-control' ),
                map_type_control = this.elements.$container.data( 'map-type-control' ),
                map_zoom_control = this.elements.$container.data( 'map-zoom-control' ),
                map_fullscreen_control = this.elements.$container.data( 'map-fullscreen-control' ),
                map_scroll_zoom = this.elements.$container.data( 'map-scroll-zoom' );

            const markers_list = JSON.parse( decodeURIComponent( ( map_markers + "" ).replace(/\+/g, "%20") ) );

            let gMaps = null;

            if ( markers_list.length > 0 ) {

                gMaps = new GMaps({
                    el: '#clbr-google-map-' + map_id,
                    lat: markers_list[0].map_marker_lat,
                    lng: markers_list[0].map_marker_lng,
                    zoom: map_zoom,
                    streetViewControl: map_streeview_control,
                    mapTypeControl: map_type_control,
                    zoomControl: map_zoom_control,
                    fullscreenControl: map_fullscreen_control,
                    scrollwheel: map_scroll_zoom
                });                      

                gMaps.setCenter( markers_list[0].map_marker_lat, markers_list[0].map_marker_lng );

                if( map_theme !== '' ) {

                    gMaps.addStyle({
                        styledMapName: 'Styled Map',
                        styles: JSON.parse( map_theme ),
                        mapTypeId: 'map_style'
                    });
        
                    gMaps.setStyle( 'map_style' );
                }

                markers_list.forEach(( item ) => {

                    let marker_content = null;
                    let marker_icon = null;
        
                    if( item.map_marker_content !== '' ) {
                        marker_content = {
                            content: item.map_marker_content
                        }
                    }
        
                    if ( item.map_marker_icon_enable === 'yes' ) {                            
        
                        if( item.map_marker_icon !== '' ) {
        
                            marker_icon = {
                                url: item.map_marker_icon[ 'url' ],
                                scaledSize: new google.maps.Size( item.map_marker_icon_width, item.map_marker_icon_height )
                            }
                        }
        
                    }        

                    gMaps.addMarker({
                        lat: parseFloat( item.map_marker_lat ),
                        lng: parseFloat( item.map_marker_lng ),
                        title: item.map_marker_title,
                        infoWindow: marker_content,
                        icon: marker_icon
                    })

                })

            }

        }

      


    }

    class ClbrCounterWidgetHandler extends elementorModules.frontend.handlers.Base {

        onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initCounter();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-counter-number'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container )
            };
        }

        initCounter() {           

            elementorFrontend.waypoint( this.elements.$container, () => {           
            
                const decimalDigits = this.elements.$container.data( 'to-value' ).toString().match( /\.(.*)/ );
                const rounding = 0;

                if ( decimalDigits ) {
                    rounding = decimalDigits[ 1 ].length;
                }

                const options = {
                    'duration' :  this.elements.$container.data( 'duration' ),
                    'toValue' : this.elements.$container.data( 'to-value' ),
                    'fromValue' : this.elements.$container.data( 'from-value' ),
                    'delimiter' : this.elements.$container.data( 'delimiter' ),
                    'rounding' : rounding
                };           

                this.elements.$container.numerator( options );

            });
         
        }

    }

    class ClbrStampWidgetHandler extends elementorModules.frontend.handlers.Base {

        onInit( ...args ) {

            super.onInit( ...args );

            if ( ! this.elements.$container.length ) {
                return;
            }

            this.initRotateStampText();
            this.initStamp();
        }

        getDefaultSettings() {
            return {
                selectors: {
                    container: '.clbr-stamp',
                    stamp: '.clbr-stamp-text'
                },
            };
        }

        getDefaultElements() {
            const selectors = this.getSettings( 'selectors' );

            return {
                $container: this.$element.find( selectors.container ),
                $stamp: this.$element.find( selectors.stamp )
            };
        }

        initRotateStampText() {

            const count = parseInt( this.elements.$stamp.data( 'count' ), 10 );

            this.elements.$stamp.children().each( function( i ) {                

				const transform = -90 + i * 360 / count;
				const transitionDelay = i * 60 / count * 10;	               
					
				jQuery( this ).css( {'transform': 'rotate(' + transform + 'deg) translateZ(0)', 'transition-delay': transitionDelay + 'ms'} );

			});

        }

        appearAnimation() {

            this.elements.$container.addClass( 'clbr-appear' );			
			
            setTimeout(() => {
			    this.elements.$container.addClass( 'clbr-init' );
			}, 300 );					
			
            setTimeout(() => {
				this.elements.$container.addClass( 'clbr-animate-stamp' );
			}, 1000 );

        }

        initStamp() {

            elementorFrontend.waypoint( this.elements.$container, () => {

                setTimeout(() => {

                    this.elements.$container.addClass( 'clbr-stamp-appeared' );
					this.appearAnimation();
                    
                }, this.elements.$container.data( 'appearing-delay' ) );				

			});

        }


    }


    jQuery( window ).on( 'elementor/frontend/init', () => {         

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-video-modal-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrVideoModalWidgetHandler, { $element } );
        });

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-testimonial-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrTestimonialWidgetHandler, { $element } );
        });

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-portfolio-section-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrPortfolioSectionWidgetHandler, { $element } );
        });

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-portfolio-carousel-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrPortfolioCarouselWidgetHandler, { $element } );
        });

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-hero-slider-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrHeroSliderWidgetHandler, { $element } );
        });

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-google-map-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrGoogleMapWidgetHandler, { $element } );
        });

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-counter-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrCounterWidgetHandler, { $element } );
        });     

        elementorFrontend.hooks.addAction( 'frontend/element_ready/clbr-stamp-widget.default', ( $element ) => {            
            elementorFrontend.elementsHandler.addHandler( ClbrStampWidgetHandler, { $element } );
        });     

    });

