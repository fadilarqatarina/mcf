var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Extra","value":880,"default_value":880,"direction":"max","is_enabled":true},"tablet":{"label":"Tablet","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Extra","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.11.3","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"additional_custom_breakpoints":true,"e_swiper_latest":true,"landing-pages":true,"kit-elements-defaults":true},"urls":{"assets":minfolioVar.homeUrl + "\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_mobile_extra","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":1423,"title":"Our%20Portfolio%20%E2%80%93%20minfolio%20Agency%20Test","excerpt":"","featuredImage":false},"user":{"roles":["administrator"]}};

(function($) {

	// USE STRICT
	"use strict";    

    const initModalPopup = function( portfolioSectionEl ) {

        $( portfolioSectionEl ).find( '.lightbox-video, .lightbox-audio' ).magnificPopup({
			disableOn: 700,
			type: 'iframe',                         
			mainClass: 'mfp-fade',   
			removalDelay: 160,
			preloader: false,
			fixedContentPos: false,
		});

    }

    const initPortfolioSection = function( portfolioSectionEl ) {
        
        const portfolioSection = $( portfolioSectionEl );

        const options = { ...portfolioSection.data( 'cbp-options' ) };		
		
		// Portfolio 
		portfolioSection.cubeportfolio( options, function() { 						
			initModalPopup( portfolioSection );								
		});      
			
		portfolioSection.on( 'lazyLoad.cbp', function( event, el ) {   
				
			const dataSrcSet = el.getAttribute( 'data-cbp-srcset' );
			const dataSizes  = el.getAttribute( 'data-sizes' );

			if( dataSrcSet != null ) {
				el.srcset = dataSrcSet;
				el.removeAttribute( 'data-cbp-srcset' );                    
			}
				
			if( dataSizes != null ) {
				el.sizes = dataSizes;
				el.removeAttribute( 'data-sizes' );                    
			}
				
		});					
		       
    };

	const portfolioSingleMediaSlider = function( mediaSliderContainer ) {

        const options = { ...$( mediaSliderContainer ).data( 'flickity-options' ) };		

        $( mediaSliderContainer ).on( 'ready.flickity', () => {
            $( mediaSliderContainer ).addClass( 'clbr-media-slider-initialized' );
        });
            
        $( mediaSliderContainer ).flickity( options );     	
                               
    };     

    const portfolioSingleHeroSlider = function( heroSliderContainer ) {

        const options = { ...$( heroSliderContainer ).data( 'flickity-options' ) };	
        
        $( heroSliderContainer ).on( 'ready.flickity', () => {
            $( heroSliderContainer ).addClass( 'clbr-hero-slider-initialized' );
        });
            
        $( heroSliderContainer ).flickity( options );                      
                                   
    };     

    const portfolioSingleHeroMultipleSlider = function( heroMultipleSliderContainer ) {

        const options = { ...$( heroMultipleSliderContainer ).data( 'flickity-options' ) };	

        $( heroMultipleSliderContainer ).on( 'ready.flickity', () => {
            $( heroMultipleSliderContainer ).addClass( 'clbr-hero-multiple-slider-initialized' );
        });
            
        $( heroMultipleSliderContainer ).flickity( options );                  
                                
    };     

    const relatedPortfolioCarousel = function( relatedPortfolioCarouselContainer ) {

        const options = { ...$( relatedPortfolioCarouselContainer ).data( 'flickity-options' ) };	

        $( relatedPortfolioCarouselContainer ).on( 'ready.flickity', () => {
            $( relatedPortfolioCarouselContainer ).addClass( 'clbr-portfolio-carousel-initialized' );
            initModalPopup( relatedPortfolioCarouselContainer );	
        });
            
        $( relatedPortfolioCarouselContainer ).flickity( options );              
        
    };


    const initImageGalleryGrid = function( imageGalleryGridEl ) {

        const imageGalleryGrid = $( imageGalleryGridEl );
        const options = { ...imageGalleryGrid.data( 'cbp-options' ) };		       
		
		// Gallery 
		imageGalleryGrid.cubeportfolio( options );      
			
		imageGalleryGrid.on( 'lazyLoad.cbp', function( event, el ) {   
				
			const dataSrcSet = el.getAttribute( 'data-cbp-srcset' );
			const dataSizes  = el.getAttribute( 'data-sizes' );

			if( dataSrcSet != null ) {
				el.srcset = dataSrcSet;
				el.removeAttribute( 'data-cbp-srcset' );                    
			}
				
			if( dataSizes != null ) {
				el.sizes = dataSizes;
				el.removeAttribute( 'data-sizes' );                    
			}
				
		});					
		       
    };

    const stickySidebar = function() {                             
                    
        const top_offset = 65;
                
        $( '.single-portfolio .right-sidebar .entry-meta' ).stick_in_parent({              
            offset_top: top_offset
        });        

    };

    const imageComparison = function() {        
                
        const imageComparisonEl = $( '.cocoen.image-comparison' );                   
        
        imageComparisonEl.each( function() {                      
            new Cocoen( this );
        });       
    
    };  
 	
   
    $( document ).on( 'ready', function () {

        const portfolioArchiveSectionContainers = $( '.clbr-portfolio-archive' );                                   
             
        portfolioArchiveSectionContainers.each( function() {            
            initPortfolioSection( this );             
        });    

        const portfolioRelatedSectionContainers = $( '.clbr-related-portfolio-grid' );                                   
             
        portfolioRelatedSectionContainers.each( function() {            
            initPortfolioSection( this );             
        });    
		
		const portfolioSingleImageGalleryContainers = $( '[id^=portfolio-container]' );                                   
             
        portfolioSingleImageGalleryContainers.each( function() {
            
            initImageGalleryGrid( this ); 
            
        });   
        
        const portfolioSingleMediaSliderContainers = $( '.portfolio-media.slider' );

        portfolioSingleMediaSliderContainers.each( function() {

            portfolioSingleMediaSlider( this );

        });  

        const portfolioSingleHeroSliderContainers = $( '.portfolio-hero.single-slider' );

        portfolioSingleHeroSliderContainers.each( function() {

            portfolioSingleHeroSlider( this );

        });  

        var portfolioSingleHeroMultipleSliderContainers = $( '.portfolio-hero.multiple-slider' );

        portfolioSingleHeroMultipleSliderContainers.each( function() {

            portfolioSingleHeroMultipleSlider( this );

        });  

        var relatedPortfolioCarouselContainer = $( '#portfolio-carousel-related' );

        relatedPortfolioCarouselContainer.each( function() {

            relatedPortfolioCarousel( this );

        });  

        if ( $( '.single-portfolio .right-sidebar.sticky-details' ).length ) { 
            stickySidebar();
        }

        if( $( 'body' ).hasClass( 'single-portfolio' ) && $( '.portfolio-social-share-links' ).length > 0 ) {   

            $( '.portfolio-social-share-links a' ).socialshare();                        

        }

        if ( $( '.portfolio-media.image-comparison' ).length ) { 

            imageComparison();
        }

        if ( $( '.portfolio-hero.image-comparison' ).length ) { 

            imageComparison();
        }    

    });    

})(jQuery);    