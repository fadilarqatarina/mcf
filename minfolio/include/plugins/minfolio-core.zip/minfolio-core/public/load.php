<?php 

    if( ! is_admin() ) {		
            
        require_once( MINFOLIO_CORE_PATH . 'public/portfolio/portfolio-functions.php' );      

    }

?>