<?php 
/**
 * Template part for displaying portfolio archive banner
 * 
 */
?>

<?php 
		
	$background_style = array();	
	$overlay_style = array();	

	$portfolio_archive_banner_image = minfolio_get_core_option( 'portfolio-archive-banner-image' );	
	$portfolio_archive_banner_overlay_color = minfolio_get_core_option( 'portfolio-archive-banner-overlay-color' );	
	
	if( $portfolio_archive_banner_image ) {
		$background_style[ 'background-image' ] = 'url("' . $portfolio_archive_banner_image . '")';			
		$overlay_style[ 'background' ]    = $portfolio_archive_banner_overlay_color;		
	}
	else {
		$portfolio_archive_banner_color = minfolio_get_core_option( 'portfolio-archive-banner-bg-color' );	
		$background_style[ 'background-color' ] = $portfolio_archive_banner_color;		
	}	

?>

	<header class="portfolio-archive-banner" <?php echo minfolio_build_inline_style( $background_style ); ?> >

		<div class="color-overlay" <?php echo minfolio_build_inline_style( $overlay_style ); ?> ></div>		

		<div class="portfolio-archive-banner-content-wrap wrap">
			<div class="portfolio-archive-banner-content">
					
				<?php if ( is_archive() ) {					
					
					the_archive_title( '<h1 class="banner-title">', '</h1>' );
					the_archive_description( '<div class="description">', '</div>' );	
							
				} ?>

			</div>
		</div>
			
	</header>

