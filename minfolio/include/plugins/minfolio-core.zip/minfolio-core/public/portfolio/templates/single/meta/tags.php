<?php

    $show_tags = minfolio_get_post_meta( 'portfolio_meta_show_tags' );			
    $portfolio_tags = wp_get_post_terms( get_the_ID(), 'portfolio_tag' );	

        
    if ( $show_tags && !empty( $portfolio_tags ) ) { ?>
        
        <li>
        
            <span><?php echo esc_html__( 'Tags', 'minfolio' ); ?></span>
        
            <span class="portfolio-tags">
        
                <?php foreach ( $portfolio_tags as $key => $value ) { ?>
            
                    <a href="<?php echo get_term_link( $value->slug, 'portfolio_tag' ); ?>">            
                        <?php echo $value->name; ?>            
                    </a>

                <?php } ?>
        
            </span>
        
        </li>

    <?php } ?>