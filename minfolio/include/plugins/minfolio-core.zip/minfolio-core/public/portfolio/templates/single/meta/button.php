<?php

    $button_section_switch  = minfolio_get_post_meta( 'button_section_switch' );	
	$button_text			= minfolio_get_post_meta( 'button_text' );	
	$button_style			= minfolio_get_post_meta( 'button_style' );	
	$button_url				= minfolio_get_post_meta( 'button_url' );
	$button_target			= minfolio_get_post_meta( 'button_target' );

	$button_markup = '';		
	
	if( $button_section_switch == '1' && $button_text ) { ?>			
		
		<div class="meta-button">
			<a href="<?php echo esc_url( $button_url ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>" 
                class="button <?php echo esc_attr( $button_style ); ?>" target="<?php echo esc_attr( $button_target ); ?>" >
                <?php echo esc_attr( $button_text ); ?>
            </a>
		</div>

	<?php }				
