<?php
/**
 * Template part for displaying portfolio details lightbox layout
 * 
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
	
	<header class="entry-header">	
		
		<?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/title' ); ?>
		
	</header><!-- .entry-header -->		
	
	
	<div class="entry-content">
		
		<?php 
		
			echo minfolio_get_cpt_portfolio_template_part( 'templates/single/media/lightbox/media-wrapper-lightbox' );
			
			the_content();
			
		?>
		
	</div><!-- .entry-content -->
	
</article><!-- #post-## -->
