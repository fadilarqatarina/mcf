<?php

    $video_upload_entries	= !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_video_upload' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_video_upload' ]  : '';			
	$show_video_caption = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_image_show_caption' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_image_show_caption' ]  : '0';
		
	if( !empty( $video_upload_entries ) ) { 

	    foreach ( $video_upload_entries as $video_entry ) { ?>

			<div class="portfolio-media video-upload">		
							
			    <?php echo wp_video_shortcode( array( 'src' => wp_get_attachment_url( $video_entry ), 'height' => 360, 'width' => 640 ) ); ?>
								
				<?php if ( $show_video_caption ) { ?>

					<div class="video-meta-details">	
						<p><?php echo minfolio_get_portfolio_image_caption( $video_entry ); ?></p>
					</div>

				<?php } ?>
				
		    </div>

		<?php } ?>

	<?php } ?>