<?php 

    $nav_next_text = minfolio_get_core_option( 'portfolio-next-text' );
    $multilingual_switch = minfolio_get_core_option( 'multilingual-switch' );

    if( get_adjacent_post( false, '', false ) ) { 

        if( $multilingual_switch == 1 ) {
            $next = get_next_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Next Portfolio', 'minfolio' ) . '</span><span>' . esc_html__( 'Next', 'minfolio' ) . '<img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Next', 'minfolio' ) . '" /></span>' );
        }
        else {
            $next = get_next_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Next Portfolio', 'minfolio' ) . '</span><span>' . $nav_next_text . '<img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Next', 'minfolio' ) . '" /></span>' );
        }
    ?>

    <li class="portfolio-next">
        <?php echo $next; ?>
    </li>

    <?php }	else {

    $last = new WP_Query( 'post_type=portfolio&posts_per_page=1&order=ASC' ); 
    $last->the_post();
    ?>

    <li class="portfolio-next">
        <a href="<?php echo esc_url( get_permalink() ); ?>" rel="next" >
            <span class="screen-reader-text"><?php echo esc_html__( 'Next Portfolio', 'minfolio' ); ?></span>
            <span>

                <?php echo ( $multilingual_switch == 1 ) ? esc_html__( 'Next', 'minfolio' ) : $nav_next_text; ?>                 

                <img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg'; ?>" alt="<?php echo esc_html__( 'Next', 'minfolio' ); ?>" />                        

            </span>
        </a>
    </li>

<?php }	?>