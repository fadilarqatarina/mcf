<?php 

    $hero_rev_slider  = minfolio_get_post_meta( 'hero_rev_slider' );		
		
	if( $hero_rev_slider != 'NO_SLIDER' ) {
		echo do_shortcode( '[rev_slider alias="' . esc_attr( $hero_rev_slider ) . '" ]' );
	}

?>