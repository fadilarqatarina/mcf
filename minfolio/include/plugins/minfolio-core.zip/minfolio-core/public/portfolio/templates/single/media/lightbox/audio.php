<?php

    $audio_url = minfolio_get_post_meta( 'lightbox_audio_url' );
    $audio_url = 'https://w.soundcloud.com/player/?url='.$audio_url.'&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true';		

    if( !empty( $audio_url ) ) { ?>

        <div class="portfolio-media embed-responsive embed-responsive-16by9">
            <?php echo wp_oembed_get( esc_url( $audio_url ) ); ?>
        </div>        

    <?php } ?>