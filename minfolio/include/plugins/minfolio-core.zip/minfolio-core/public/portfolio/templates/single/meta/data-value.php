<?php

    $meta_section_switch = minfolio_get_post_meta( 'meta_details_reqd' );	
		
	if( !post_password_required() && $meta_section_switch == 1 ) {
		
		$meta_entries = minfolio_get_post_meta( 'portfolio_groupbox' );		
    ?>

		<div class="meta-entries">
			
			<ul>
				
                <?php if( $meta_entries ) {		

                    foreach ( $meta_entries as $meta_entry ) {				

                        $title	= !empty( $meta_entry[ MINFOLIO_META_PREFIX . 'new_title' ] )  ? $meta_entry[ MINFOLIO_META_PREFIX . 'new_title' ]  : '';						
                        $value	= !empty( $meta_entry[ MINFOLIO_META_PREFIX . 'new_value' ] )  ? $meta_entry[ MINFOLIO_META_PREFIX . 'new_value' ]  : '';			

                        if ( $title != '' ) { ?>

                            <li>
                                <span><?php echo esc_html( $title ); ?></span>
                                <?php echo wp_kses_post( $value ); ?>
                            </li>

                        <?php }

                    }						
                } 	
                              
                echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/categories' );                        
             
                echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/tags' );
                    
                echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/social-share' );     

                ?>
				
			</ul>

            <?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/button' ); ?>
				
		</div>

    <?php } ?>