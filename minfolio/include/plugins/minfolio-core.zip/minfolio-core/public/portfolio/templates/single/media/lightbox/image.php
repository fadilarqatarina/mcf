<?php

	$image_array = minfolio_get_post_meta( 'lightbox_image_url', true );			

	if( !empty( $image_array ) ) {
		
		foreach ( $image_array as $image ) { ?>
			
			<div class="portfolio-media">
				<?php echo wp_get_attachment_image( $image, 'full' ); ?>
			</div>
		
		<?php }		
	}
?>