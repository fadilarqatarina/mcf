<?php

	$nav_prev_text = minfolio_get_core_option( 'portfolio-prev-text' );
	$multilingual_switch = minfolio_get_core_option( 'multilingual-switch' );

	if( get_adjacent_post( false, '', true ) ) {

		if( $multilingual_switch == 1 ) {	
			$prev = get_previous_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Previous Portfolio', 'minfolio' ) . '</span><span><img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Previous', 'minfolio' ) . '" />' . esc_html__( 'Prev', 'minfolio' ) . '</span>' );
		}
		else {
			$prev = get_previous_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Previous Portfolio', 'minfolio' ) . '</span><span><img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Previous', 'minfolio' ) . '" />' . $nav_prev_text . '</span>' );
		}

	?>	
		<li class="portfolio-prev">
			<?php echo $prev; ?>
		</li>

	<?php } else {

		$first = new WP_Query( 'post_type=portfolio&posts_per_page=1&order=DESC' ); 		
		$first->the_post();    	

	?>

		<li class="portfolio-prev">
			<a href="<?php echo esc_url( get_permalink() ); ?>" rel="prev" >

				<span class="screen-reader-text">
					<?php echo esc_html__( 'Previous Portfolio', 'minfolio' ); ?>
				</span>
				<span>

					<img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg'; ?>" alt="<?php echo esc_html__( 'Previous', 'minfolio' ); ?>" />                        

					<?php echo ( $multilingual_switch == 1 ) ? esc_html__( 'Prev', 'minfolio' ) : $nav_prev_text; ?>                 
					
				</span>

			</a>
		</li>

	    <?php wp_reset_postdata();

	} ?>