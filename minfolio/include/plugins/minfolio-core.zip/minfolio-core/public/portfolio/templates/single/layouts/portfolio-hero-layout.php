<?php
/**
 * Template part for displaying portfolio hero content
 *
 */

?>

<?php 

	$hero_section_type	= minfolio_get_post_meta( 'hero_section_type' );	
	$page_hero_section_switch = minfolio_get_post_meta( 'hero_section_switch' );
	
	$page_builder_section_placement = minfolio_get_post_meta( 'page_builder_section_placement' );

	if( !post_password_required() && $page_hero_section_switch == 1 ) { ?>	

		<div class="portfolio-hero-section-wrap" >
			<div class="portfolio-hero-section">

			    <?php 			

					echo minfolio_get_cpt_portfolio_template_part( 'templates/single/hero/hero', $hero_section_type ); 

					if( $page_builder_section_placement == 'below-hero-section' && $hero_section_type != 'custom' ) {				 
						the_content();
					}			
					
				?>	

			</div>			
		</div>

<?php } ?>
