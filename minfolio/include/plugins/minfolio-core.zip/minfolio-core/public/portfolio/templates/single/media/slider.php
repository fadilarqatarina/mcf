<?php 

	wp_enqueue_script( 'flickity' );	
	
	$params = [];
	$slider_images   = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ]  : '';
	
	$params[ 'pagination' ] = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_slider_pagination' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_slider_pagination' ]  : '0';
	$params[ 'navigation' ] = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_slider_navigation' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_slider_navigation' ]  : '0';		
		
		
    if( $slider_images ) {	?>
			
		<div class="clbr-slider-wrap">
			
			<div class="portfolio-media slider" <?php echo minfolio_build_data_attr( minfolio_get_media_slider_data_attributes( $params ) ); ?> >	

				<?php foreach ( $slider_images as $slide_image ) {	?>

					<div class="carousel-cell">

						<?php echo wp_get_attachment_image( $slide_image, 'full' ); ?>      

					</div>

				<?php } ?>			
				
			</div>			

		</div>
		
	<?php } ?>
