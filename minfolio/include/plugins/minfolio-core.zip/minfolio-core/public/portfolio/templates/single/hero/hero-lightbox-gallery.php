<?php

    wp_enqueue_script( 'cubeportfolio' );	    

    do_action( 'minfolio_enqueue_portfolio_scripts' );  

    $gallery_images =  minfolio_get_post_meta( 'hero_gallery_images', true );
    $params = [];
            
    $params[ 'gallery_columns' ]  =  minfolio_get_post_meta( 'hero_image_gallery_cols' );	
    $params[ 'gallery_layout' ]   =  minfolio_get_post_meta( 'hero_media_layout' );
    $params[ 'gap_horizontal' ]   =  minfolio_get_post_meta( 'hero_gap_horizontal' );
    $params[ 'gap_vertical' ]     =  minfolio_get_post_meta( 'hero_gap_vertical' );		
            
       
    if( $gallery_images ) { ?>

        <div id="portfolio-container-hero-gallery" class="portfolio-hero cbp" <?php echo minfolio_build_data_attr( minfolio_get_gallery_data_attributes( $params ) ); ?> >                                     
                            
            <?php foreach ( $gallery_images as $grid_image ) { ?>          
         
            <div class="cbp-item">
                <a class="cbp-hero-lightbox cbp-caption" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="slide-show-hero" href="<?php echo esc_url( wp_get_attachment_url( $grid_image ) ); ?>" >
                    <div class="cbp-caption-defaultWrap">	
                        <?php echo minfolio_get_cpt_attachment_image( $grid_image, 'full' ); ?>
                    </div>
                    <div class="cbp-caption-activeWrap">
                        <div class="cbp-l-caption-alignCenter">
                            <div class="cbp-l-caption-body">
                                <div class="cbp-l-caption-title">
                                    <img src="<?php echo get_theme_file_uri( '/assets/images/svg/plus.svg' ); ?>" class="lightbox-plus" alt="<?php echo esc_attr( 'Lightbox Plus', 'minfolio' ); ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

        <?php } ?>
            
        </div>

<?php }	?>
