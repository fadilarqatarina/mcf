<?php

	wp_enqueue_script( 'cocoen' );
  
	$compare_images   = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ]  : '';
		
    if( $compare_images ) {					
		
	    for ( $index = 0; $index < count( $compare_images ); $index++ ) { ?>
			
			<div class="portfolio-media cocoen image-comparison">

			    <?php 
                
                    echo wp_get_attachment_image( $compare_images[ $index ], 'full' );
				
				    $index++;
				
				    if( $index >= count( $compare_images ) ) { ?>
					
					</div>
					
				    <?php break;

				    } ?>
				 
				<?php echo wp_get_attachment_image( $compare_images[ $index ], 'full' ); ?>

			</div>

        <?php }			
		
	}