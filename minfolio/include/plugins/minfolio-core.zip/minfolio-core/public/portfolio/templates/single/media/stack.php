<?php

    wp_enqueue_script( 'cubeportfolio' );

    $gallery_stack_images = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ]  : '';	
    $params = [];
	
	$params[ 'gallery_columns' ]  =  1;
    $params[ 'gallery_layout' ]   =  'grid';
    $params[ 'gap_horizontal' ]   =  !empty( $media_entry[ MINFOLIO_META_PREFIX . 'gap_horizontal' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'gap_horizontal' ]  : 0;
    $params[ 'gap_vertical' ]     =  !empty( $media_entry[ MINFOLIO_META_PREFIX . 'gap_vertical' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'gap_vertical' ]  : 0;
			
            
    $gap_horizontal = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'gap_horizontal' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'gap_horizontal' ]  : '30';
    $gap_vertical   = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'gap_vertical' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'gap_vertical' ]  : '30';
            
    $show_image_caption = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_image_show_caption' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_image_show_caption' ]  : '0';
            

    if( $gallery_stack_images ) { ?>

        <div class="clbr-portfolio-wrap portfolio-media stack-images">

            <div id="portfolio-container-media<?php echo esc_attr( $index ); ?>" class="cbp" <?php echo minfolio_build_data_attr( minfolio_get_gallery_data_attributes( $params ) ); ?> >
                                    
                        
            <?php foreach ( $gallery_stack_images as $grid_image ) { ?>

                <div class="cbp-item">
                    <div class="cbp-caption-defaultWrap">
                        <?php echo minfolio_get_cpt_attachment_image( $grid_image, 'full' );	?>  
                    </div>

                   	<?php if ( $show_image_caption ) { ?>

						<div class="image-meta-details">	
							<p><?php echo minfolio_get_portfolio_image_caption( $grid_image ); ?></p>
						</div>

					<?php } ?>
                     
                </div>

            <?php } ?>
                
            </div>

        </div>

    <?php }	?>

