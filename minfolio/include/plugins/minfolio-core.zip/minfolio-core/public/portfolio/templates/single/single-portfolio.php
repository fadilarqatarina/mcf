<?php
/**
 * The template for displaying all single portfolio
 *
 */

get_header(); 

wp_enqueue_script( 'minfolio-portfolio-script' );

echo minfolio_get_cpt_portfolio_template_part( 'templates/single/layouts/portfolio-hero-layout' ); 

?>

<div id="content" class="site-content">

	<div class="wrap">
	
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">
			
				<?php
				/* Start the Loop */
				while ( have_posts() ) {			
					
					the_post();			
					
					echo minfolio_get_cpt_portfolio_template_part( 'templates/single/layouts/portfolio-main-layout' ); 									

				} // End of the loop.
				?>

			</main><!-- #main -->
		</div><!-- #primary -->
		
	</div><!-- .wrap -->

</div>

<?php get_footer(); ?>
