<?php   
   
    $hero_video_url = minfolio_get_post_meta( 'hero_video_url' );

    $hero_section_style = array();
    $hero_full_height_class = '';

    $hero_section_height = minfolio_get_post_meta( 'hero_section_height' );	

    if( $hero_section_height == 'custom' ) {

        $hero_custom_height = minfolio_get_post_meta( 'hero_custom_height' );

        $hero_section_style[ 'height' ] = $hero_custom_height;	
    }
    else {
        $hero_full_height_class = 'hero-full-height';
    }			
    

    if( !empty( $hero_video_url ) ) { ?>				
        <div id="hero-background-video"  class="elementor-section portfolio-hero bg-video <?php echo esc_attr( $hero_full_height_class ); ?>"  <?php echo minfolio_build_inline_style( $hero_section_style ); ?> data-settings="{"background_background":"video","background_video_link":"https:\/\/www.youtube.com\/watch?v=EzSWC-mXCGw","background_play_once":"yes","background_play_on_mobile":"yes","background_privacy_mode":"yes"}" >           

           <div class="elementor-background-video-container">
				<div class="elementor-background-video-embed"></div>
			</div>

        </div>
    <?php }	?>