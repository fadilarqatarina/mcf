<li>
    <a href="<?php echo esc_url( minfolio_navigation_back_button_url() ); ?>">
        <span class="screen-reader-text">
            <?php echo esc_html__( 'All Portfolio', 'minfolio' ); ?>
        </span>
        <img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/svg/all-works.svg'; ?>" alt="<?php echo esc_html__( 'All Portfolio', 'minfolio' ); ?>" />                        
    </a>
</li>	