<?php

    wp_enqueue_script( 'cubeportfolio' );	    

    $gallery_images =  minfolio_get_post_meta( 'hero_gallery_images', true );
    $params = [];
            
    $params[ 'gallery_columns' ]  =  minfolio_get_post_meta( 'hero_image_gallery_cols' );	
    $params[ 'gallery_layout' ]   =  minfolio_get_post_meta( 'hero_media_layout' );
    $params[ 'gap_horizontal' ]   =  minfolio_get_post_meta( 'hero_gap_horizontal' );
    $params[ 'gap_vertical' ]     =  minfolio_get_post_meta( 'hero_gap_vertical' );		


    if( $gallery_images ) { ?>

        <div id="portfolio-container-hero-gallery" class="portfolio-hero gallery cbp" <?php echo minfolio_build_data_attr( minfolio_get_gallery_data_attributes( $params ) ); ?> >                                     
                                    
            <?php foreach ( $gallery_images as $grid_image ) { ?>		

                <div class="cbp-item">
                    <div class="cbp-caption-defaultWrap">
                        <?php echo minfolio_get_cpt_attachment_image( $grid_image, 'full' ); ?>
                    </div>
                </div>

            <?php } ?>
                
        </div>

    <?php }	?>