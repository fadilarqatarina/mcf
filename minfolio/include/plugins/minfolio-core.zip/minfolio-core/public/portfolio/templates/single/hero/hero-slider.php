<?php 

	wp_enqueue_script( 'flickity' );		
		
	$data_attr = array();	
	$params = [];	
			
	$params[ 'transition_effect' ] = minfolio_get_post_meta( 'hero_transition_effect' );
	$params[ 'auto_play' ] = minfolio_get_post_meta( 'hero_autoplay_delay' );		
		
	$params[ 'pagination' ] = minfolio_get_post_meta( 'hero_slider_pagination' );
	$params[ 'navigation' ] = minfolio_get_post_meta( 'hero_slider_navigation' );	
	
	$data_attr[ 'data-flickity-options' ]  = minfolio_get_hero_slider_data_attributes( $params );			
		
	$hero_section_style = array();		
		
	$hero_full_height_class = '';
	
	$hero_section_height = minfolio_get_post_meta( 'hero_section_height' );	

	if( $hero_section_height == 'custom' ) {

		$hero_custom_height = minfolio_get_post_meta( 'hero_custom_height' );

		$hero_section_style[ 'height' ] = $hero_custom_height;	
	}
	else {
		$hero_full_height_class = 'hero-full-height';
	}	

					
	$slider_images  =  minfolio_get_post_meta( 'hero_slider_images', true );	
	
    if( $slider_images ) { ?>	
						
	    <div class="portfolio-hero single-slider <?php echo esc_attr( $hero_full_height_class ); ?>"  <?php echo minfolio_build_data_attr( $data_attr ); ?> >		    

		    <?php foreach ( $slider_images as $slide_image ) { ?>
				
			    <div class="carousel-cell">

					<?php 
					
						$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
						$slide_image_data = '';
					
		
						if( $lazy_load === 1 ) {		
							$slide_image_data = 'data-flickity-bg-lazyload =' . esc_url( wp_get_attachment_url( $slide_image ) );		
						} else {
							$hero_section_style[ 'background-image' ] = 'url(' . esc_url( wp_get_attachment_url( $slide_image ) ) . ')';							
						}		

					?>
				
                    <div <?php echo esc_attr( $slide_image_data ) ?> <?php echo minfolio_build_inline_style( $hero_section_style ); ?> ></div>
                   
                </div>
				
		    <?php } ?>			
		
		</div>
		
	<?php }	?>