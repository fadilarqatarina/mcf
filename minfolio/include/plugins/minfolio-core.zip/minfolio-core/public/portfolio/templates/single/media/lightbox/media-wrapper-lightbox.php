<?php
	$media_type   = minfolio_get_post_meta( 'portfolio_lightbox_type' );
?>
				
	<div class="media-wrap">

		<?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/media/lightbox/' . $media_type );  ?>

	</div>

