<?php
		
    $meta_desc = minfolio_get_post_meta( 'portfolio_desc' );	
		
	if( !post_password_required() && $meta_desc ) {	?>

		<div class="meta-desc">
			<?php echo do_shortcode( $meta_desc ); ?>
		</div>		

    <?php } ?>