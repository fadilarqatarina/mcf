<?php
/**
 * The template for displaying archive portfolio category
 */

get_header(); 

$archive_obj = get_queried_object();

$archive_banner_type = get_term_meta( $archive_obj->term_id, 'clbr_meta_' . $archive_obj->taxonomy . '_banner', true );

if( $archive_banner_type == 'custom' ) {
	
	echo minfolio_get_cpt_portfolio_template_part( 'templates/archive/banner/banner', $archive_obj->taxonomy ); 
}
else {
	echo minfolio_get_cpt_portfolio_template_part( 'templates/archive/banner/banner' ); 
}

?>

<div id="content" class="site-content">

	<div class="wrap">	

		<div id="primary" class="content-area content-list">
			<main id="main" class="site-main" role="main">					
			
			<?php 

				$portfolioFrontEnd = Minfolio_Portfolio_FrontEnd::getInstance();
				$portfolioFrontEnd->get_archive_portfolio_items();			

			?>

			</main><!-- #main -->
		</div><!-- #primary -->
		
	</div><!-- .wrap -->

</div>

<?php get_footer(); ?>

