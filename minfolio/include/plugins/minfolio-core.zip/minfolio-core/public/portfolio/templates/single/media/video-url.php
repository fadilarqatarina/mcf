<?php

	$video_url_entries	= !empty( $media_entry[ MINFOLIO_META_PREFIX . 'page_video_url' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'page_video_url' ]  : '';
	
	if( !empty( $video_url_entries ) ) { 

		foreach ( $video_url_entries as $video_url ) {
			
			$video_url_data = explode( '|', $video_url );

		?>
			<div class="portfolio-media video-url embed-responsive embed-responsive-16by9">			
			
				<?php echo wp_oembed_get( esc_url( $video_url_data[ 0 ] ) ); ?>
			
				<?php if( isset( $video_url_data[ 1 ] ) ) { ?>
					<div class="video-meta-details">				
						<p><?php echo $video_url_data[ 1 ]; ?></p>
					</div>									
				<?php }	?>
			
			</div>

		<?php }

	} ?>