<?php

    $video_url = minfolio_get_post_meta( 'lightbox_video_url' );			

    if( !empty( $video_url ) ) { ?>

        <div class="portfolio-media embed-responsive embed-responsive-16by9">
            <?php echo wp_oembed_get( esc_url( $video_url ) ); ?>
        </div>
        
    <?php } ?>