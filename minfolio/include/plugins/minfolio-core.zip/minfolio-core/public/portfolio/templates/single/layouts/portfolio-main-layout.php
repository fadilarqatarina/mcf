<?php
   
    $portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );

    $portfolio_nav_switch = minfolio_get_core_option( 'portfolio-nav-switch' );
    $related_portfolio_switch = minfolio_get_core_option( 'portfolio-related-switch' );		
        	

	if( $portfolio_project_type == 'lightbox' ) {   

		echo minfolio_get_cpt_portfolio_template_part( 'templates/single/layouts/layout-lightbox-details' ); 
    }
    else {				
            
        $details_placement = minfolio_get_post_meta( 'details_placement' );	
			
	    echo minfolio_get_cpt_portfolio_template_part( 'templates/single/layouts/layout', $details_placement ); 
                
    }				

    if( $portfolio_nav_switch == 1 ) {        
        
	    echo minfolio_get_cpt_portfolio_template_part( 'templates/single/navigation/nav' ); 		
    }
        
    if( $related_portfolio_switch == 1 ) {

        $page_related_portfolio_section = minfolio_get_post_meta( 'page_related_portfolio_section' );
        
        if( $page_related_portfolio_section == 1 ) {

	        echo minfolio_get_cpt_portfolio_template_part( 'templates/single/related/section-wrapper' ); 
        }
	}
       	