<?php 

    $show_categories = minfolio_get_post_meta( 'portfolio_meta_show_categories' );			
	$portfolio_categories = wp_get_post_terms( get_the_ID(), 'portfolio_category' );	
					
	if ( $show_categories && !empty( $portfolio_categories ) ) { ?>
			
		<li>
			
		    <span><?php echo esc_html__( 'Categories', 'minfolio' ); ?></span>
			
            <span class="portfolio-categories">
                
                <?php foreach ( $portfolio_categories as $key => $value ) { ?>
                        
                    <a href="<?php echo get_term_link( $value->slug, 'portfolio_category'); ?>">				
                        <?php echo $value->name; ?>				
                    </a>

                <?php } ?>
                
            </span>
			
		</li>

	<?php }	?>