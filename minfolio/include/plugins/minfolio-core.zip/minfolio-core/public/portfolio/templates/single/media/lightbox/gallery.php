<?php

	wp_enqueue_script( 'flickity' );	

	$slider_images   = minfolio_get_post_meta( 'lightbox_gallery_images', true );	
	
    if( $slider_images ) { ?>		

		<div class="clbr-slider-wrap">
			
			<div class="portfolio-media slider" <?php echo minfolio_build_data_attr( minfolio_get_media_slider_data_attributes( $params ) ); ?> >	

				<?php foreach ( $slider_images as $slide_image ) {	?>

					<div class="carousel-cell">

						<?php echo wp_get_attachment_image( $slide_image, 'full' ); ?>      

					</div>

				<?php } ?>			
				
			</div>			

		</div>
		
	<?php } ?>