<?php
/**
 * Template part for displaying portfolio details top layout
 *
 */

$page_builder_section_placement = minfolio_get_post_meta( 'page_builder_section_placement' );

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >

	<div class="entry-details">	
	
		<header class="entry-header">	
			
			<?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/title' ); ?>
			
		</header><!-- .entry-header -->				
			
		<div class="entry-meta <?php echo esc_attr( minfolio_meta_section_check() ); ?>">
				
			<?php 
			
				echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/description' );                      
						
				echo minfolio_get_cpt_portfolio_template_part( 'templates/single/meta/data-value' );   
					
			?>
				
		</div>

	</div>
	
		
	<?php if( $page_builder_section_placement == 'below-details-section' ) {				 
		the_content();
	} ?>	

	<div class="entry-content">
		
		<?php 
		
			echo minfolio_get_cpt_portfolio_template_part( 'templates/single/media/media-wrapper' ); 
					
			if( $page_builder_section_placement == 'below-media-section' ) {				 
				the_content();
			}				
			
		?>
		
	</div><!-- .entry-content -->

	
</article><!-- #post-## -->
