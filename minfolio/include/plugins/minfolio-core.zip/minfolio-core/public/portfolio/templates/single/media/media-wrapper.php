<?php

	$media_section_switch = minfolio_get_post_meta( 'media_section_switch' );

	$media_entries	= minfolio_get_post_meta( 'portfolio_multiple_media_groupbox' );
	$index = 1;		

	if( $media_section_switch == 1 && $media_entries ) { ?>		

		<div class="media-wrap">			

			<?php foreach ( $media_entries as $media_entry ) {		
				
				$params = array();

				$params[ 'media_entry' ] = $media_entry;
				$params[ 'index' ] = $index;

				$media_type	= !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_display' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_display' ]  : 'NO_MEDIA';					

				echo minfolio_get_cpt_portfolio_template_part( 'templates/single/media/' . $media_type, '', $params );				

				$index++;

			} ?>

		</div>

	<?php }	?>
