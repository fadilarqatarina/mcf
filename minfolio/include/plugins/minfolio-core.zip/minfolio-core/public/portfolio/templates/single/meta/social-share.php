<?php   
                                        
    $allow_social_sharing = minfolio_get_core_option( 'portfolio-social-sharing' );
        
    $multilingual_switch = minfolio_get_core_option( 'multilingual-switch' );		
    $social_share_title  = minfolio_get_core_option( 'portfolio-social-share-title' );		      
            
    $icons = minfolio_get_core_option( 'portfolio-share-icons' );

    if ( $allow_social_sharing == 1 ) { 

        wp_enqueue_script( 'minfolio-social-share' );   
        
        $icons = explode ( ',', $icons ); 
             
    ?>

        <li class="portfolio-social-share-links">    

            <?php if( $multilingual_switch == 1 ) {	?>					
				<span><?php echo esc_html__( 'Share', 'minfolio' ); ?></span>
			<?php }	else { ?>
				<span><?php echo $social_share_title; ?></span>
			<?php } ?>
                        
            <?php foreach ( $icons as $icon ) { ?>                        

                <a href="#" data-network="<?php echo esc_attr( $icon ); ?>" data-shareurl="<?php echo esc_url( get_the_permalink() ); ?>" >
                    <i class="<?php echo esc_attr( $icon ); ?>" ></i>
                </a>

           <?php } ?>
            
        </li>

    <?php } ?>