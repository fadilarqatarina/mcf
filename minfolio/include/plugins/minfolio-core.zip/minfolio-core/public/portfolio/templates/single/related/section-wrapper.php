<?php

    $related_portfolio_title = minfolio_get_post_meta( 'related_portfolio_title' );		
    $related_portfolio_layout = minfolio_get_post_meta( 'related_portfolio_layout' );	
?>

    <div class="clbr-related-portfolio-wrapper">

        <h3 class="clbr-related-portfolio-title">
            <?php echo esc_html( $related_portfolio_title ); ?>
        </h3>

        <?php 

            $portfolioFrontEnd = Minfolio_Portfolio_FrontEnd::getInstance();

            if( $related_portfolio_layout == 'grid' ) {
                $portfolioFrontEnd->get_related_grid_portfolio_items();	
            }
            else {               
                $portfolioFrontEnd->get_related_carousel_portfolio_items();
            }

        ?>
                
    </div>