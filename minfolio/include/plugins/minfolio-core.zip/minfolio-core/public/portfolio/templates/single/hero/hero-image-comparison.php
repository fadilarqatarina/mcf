<?php

	wp_enqueue_script( 'cocoen' );

    $compare_images   = minfolio_get_post_meta( 'hero_image_comparison', true );
	
    if( $compare_images ) {	?>
			
	    <div class="portfolio-hero cocoen image-comparison">
			
			<?php foreach ( $compare_images as $compare_image ) {

				echo wp_get_attachment_image( $compare_image, 'full' );

			} ?>
			
		</div>
		
<?php } ?>
		