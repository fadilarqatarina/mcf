<?php

	$page_title     = minfolio_get_post_meta( 'title' );
	$page_sub_title = minfolio_get_post_meta( 'sub_title' );	

	$thumbnail_title = minfolio_get_post_meta( 'thumbnail_title' );
	

	if( $page_title ) { ?>

		<h2 class="entry-title"><?php echo esc_html( $page_title ); ?></h2>
		
		<?php if( $page_sub_title ) { ?>
			<div class="description"><?php echo esc_html( $page_sub_title ); ?></div>
		<?php }			

	}
	elseif( $thumbnail_title ) {

		$thumbnail_sub_title = minfolio_get_post_meta( 'thumbnail_sub_title' );
	?>
		<h2 class="entry-title"><?php echo esc_html( $thumbnail_title ); ?></h2>
		
		<?php if( $thumbnail_sub_title ) { ?>
			<div class="description"><?php echo esc_html( $thumbnail_sub_title ); ?></div>
		<?php }			
	}		
	else { ?>
				
		<h2 class="entry-title"><?php echo esc_html( get_the_title() ); ?></h2>

	<?php }	?>