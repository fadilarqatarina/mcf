<?php

    $hero_image = minfolio_get_post_meta( 'hero_image_url' );		
    $hero_overlay_color = minfolio_get_post_meta( 'hero_image_overlay_color' );		
  
    $hero_image_title = minfolio_get_post_meta( 'hero_image_title' );	
    $hero_image_desc  = minfolio_get_post_meta( 'hero_image_desc' );	
            
    $hero_section_style = array();
    $overlay_style = array();
      
    $hero_section_style[ 'background-image' ] = 'url("' . esc_url( wp_get_attachment_url( $hero_image ) ) . '")';	
      
    $overlay_style[ 'background-color' ]    = $hero_overlay_color;
    
    $hero_section_height = minfolio_get_post_meta( 'hero_section_height' );	

    if( $hero_section_height == 'custom' ) {

        $hero_custom_height = minfolio_get_post_meta( 'hero_custom_height' );

        $hero_section_style[ 'height' ] = $hero_custom_height;	        
    }	
    
   ?>        
          
    <div class="portfolio-hero bg-image hero-full-height" <?php echo minfolio_build_inline_style( $hero_section_style ); ?> >
        
        <div class="color-overlay" <?php echo minfolio_build_inline_style( $overlay_style ); ?> ></div>	

        <?php if( $hero_image_title || $hero_image_desc ) { ?>

            <div class="hero-image-content-wrap wrap">
                <div class="hero-image-banner-content">
                    
                    <?php if( $hero_image_title ) { ?>

                        <span>
                            <?php echo esc_html__( $hero_image_title, 'minfolio' ); ?>
                        </span>	

                    <?php } ?>

                    <?php if( $hero_image_desc ) { ?>
                        <h1 class="hero-image-desc">
                            <?php echo wp_kses_post( $hero_image_desc ); ?>
                        </h1>		
                    <?php } ?>							

                </div>                
            </div>

        <?php } ?>

    </div>					
      
   
