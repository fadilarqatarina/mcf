<?php   

    wp_enqueue_script( 'flickity' );		

    $data_attr = array();

    $hero_section_style = array();	
	$params = [];	
   
  
    $params[ 'loop' ] = minfolio_get_post_meta( 'hero_loop' );
    $params[ 'transition_effect' ] = minfolio_get_post_meta( 'hero_transition_effect' );
    $params[ 'auto_play' ] = minfolio_get_post_meta( 'hero_autoplay_delay' );
    $params[ 'pagination' ] = minfolio_get_post_meta( 'hero_slider_pagination' );
	$params[ 'navigation' ] = minfolio_get_post_meta( 'hero_slider_navigation' );

    $data_attr[ 'data-flickity-options' ]  = minfolio_get_hero_multi_slider_data_attributes( $params );			

    $data_attr[ 'data-slide-space' ] = minfolio_get_post_meta( 'hero_slide_space' );
    
    $data_attr[ 'data-desktop-slide' ] = minfolio_get_post_meta( 'hero_slide_per_view' );    
    $data_attr[ 'data-tablet-slide' ] = minfolio_get_post_meta( 'hero_tablet_slide' );
    $data_attr[ 'data-mobile-slide' ] = minfolio_get_post_meta( 'hero_mobile_slide' );    	

    $data_attr[ 'data-desktop-height' ] = minfolio_get_post_meta( 'hero_slider_desktop_height' );
    $data_attr[ 'data-tablet-height' ] = minfolio_get_post_meta( 'hero_slider_tablet_height' );
    $data_attr[ 'data-mobile-height']  = minfolio_get_post_meta( 'hero_slider_mobile_height' );

   
    $slider_images  =  minfolio_get_post_meta( 'hero_slider_images', true );	


    if( $slider_images ) { ?>
                    
        <div class="portfolio-hero multiple-slider" <?php echo minfolio_build_data_attr( $data_attr ); ?> >        	

            <?php foreach ( $slider_images as $slide_image ) { ?>		

                <div class="carousel-cell">     
                    
                    <?php 
					
						$lazy_load = minfolio_get_core_option( 'lazy-load-switch' );                       
						$slide_image_data = '';					
		
						if( $lazy_load === 1 ) {		
							$slide_image_data = 'data-flickity-bg-lazyload =' . esc_url( wp_get_attachment_url( $slide_image ) );		
						} else {
							$hero_section_style[ 'background-image' ] = 'url(' . esc_url( wp_get_attachment_url( $slide_image ) ) . ')';							
						}		

					?>

                    <div <?php echo esc_attr( $slide_image_data ) ?> <?php echo minfolio_build_inline_style( $hero_section_style ); ?> class="image-wrap"></div>
                    
                </div>

            <?php } ?>  	

        </div>

<?php } ?>