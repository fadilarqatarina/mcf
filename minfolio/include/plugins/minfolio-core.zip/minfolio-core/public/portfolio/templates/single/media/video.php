<?php 	
							
	$video_src	= !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_video_source' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_video_source' ]  : '';

    echo minfolio_get_cpt_portfolio_template_part( 'templates/single/media/' . $video_src, '', $params );		
    
?>

