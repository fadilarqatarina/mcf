<?php  

    $nav_prev_text = minfolio_get_core_option( 'portfolio-prev-text' );
    $multilingual_switch = minfolio_get_core_option( 'multilingual-switch' );     
    
    if( $multilingual_switch == 1 ) {	
        $prev = get_previous_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Previous Portfolio', 'minfolio' ) . '</span><span><img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Previous', 'minfolio' ) . '" />' . esc_html__( 'Prev', 'minfolio' ) . '</span>' );
    }
    else {
        $prev = get_previous_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Previous Portfolio', 'minfolio' ) . '</span><span><img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Previous', 'minfolio' ) . '" />' . $nav_prev_text . '</span>' );
    }

    if ( $prev !== '' ) { ?>

        <li class="portfolio-prev">
            <?php echo $prev; ?>
        </li>
                
    <?php } else { ?>

        <li class="portfolio-prev disabled">
            <span class="screen-reader-text"><?php echo esc_html__( 'Previous Portfolio', 'minfolio' ); ?></span>
            <span>

                <img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg'; ?>" alt="<?php echo esc_html__( 'Previous', 'minfolio' ); ?>" />                        

                <?php echo ( $multilingual_switch == 1 ) ? esc_html__( 'Prev', 'minfolio' ) : $nav_prev_text; ?>                 

            </span>
        </li>
            
<?php } ?>
