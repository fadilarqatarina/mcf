<?php 
    $portfolio_nav_type = minfolio_get_core_option( 'portfolio-nav-type' );
?>

    <div class="portfolio-navigation-wrap">

        <ul class="portfolio-navigation">  

            <?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/navigation/parts/prev', $portfolio_nav_type ); ?>

            <?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/navigation/parts/home' ); ?>

            <?php echo minfolio_get_cpt_portfolio_template_part( 'templates/single/navigation/parts/next', $portfolio_nav_type ); ?>  

        </ul>

    </div>
