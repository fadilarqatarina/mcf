<?php 

    $nav_next_text = minfolio_get_core_option( 'portfolio-next-text' );
    $multilingual_switch = minfolio_get_core_option( 'multilingual-switch' );

    if( $multilingual_switch == 1 ) {
        $next = get_next_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Next Portfolio', 'minfolio' ) . '</span><span>' . esc_html__( 'Next', 'minfolio' ) . '<img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Next', 'minfolio' ) . '" /></span>' );
    }
    else {
        $next = get_next_post_link( '%link', '<span class="screen-reader-text">' . esc_html__( 'Next Portfolio', 'minfolio' ) . '</span><span>' . $nav_next_text . '<img src="' . MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg' . '" alt="' . esc_html__( 'Next', 'minfolio' ) . '" /></span>' );
    }

    if ( $next !== '' ) { ?>

        <li class="portfolio-next">
            <?php echo $next; ?>
        </li>

    <?php } else { ?>

        <li class="portfolio-next disabled">
            <span class="screen-reader-text"><?php echo esc_html__( 'Next Portfolio', 'minfolio' ); ?></span>

            <span>
            
                <?php echo ( $multilingual_switch == 1 ) ? esc_html__( 'Next', 'minfolio' ) : $nav_next_text; ?>                 

                <img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/svg/nav-arrow.svg'; ?>" alt="<?php echo esc_html__( 'Next', 'minfolio' ); ?>" />                        

            </span>
        </li>	

<?php }	?>           