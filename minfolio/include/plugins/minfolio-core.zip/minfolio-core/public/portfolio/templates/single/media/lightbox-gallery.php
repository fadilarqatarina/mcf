<?php 

    wp_enqueue_script( 'cubeportfolio' );	    

    do_action( 'minfolio_enqueue_portfolio_scripts' );  
  
    $gallery_images = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'media_images' ]  : '';
    $params = [];
	
	$params[ 'gallery_columns' ]  =  !empty( $media_entry[ MINFOLIO_META_PREFIX . 'image_gallery_cols' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'image_gallery_cols' ]  : 3;		
    $params[ 'gallery_layout' ]   =  !empty( $media_entry[ MINFOLIO_META_PREFIX . 'media_layout' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'media_layout' ]  : 'grid';
    $params[ 'gap_horizontal' ]   =  !empty( $media_entry[ MINFOLIO_META_PREFIX . 'gap_horizontal' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'gap_horizontal' ]  : 0;
    $params[ 'gap_vertical' ]     =  !empty( $media_entry[ MINFOLIO_META_PREFIX . 'gap_vertical' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'gap_vertical' ]  : 0;
	               
    $show_image_caption = !empty( $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_image_show_caption' ] )  ? $media_entry[ MINFOLIO_META_PREFIX . 'multi_media_image_show_caption' ]  : '0';
    
    if( $gallery_images ) { ?>

        <div class="clbr-portfolio-wrap portfolio-media">

            <div id="portfolio-container-lightbox-media-<?php echo esc_attr( $index ); ?>" class="cbp" <?php echo minfolio_build_data_attr( minfolio_get_gallery_data_attributes( $params ) ); ?> >
                                        
            <?php foreach ( $gallery_images as $grid_image ) {
             
                $grid_image_url = wp_get_attachment_image_url( $grid_image, 'full' );					
            
                $image_caption = '';		

                if ( $show_image_caption ) {

                    $image_caption = minfolio_get_portfolio_image_caption( $grid_image );
                }             
                                              
            ?>
               <div class="cbp-item">

                    <a class="cbp-caption" data-elementor-open-lightbox="yes" data-elementor-lightbox-title="<?php echo esc_attr( $image_caption ); ?>" data-elementor-lightbox-slideshow="slide-show-<?php echo esc_attr( $index ); ?>" href="<?php echo esc_url( $grid_image_url ); ?>" >		
                
                        <div class="cbp-caption-defaultWrap">		
                                <?php echo minfolio_get_cpt_attachment_image( $grid_image, 'full' ); ?>
                        </div>

                        <div class="cbp-caption-activeWrap">
                            <div class="cbp-l-caption-alignCenter">
                                <div class="cbp-l-caption-body">
                                    <div class="cbp-l-caption-title">
                                        <img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/svg/plus.svg'; ?>" class="lightbox-plus" alt="<?php echo esc_attr( 'Lightbox Plus', 'minfolio' ); ?>" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>	
                    		
               </div>

            <?php } ?>
                
            </div>

        </div>

    <?php }	?>