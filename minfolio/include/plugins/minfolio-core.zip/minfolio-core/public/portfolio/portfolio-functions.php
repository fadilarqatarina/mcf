<?php

    if ( ! function_exists( 'minfolio_enqueue_elementor_scripts' ) ) {	

        function minfolio_enqueue_elementor_scripts() {

            if( is_archive() ) {

                wp_enqueue_script( 'elementor-frontend' );
                wp_enqueue_style( 'swiper' );
                wp_enqueue_script( 'swiper' );
                wp_enqueue_script( 'preloaded-modules',	 plugins_url() . '/elementor/assets/js/preloaded-modules.min.js', [ 'elementor-frontend', ], MINFOLIO_THEME_VERSION, true );

            }
            else {

                $post_id = get_the_ID();

                $document = \Elementor\Plugin::$instance->documents->get( $post_id );
        
                if (  ! $document->is_built_with_elementor() ) {

                    wp_enqueue_script( 'elementor-frontend' );
                    wp_enqueue_style( 'swiper' );
                    wp_enqueue_script( 'swiper' );
                    wp_enqueue_script( 'preloaded-modules',	 plugins_url() . '/elementor/assets/js/preloaded-modules.min.js', [ 'elementor-frontend', ], MINFOLIO_THEME_VERSION, true );
                    
                }            

            }

        }

        add_action( 'minfolio_enqueue_portfolio_scripts', 'minfolio_enqueue_elementor_scripts' );    

    }


    if ( ! function_exists( 'minfolio_meta_section_check' ) ) {
	
        function minfolio_meta_section_check() {
    
            $meta_section_switch = minfolio_get_post_meta( 'meta_details_reqd' );
            $no_meta_class = '';
    
            if( $meta_section_switch == 0 ) {
                $no_meta_class = 'no-meta';
            }
          
            return $no_meta_class;
        }
    }

    
    if ( ! function_exists( 'minfolio_navigation_back_button_url' ) ) {	

        function minfolio_navigation_back_button_url() {
        
            $portfolio_page	= minfolio_get_core_option( 'portfolio-nav-home' );        
            
            $portfolio_page_home_custom	= minfolio_get_post_meta( 'page_portfolio_home_custom' );
            
            if( $portfolio_page_home_custom ) {
                $portfolio_page = $portfolio_page_home_custom;
            }
    
            $back_url = get_page_link( $portfolio_page );
               
            return $back_url;

        } 
    }


    if ( ! function_exists( 'minfolio_get_cpt_attachment_image' ) ) {	
	
        function minfolio_get_cpt_attachment_image( $image_id, $size = 'post-thumbnail' ) {
    
            $lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
                            
            $attachment_html = '';
            
            $attachment_html = wp_get_attachment_image( $image_id, $size );
            
            if( $lazy_load == 1 ) {
            
                $attachment_html =  preg_replace( '/src/', ' src="data:image/gif;base64,R0lGODlhAQABAPAAAP///////yH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" data-cbp-src', $attachment_html, 1 );
    
                $attachment_html =  preg_replace( '/srcset/', 'data-cbp-srcset', $attachment_html, 1 );	
            
                $attachment_html =  preg_replace( '/sizes/', 'data-sizes', $attachment_html, 1 );	
    
            }
                    
            return $attachment_html;		
            
        }
        
    }

    if ( ! function_exists( 'minfolio_get_portfolio_image_caption' ) ) {
	
        function minfolio_get_portfolio_image_caption( $image_id ) {
            
            $attributes = [];	
            
            $attachment = get_post( $image_id );   
          
            $image_caption = $attachment->post_excerpt;
    
            return $image_caption;
        }
    }
    
  
    if ( ! function_exists( 'minfolio_add_portfolio_inline_css' ) ) {	
	
        function minfolio_add_portfolio_inline_css( $portfolio_theme_options_css ) {

            if( is_singular( 'portfolio' ) || is_archive( 'portfolio' ) ) {
                
                $portfolio_media_spacing = minfolio_get_post_meta( 'multi_media_space_between' );  

                $portfolio_meta_title_color = minfolio_get_core_option( 'portfolio-single-meta-title-color' );                              
                $portfolio_meta_desc_color = minfolio_get_core_option( 'portfolio-single-meta-desc-color' );                              
                $portfolio_meta_desc_hover_color = minfolio_get_core_option( 'portfolio-single-meta-desc-hover-color' );                              

                $hero_slider_pagination_color = minfolio_get_core_option( 'portfolio-single-hero-slider-pag-color' );                              
                $hero_slider_pagination_active_color = minfolio_get_core_option( 'portfolio-single-hero-slider-pag-active-color' );                  

                $media_slider_pagination_color = minfolio_get_core_option( 'portfolio-single-media-slider-pag-color' );                              
                $media_slider_pagination_active_color = minfolio_get_core_option( 'portfolio-single-media-slider-pag-active-color' );                

                $related_slider_pagination_color = minfolio_get_core_option( 'portfolio-single-related-slider-pag-color' );                              
                $related_slider_pagination_active_color = minfolio_get_core_option( 'portfolio-single-related-slider-pag-active-color' );                
                

                 $portfolio_theme_options_css .= 'body { --clbr-portfolio-media-spacing:' . $portfolio_media_spacing . 'px; }';    

                if( $portfolio_meta_title_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li span:not(.portfolio-categories):not(.portfolio-tags) { color: ' . $portfolio_meta_title_color . ' } ';	
                }

                if( $portfolio_meta_desc_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li { color: ' . $portfolio_meta_desc_color . ' } ';	
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li span.portfolio-categories a { color: ' . $portfolio_meta_desc_color . ' } ';	
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li span.portfolio-tags a { color: ' . $portfolio_meta_desc_color . ' } ';	
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li.portfolio-social-share-links a i { color: ' . $portfolio_meta_desc_color . ' } ';
                }

                if( $portfolio_meta_desc_hover_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li span.portfolio-categories a:hover { color: ' . $portfolio_meta_desc_hover_color . ' } ';	
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li span.portfolio-tags a:hover { color: ' . $portfolio_meta_desc_hover_color . ' } ';	
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio .entry-meta .meta-entries ul li.portfolio-social-share-links a:hover i { color: ' . $portfolio_meta_desc_hover_color . ' } ';	
                }

                if( $hero_slider_pagination_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio-hero.single-slider .flickity-page-dots .dot { background-color: ' . $hero_slider_pagination_color . ' } ';	
                }

                if( $hero_slider_pagination_active_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio-hero.single-slider .flickity-page-dots .dot.is-selected { background-color: ' . $hero_slider_pagination_active_color . ' } ';	
                }         
                
                if( $media_slider_pagination_color ) {                     
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio-media.slider button.flickity-button { background-color: ' . $media_slider_pagination_color . ' } ';	
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio-media.slider .flickity-page-dots .dot { background-color: ' . $media_slider_pagination_color . ' } ';	
                }

                if( $media_slider_pagination_active_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .portfolio-media.slider .flickity-page-dots .dot.is-selected { background-color: ' . $media_slider_pagination_active_color . ' } ';	
                }      
                
                if( $related_slider_pagination_color ) {                                         
                    $portfolio_theme_options_css .= ' .single-portfolio .clbr-related-portfolio-carousel .flickity-page-dots .dot { background-color: ' . $related_slider_pagination_color . ' } ';	
                }

                if( $related_slider_pagination_active_color ) { 
                    $portfolio_theme_options_css .= ' .single-portfolio .clbr-related-portfolio-carousel .flickity-page-dots .dot.is-selected { background-color: ' . $related_slider_pagination_active_color . ' } ';	
                }           
                
                
                $portfolio_theme_options_css .= build_responsive_padding_control_css( 'desktop', 'portfolio-archive-banner-padding', '.portfolio-archive-banner' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-banner-title-typo', 'portfolio-banner-title-color', '.portfolio-archive-banner .portfolio-archive-banner-content h1' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-banner-desc-typo', 'portfolio-banner-desc-color', '.portfolio-archive-banner .portfolio-archive-banner-content .description p' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-hero-title-typo', 'portfolio-hero-title-color', '.portfolio-hero-section-wrap .hero-image-content-wrap span' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-hero-desc-typo', 'portfolio-hero-desc-color', '.portfolio-hero-section-wrap .hero-image-content-wrap h1' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-single-title-typo', 'portfolio-single-title-color', '.single-portfolio .portfolio .entry-header .entry-title' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-single-subtitle-typo', 'portfolio-single-subtitle-color', '.single-portfolio .portfolio .entry-header .description' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'desktop', 'portfolio-single-desc-typo', 'portfolio-single-desc-color', '.single-portfolio .portfolio .entry-meta .meta-desc p' );
                             

                $portfolio_theme_options_css .= ' @media (max-width: 1024px) { ';

                $portfolio_theme_options_css .= build_responsive_padding_control_css( 'tablet', 'portfolio-archive-banner-padding', '.portfolio-archive-banner' );                

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'bportfolio-banner-title-typo', 'portfolio-banner-title-color', '.portfolio-archive-banner .portfolio-archive-banner-content h1' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'portfolio-banner-desc-typo', 'portfolio-banner-desc-color', '.portfolio-archive-banner .portfolio-archive-banner-content .description p' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'portfolio-hero-title-typo', 'portfolio-hero-title-color', '.portfolio-hero-section-wrap .hero-image-content-wrap span' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'portfolio-hero-desc-typo', 'portfolio-hero-desc-color', '.portfolio-hero-section-wrap .hero-image-content-wrap h1' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'portfolio-single-title-typo', 'portfolio-single-title-color', '.single-portfolio .portfolio .entry-header .entry-title' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'portfolio-single-subtitle-typo', 'portfolio-single-subtitle-color', '.single-portfolio .portfolio .entry-header .description' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'tablet', 'portfolio-single-desc-typo', 'portfolio-single-desc-color', '.single-portfolio .portfolio .entry-meta .meta-desc p' );

                $portfolio_theme_options_css .= ' } ';	

                $portfolio_theme_options_css .= ' @media (max-width: 767px) { ';
               
                $portfolio_theme_options_css .= build_responsive_padding_control_css( 'mobile', 'portfolio-archive-banner-padding', '.portfolio-archive-banner' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'bportfolio-banner-title-typo', 'portfolio-banner-title-color', '.portfolio-archive-banner .portfolio-archive-banner-content h1' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'portfolio-banner-desc-typo', 'portfolio-banner-desc-color', '.portfolio-archive-banner .portfolio-archive-banner-content .description p' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'portfolio-hero-title-typo', 'portfolio-hero-title-color', '.portfolio-hero-section-wrap .hero-image-content-wrap span' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'portfolio-hero-desc-typo', 'portfolio-hero-desc-color', '.portfolio-hero-section-wrap .hero-image-content-wrap h1' );

                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'portfolio-single-title-typo', 'portfolio-single-title-color', '.single-portfolio .portfolio .entry-header .entry-title' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'portfolio-single-subtitle-typo', 'portfolio-single-subtitle-color', '.single-portfolio .portfolio .entry-header .description' );
                $portfolio_theme_options_css .= build_responsive_typography_control_css( 'mobile', 'portfolio-single-desc-typo', 'portfolio-single-desc-color', '.single-portfolio .portfolio .entry-meta .meta-desc p' );

                $portfolio_theme_options_css .= ' } ';	
 
            }

            return $portfolio_theme_options_css;
            
        }
        
        add_filter( 'minfolio_add_inline_css', 'minfolio_add_portfolio_inline_css' );      

    }

    if ( ! function_exists( 'minfolio_get_gallery_data_attributes' ) ) {        

    	function minfolio_get_gallery_data_attributes( $params ) {
			
			$data_attr = array();	
			$options = array();						
					
			//$options[ 'filters' ] = '#filters-container, [id^=filters-container-subcategory]';
			//$options[ 'defaultFilter' ] = '*';
            //$options[ 'animationType' ] = ( $params[ 'filter_animation' ] ) ? $params[ 'filter_animation' ] : '';

			$options[ 'layoutMode' ] = ( $params[ 'gallery_layout' ] ) ? $params[ 'gallery_layout' ] : 'grid';
			$options[ 'sortToPreventGaps' ] = true;			
			$options[ 'gapHorizontal' ] = ( $params[ 'gap_horizontal' ] ) ? intval( $params[ 'gap_horizontal' ] ) : 0;
			$options[ 'gapVertical' ] = ( $params[ 'gap_vertical' ] ) ? intval( $params[ 'gap_vertical' ] ) : 0;
			$options[ 'gridAdjustment' ] = 'responsive';
			$options[ 'displayType' ] = 'default';
            $options[ 'caption' ] = 'fadeIn';
			$options[ 'displayTypeSpeed' ] = 100;
			$options[ 'mediaQueries' ] = [ 
											[ 'width' => 1025, 'cols' => isset( $params[ 'gallery_columns' ] ) ?  intval( $params[ 'gallery_columns' ] ) : 4 ],  
											[ 'width' => 790, 'cols' => isset( $params[ 'gallery_columns' ] ) ?  intval( $params[ 'gallery_columns' ] ) : 3 ],  
											[ 'width' => 680, 'cols' => isset( $params[ 'gallery_columns' ] ) ?  intval( $params[ 'gallery_columns' ] ) : 2 ],  
											[ 'width' => 600, 'cols' => 1 ],  
										];


			$data_attr[ 'data-cbp-options' ] = stripslashes( wp_json_encode( $options ) );		
			
			return $data_attr;
	
		}

    }

    if ( ! function_exists( 'minfolio_get_media_slider_data_attributes' ) ) {        

    	function minfolio_get_media_slider_data_attributes( $params ) {
			
			$data_attr = array();	
			$options = array();								
                      
            $options[ 'prevNextButtons' ] = ( $params[ 'navigation' ] ) ? true : false;
		    $options[ 'pageDots' ] = ( $params[ 'pagination' ] ) ? true : false;
		    $options[ 'wrapAround' ] = true;
		    $options[ 'cellAlign' ] = 'center';
		    $options[ 'draggable' ] = true;
		    $options[ 'autoPlay' ] = true;
		    $options[ 'pauseAutoPlayOnHover' ] = false;
		    $options[ 'contain' ] = true;
            $options[ 'adaptiveHeight' ] = true;
		    $options[ 'imagesLoaded' ] = true;
		    $options[ 'bypassCheck' ] = true;

			$data_attr[ 'data-flickity-options' ] = stripslashes( wp_json_encode( $options ) );
			
			return $data_attr;
	
		}

    }

    if ( ! function_exists( 'minfolio_get_hero_slider_data_attributes' ) ) {        

    	function minfolio_get_hero_slider_data_attributes( $params ) {	
            
            $lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
			
			$options = array();								
                      
            $options[ 'prevNextButtons' ] = ( $params[ 'navigation' ] ) ? true : false;
		    $options[ 'pageDots' ] = ( $params[ 'pagination' ] ) ? true : false;
            $options[ 'fade' ] = ( $params[ 'transition_effect' ] === 'fade' ) ? true : false;			
		    $options[ 'wrapAround' ] = true;
		    $options[ 'cellAlign' ] = 'center';
		    $options[ 'draggable' ] = true;
		    $options[ 'autoPlay' ] = ( $params[ 'auto_play' ] ) ? $params[ 'auto_play' ] : true;
		    $options[ 'pauseAutoPlayOnHover' ] = false;
		    $options[ 'contain' ] = true;
            $options[ 'bgLazyLoad' ] = ( $lazy_load ) ? 1 : false;		  
		    $options[ 'bypassCheck' ] = true;

			return stripslashes( wp_json_encode( $options ) );	
				
		}

    }

    if ( ! function_exists( 'minfolio_get_hero_multi_slider_data_attributes' ) ) {        

    	function minfolio_get_hero_multi_slider_data_attributes( $params ) {	
            
            $lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
			
			$options = array();								
                      
            $options[ 'prevNextButtons' ] = ( $params[ 'navigation' ] ) ? true : false;
		    $options[ 'pageDots' ] = ( $params[ 'pagination' ] ) ? true : false;
            $options[ 'fade' ] = ( $params[ 'transition_effect' ] === 'fade' ) ? true : false;			
		    $options[ 'wrapAround' ] = ( $params[ 'loop' ] ) ? true : false;
            $options[ 'cellAlign' ] = 'center';
		    $options[ 'draggable' ] =  true;
		    $options[ 'autoPlay' ] = ( $params[ 'auto_play' ] ) ? $params[ 'auto_play' ] : true;
		    $options[ 'pauseAutoPlayOnHover' ] = false;
		    $options[ 'contain' ] = true;
            $options[ 'bgLazyLoad' ] = ( $lazy_load ) ? true : false;		  
		    $options[ 'bypassCheck' ] = true;

			return stripslashes( wp_json_encode( $options ) );	
				
		}

    }
   
   
   
    
    if ( ! function_exists( 'minfolio_get_cpt_portfolio_template_part' ) ) {
        
        function minfolio_get_cpt_portfolio_template_part( $template, $slug = '', $params = array() ) {
            
            //HTML Content from template
            $html          = '';	
            $template_path =  MINFOLIO_CORE_PATH . 'public/portfolio';
            
            $temp = $template_path . '/' . $template;
            
            if ( is_array( $params ) && count( $params ) ) {
                extract( $params );
            }
            
            $template = '';
            
            if ( ! empty( $temp ) ) {
                if ( ! empty( $slug ) ) {
                    $template = "{$temp}-{$slug}.php";
                    
                    if ( ! file_exists( $template ) ) {
                        $template = $temp . '.php';
                    }
                } else {
                    $template = $temp . '.php';
                }
            }
            
            if ( ! empty( $template ) ) {
                ob_start();
                include( $template );
                $html = ob_get_clean();
            }
            
            return $html;

        }
    }

