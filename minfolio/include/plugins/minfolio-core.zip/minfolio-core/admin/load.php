<?php 

   if( is_admin() ) {

        require_once( MINFOLIO_CORE_PATH . 'admin/meta-boxes/meta-boxes.php' );
    }       

    require_once( MINFOLIO_CORE_PATH . 'admin/customizer/class-theme-customizer.php' );     

    require_once( MINFOLIO_CORE_PATH . 'admin/custom-post/portfolio-register.php');			
    require_once( MINFOLIO_CORE_PATH . 'admin/custom-post/portfolio-frontend.php');			

    require_once( MINFOLIO_CORE_PATH . 'admin/page-builder/elementor/config.php' );  

    require_once( MINFOLIO_CORE_PATH . 'admin/page-builder/common-functions.php' );

    require_once( MINFOLIO_CORE_PATH . 'admin/widgets/contact-info.php' );																	   
	require_once( MINFOLIO_CORE_PATH . 'admin/widgets/social-links.php' );					
  