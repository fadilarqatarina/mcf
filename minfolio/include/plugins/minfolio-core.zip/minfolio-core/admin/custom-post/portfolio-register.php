<?php

if( ! class_exists( 'Minfolio_Portfolio_Register' ) ) {	 

	class Minfolio_Portfolio_Register {

		private $base;
		private $taxBase;
		private $tagBase;

		private $portfolio;

		public function __construct() {

			$this->base    = 'portfolio';
			$this->taxBase = 'portfolio_category';
			$this->tagBase = 'portfolio_tag';

			//portfolio image sizes
			add_image_size( 'minfolio-portfolio-grid-image', 600, 500, true );
			add_image_size( 'minfolio-portfolio-masonry-image', 600 );			

			$this->register();

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 10, 1 );	

			add_action( 'admin_menu' , array( $this, 'register_sub_menu_page' ) );
			add_action( 'wp_ajax_minfolio_portfolio_sort', array( $this, 'portfolio_posts_sort_order' ) );
			
			add_filter( 'archive_template', array( $this, 'register_archive_template' ) );
			add_filter( 'single_template', array( $this, 'register_single_template' ) );

			add_filter( 'body_class', array( $this, 'add_body_classes' ) );

			//add_filter( 'get_previous_post_sort', array( $this, 'modify_portfolio_prev_sort' ) );
			//add_filter( 'get_next_post_sort', array( $this, 'modify_portfolio_next_sort' ) );

			add_filter( 'get_previous_post_join', array( $this, 'modify_portfolio_join' ) );
			add_filter( 'get_next_post_join', array( $this, 'modify_portfolio_join' ) );

			add_filter( 'get_previous_post_where', array( $this, 'modify_portfolio_where' ) );
			add_filter( 'get_next_post_where', array( $this, 'modify_portfolio_where' ) );

		}		
	
		public function register() {

			$this->register_post_type();
			$this->register_tax();
			$this->register_tag_tax();
			$this->register_sub_menu_page();
		}

		/**
		 * Registers custom post type with WordPress
		 */
		private function register_post_type() {

			$portfolio_slug = minfolio_get_core_option( 'portfolio-slug-name' );			

			$names = [
				'post_type_name' => $this->base,
				'singular'	=> 'Portfolio Item',
				'plural'	=> 'Portfolio Items',				    
				'slug'		=> $portfolio_slug
			];

			$options = [
				'show_in_rest' => true, 
				'supports' => array( 'title', 'editor', 'thumbnail', 'revisions' )
			];

			$this->portfolio = new CPT( $names, $options );	
			
			$this->portfolio -> menu_icon( 'dashicons-book-alt' );

			$this->portfolio -> set_textdomain( 'minfolio' );			

			$this->portfolio->columns( array(
				'cb' 			 	 => '<input type="checkbox" />',
				'icon'  		 	 => esc_html__( 'Featured Image', 'minfolio' ),
				'title' 		 	 => esc_html__( 'Title', 'minfolio' ),
				'portfolio_type' 	 => esc_html__( 'Portfolio Type', 'minfolio' ),
				'portfolio_category' => esc_html__( 'Portfolio Categories', 'minfolio' ),
				'portfolio_tag' 	 => esc_html__( 'Portfolio Tags', 'minfolio' ),
				'date' 			     => esc_html__( 'Date', 'minfolio' ),
				'post_id' 			 => esc_html__( 'ID', 'minfolio' ),
			));

			$this->portfolio->populate_column( 'portfolio_type', function( $column, $post ) {

				$portfolio_type = minfolio_get_post_meta( 'portfolio_project_type' );

				if( $portfolio_type ) {
					echo ucfirst( $portfolio_type );
				}
			
			});		

		}


		/**
		 * Registers custom taxonomy with WordPress
		 */
		private function register_tax() {
			
			$names = [
				'taxonomy_name' => $this->taxBase,
				'singular' => 'Portfolio Category',
				'plural'   => 'Portfolio Categories',
				'slug'	   => 'portfolio-category'
			];

			$options = [
				'show_in_rest' => true 
			];	
			
			$this->portfolio -> register_post_taxonomy( $names, $options );		
		
		}


		/**
		 * Registers custom tag taxonomy with WordPress
		 */
		private function register_tag_tax() {
			
			$names = [
				'taxonomy_name' => $this->tagBase,
				'singular'	=> 'Portfolio Tag',
				'plural'	=> 'Portfolio Tags',
				'slug'		=> 'portfolio-tag'
			];

			$options = [
				'show_in_rest' => true,
				'hierarchical' => false
			];		
			
			$this->portfolio -> register_post_taxonomy( $names, $options );

		}

		public function register_sub_menu_page() {

			$names = [
				'parent_slug'		=> 'portfolio',
				'page_title'        => 'Sort Porfolio', 
				'menu_slug'			=> 'sort_portfolio', 
				'callback_function'	=> array( $this, 'portfolio_posts_sort_callback' )
			];

			$this->portfolio -> submenu_page_settings( $names );			
		}


		public function register_archive_template( $archive ) {

			global $post;
			
			if ( ! empty( $post ) && $post->post_type == $this->base ) {
				if ( ! file_exists( get_template_directory() . '/archive-' . $this->base . '.php' ) ) {
					return MINFOLIO_CORE_PATH . 'public/portfolio/templates/archive/archive-' . $this->base . '.php';
				}
			}
			
			return $archive;
		}
		
	
		public function register_single_template( $single ) {

			global $post;
			
			if ( ! empty( $post ) && $post->post_type == $this->base ) {
				if ( ! file_exists( get_template_directory() . '/single-' . $this->base . '.php' ) ) {
					return MINFOLIO_CORE_PATH . 'public/portfolio/templates/single/single-' . $this->base . '.php';
				}
			}
			
			return $single;
		}

		/**
		 * Load admin Style & Javascript.	 	
		 */
		public function admin_enqueue_scripts() {
			
			$screen = get_current_screen();		
	
			if( $screen -> id == 'portfolio_page_sort_portfolio' ) {
				
				wp_enqueue_style( 'minfolio-sort-stylesheet', MINFOLIO_CORE_URL . 'admin/assets/css/sort-stylesheet.min.css', array(), MINFOLIO_CORE_VERSION );
				wp_enqueue_script( 'jquery-ui-sortable' );
				wp_enqueue_script( 'minfolio-sort-script', MINFOLIO_CORE_URL . 'admin/assets/js/sort-script.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );								
			}		
													
		}  // End admin_enqueue_scripts ()

				
		public function portfolio_posts_sort_callback() {
		
			$portfolio = new WP_Query( 'post_type=portfolio&posts_per_page=-1&orderby=menu_order&order=ASC' );
		
		?>

			<div class="wrap">
				<h3><?php esc_html_e( 'Sort Porfolio', 'minfolio' ); ?><img src="<?php echo esc_url( home_url('/') ); ?>wp-admin/images/loading.gif" id="loading-animation" /></h3>
					<ul id="slide-list">
						<?php if( $portfolio -> have_posts() ) : ?>
							<?php while ( $portfolio -> have_posts() ) { $portfolio -> the_post(); ?>
								<li id="<?php the_id(); ?>"><?php the_title(); ?></li>			
							<?php } ?>
						<?php else : ?>
							<li><?php esc_html_e( 'There is no Portfolio Created', 'minfolio' ); ?></li>		
						<?php endif; ?>
					</ul>
			</div>

		<?php
		}

		public function portfolio_posts_sort_order() {
		
			global $wpdb;
		
			$order = explode( ',', $_POST['order'] );
			$counter = 0;
		
			foreach ( $order as $slide_id ) {
				$wpdb -> update( $wpdb->posts, array( 'menu_order' => $counter ), array( 'ID' => $slide_id ) );
				$counter++;
			}
		
			wp_die();

		}		

		public function add_body_classes( $classes ) {

			if ( is_singular( 'portfolio' ) ) {
			
				$page_layout = minfolio_get_post_meta( 'portfolio_page_layout' );
				$page_details_placement = minfolio_get_post_meta( 'details_placement' );		
				$media_section_switch = minfolio_get_post_meta( 'media_section_switch' );
				
				$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );
				
				if( $portfolio_project_type == 'lightbox' ) {			
					$page_details_placement = 'details-bottom';
				}

				if( $media_section_switch == 1 ) {			
					$classes[] = 'portfolio-media';
				}				
				
				$classes[] = $page_layout;
				$classes[] = 'portfolio-' . $page_details_placement;

			}	
			
			return $classes;
			
		}

		public function modify_portfolio_prev_sort( $sort ) {
	
			global $wpdb;
		 
			if( !is_admin() && is_singular( 'portfolio' ) ) {	
		
				$orderby = minfolio_get_core_option( 'portfolio-order-by' ); 	
				
				if( $orderby == 'date' ) {
					$orderby = 'post_date';
				}
				elseif( $orderby == 'ID' ) {
					$orderby = 'ID';
				}
				elseif( $orderby == 'title' ) {
					$orderby = 'post_title';
				}
				elseif( $orderby == 'modified' ) {
					$orderby = 'post_modified';
				}
				elseif( $orderby == 'menu_order' ) {
					$orderby = 'menu_order';
				}
				else {
					$orderby = 'post_date';
				}
		
				$sort = " ORDER BY p.$orderby DESC LIMIT 1 ";		
			}
			
			return $sort;
		}

			public function modify_portfolio_next_sort( $sort ) {
	
			global $wpdb;
		 
			if( !is_admin() && is_singular( 'portfolio' ) ) {	
		
				$orderby = minfolio_get_core_option( 'portfolio-order-by' ); 	
				
				if( $orderby == 'date' ) {
					$orderby = 'post_date';
				}
				elseif( $orderby == 'ID' ) {
					$orderby = 'ID';
				}
				elseif( $orderby == 'title' ) {
					$orderby = 'post_title';
				}
				elseif( $orderby == 'modified' ) {
					$orderby = 'post_modified';
				}
				elseif( $orderby == 'menu_order' ) {
					$orderby = 'menu_order';
				}
				else {
					$orderby = 'post_date';
				}
		
				$sort = " ORDER BY p.$orderby ASC LIMIT 1 ";		
			}
			
			return $sort;
		}


		public function modify_portfolio_join( $join ) {
	
			global $wpdb;
		 
			if( !is_admin() && is_singular( 'portfolio' ) ) {	
				$join = " INNER JOIN $wpdb->postmeta AS pm ON pm.post_id = p.ID ";
			}
			
			return $join;
		}

		public function modify_portfolio_where( $where ) {	
 	
			if( !is_admin() && is_singular( 'portfolio' ) ) {	
				$where .= " AND pm.meta_key = 'clbr_meta_portfolio_project_type' AND pm.meta_value != 'lightbox' ";
			}
			
			return $where;
			
		}
		
	

	}

	new Minfolio_Portfolio_Register();

}