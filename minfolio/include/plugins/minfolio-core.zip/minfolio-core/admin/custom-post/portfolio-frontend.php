<?php

if( ! class_exists( 'Minfolio_Portfolio_FrontEnd' ) ) {	 

	class Minfolio_Portfolio_FrontEnd {

		private static $instance = null;

		public function __construct() {

			add_action( 'wp_ajax_nopriv_minfolio_load_more_portfolio_items', array( $this, 'load_more_portfolio_items' ) );
			add_action( 'wp_ajax_minfolio_load_more_portfolio_items', array( $this, 'load_more_portfolio_items' ) );

		}	
		
		public static function getInstance() {

			if ( self::$instance == null ) {
				self::$instance = new Minfolio_Portfolio_FrontEnd();
			}
		
			return self::$instance;
		}
	
		public function load_more_portfolio_items() {

			check_ajax_referer( 'minfolio-secure-ajax', 'security' );

			global $post;

			$params = array();
			
			$params[ 'offset' ] = $_GET[ 'of' ];		
			$params[ 'orderby' ] = $_GET[ 'ob' ];	
			$params[ 'order' ] = $_GET[ 'od' ];		
			$params[ 'content_position' ] = $_GET[ 'cp' ];			
			$params[ 'portfolio_items_flag' ] = $_GET[ 'fp' ];
			$params[ 'exclude_portfolio' ] = $_GET[ 'ep' ];
			$params[ 'categories_flag' ] = $_GET[ 'fc' ];	
			$params[ 'exclude_categories' ] = $_GET[ 'ec' ];	
			
			$params[ 'content_alignment' ] = $_GET[ 'ca' ];
			$params[ 'overlay_caption_animation' ] = $_GET[ 'oa' ];
			$params[ 'under_image_caption_animation' ] = $_GET[ 'ua' ];
			
			$params[ 'portfolio_layout' ] = $_GET[ 'pl' ];		

			$params[ 'show_title' ] = $_GET[ 'st' ];						
			$params[ 'show_subtitle' ] = $_GET[ 'ss' ];	
				

			$query_array = $this->get_load_more_query_array( $params );
					
			$portfolio_query = new \WP_Query( $query_array );
	
			if( $portfolio_query -> have_posts() ) { 

				foreach ( $portfolio_query -> posts as $post ) {	
						
					setup_postdata( $post );

					$params[ 'portfolio_id' ] = get_the_ID();

					$portfolio_category = $this->get_category_array( $params );							
						
					$params[ 'term_string' ] = $portfolio_category[0];
					$params[ 'term_subtitle' ] = $portfolio_category[1];

					$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );						
					
					$portfolio_project_type_method = 'render_portfolio_' . $portfolio_project_type . '_items';

					$this->$portfolio_project_type_method( $params );

				} 
				
			}

			wp_reset_postdata();
		
			wp_die();

		}

		private function get_load_more_query_array( $params ) {

			$inherit_orderby = minfolio_get_core_option( 'portfolio-order-by' ); 
			$inherit_order = minfolio_get_core_option( 'portfolio-order-arrangement' );	

			$exclude_portfolio_items = null;
			$exclude_category_items = null;

			$orderby = $inherit_orderby;
			$order = $inherit_order;

			$offset = $params[ 'offset' ];

			if( $params[ 'exclude_portfolio' ] ) {	
				$exclude_portfolio_items  = explode( ',', $params[ 'exclude_portfolio' ] );
			}
			
			if( $params[ 'exclude_categories' ] ) {
				$exclude_category_items = explode( ',', $params[ 'exclude_categories' ] );
			}	
			
			if( $params[ 'orderby' ] != 'inherit' ) {
				$orderby = $params[ 'orderby' ];
			}
			
			if( $params[ 'order' ] != 'inherit' ) {
				$order = $params[ 'order' ];
			}
			
			$portfolio_count = wp_count_posts( 'portfolio' )->publish;	
								
			$tax_query = array();

			if( !empty( $exclude_category_items ) ) {		
					
				$tax_query[] = array(
									array(
										'taxonomy' => 'portfolio_category',
										'field'    => 'slug',
										'terms'    => $exclude_category_items,
										'operator' => ( $params[ 'categories_flag' ] == 'exclude' ) ? 'NOT IN' : 'IN'	
									)
								);	
									
			}			
			
					
			if( $params[ 'portfolio_items_flag' ] == 'exclude' ) {		
					
				$query_array = array(
					'post_type'		 => 'portfolio',			
					'posts_per_page' => $portfolio_count - $offset,
					'offset'		 => $offset,		
					'order'			 => $order,			
					'orderby'		 => $orderby,
					'post_status'	 => 'publish',
					'post__not_in'   => $exclude_portfolio_items,			
					'tax_query'		 =>	$tax_query
				);
			}
			else {
				
				$query_array = array(
					'post_type'		 => 'portfolio',			
					'posts_per_page' => $portfolio_count - $offset,
					'offset'		 => $offset,		
					'order'			 => $order,			
					'orderby'		 => $orderby,
					'post_status'	 => 'publish',
					'post__in'       => $exclude_portfolio_items,			
					'tax_query'		 =>	$tax_query
				);			
			}	

			return $query_array;		

		}

		public function get_archive_portfolio_items() {

			global $post;

			$queried_object = get_queried_object();
			$type = $queried_object->taxonomy;

			$params = array();		

			$params[ 'no_of_items' ] = -1;
			$params[ 'orderby' ] = 'date';	
			$params[ 'order' ] = 'ASC';	
			
			$params[ 'show_sub_category_filter' ] = 'yes';	
		
			$params[ 'content_position' ] = 'content-under-img';	
			$params[ 'content_alignment' ] = 'center';	
			$params[ 'overlay_caption_animation' ] = 'default-effect';	
			$params[ 'under_image_caption_animation' ] = 'zoom-effect';	
						
			$params[ 'portfolio_columns' ] = 3;
			$params[ 'portfolio_columns_tablet' ] = 2;
			$params[ 'portfolio_columns_mobile_extra' ] = 2;
			$params[ 'portfolio_columns_mobile' ] = 1;				
				
			$params[ 'portfolio_layout' ] = 'grid';
			$params[ 'filter_animation' ] = 'quicksand';
			$params[ 'vertical_space' ]  = '30';
			$params[ 'horizontal_space' ] = '30';

			$params[ 'show_title' ] = 'yes';	
			$params[ 'show_subtitle' ] = 'yes';	
					
			wp_enqueue_script( 'cubeportfolio' );
			wp_enqueue_script( 'magnific-popup' );
			wp_enqueue_script( 'minfolio-portfolio-script' );
			
			do_action( 'minfolio_enqueue_portfolio_scripts' );  

		?>

			<div class="clbr-portfolio-wrap">

				<?php if ( $type == 'portfolio_category' && $params[ 'show_sub_category_filter' ] ) { 

					$this->render_archive_category_filter( $queried_object, $params );

				} ?>

				<?php $this->render_archive_portfolio_container( $type, $queried_object, $params ); ?>

			</div>


		<?php
		}
				
		private function render_archive_category_filter( $category, $params ) {

			$sub_categories = get_terms( 'portfolio_category', array( 'parent' => $category->term_id, 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );		

			if ( !empty( $sub_categories ) ) { ?>		
			
				<div id="filters-container" class="cbp-l-filters-text text-left" >
	
					<div data-filter="*" class="cbp-filter-item-active cbp-filter-item">	
					 	<?php echo esc_html__( 'All', 'minfolio' ); ?>
					</div>
	
					<?php foreach ( $sub_categories as $key => $value ) { ?>
	
						<div data-filter=".<?php echo esc_attr( $value->slug ); ?>" class="cbp-filter-item">
							<?php echo esc_html( $value->name ); ?>										        
						</div>														
	
					<?php } ?>									
	
				</div>
				
			<?php }

		}

		private function render_archive_portfolio_container( $type, $queried_object, $params ) {

			global $post;

			$wrapper_classes = array( 'clbr-portfolio-archive', 'cbp' );

			$wrapper_classes[] = 'clbr-portfolio-' . $params[ 'content_position' ];	
			$wrapper_classes[] = $params[ 'portfolio_layout' ];		

			if( $params[ 'content_position' ] == 'content-under-img' ) {
				$wrapper_classes[] = $params[ 'under_image_caption_animation' ];		
			}
			else {
				$wrapper_classes[] = 'clbr-portfolio-' . $params[ 'overlay_caption_animation' ];		
			}

			$wrapper_classes = implode( ' ', $wrapper_classes );	

			$query_array = $this->get_archive_query_array( $type, $queried_object, $params );
					
			$portfolio_query = new \WP_Query( $query_array );

			if( $portfolio_query -> have_posts() ) { ?>

				<div class="<?php echo esc_attr( $wrapper_classes ); ?>" <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >
					
					<?php
					
						foreach ( $portfolio_query -> posts as $post ) {	
							
							setup_postdata( $post );

							$params[ 'portfolio_id' ] = get_the_ID();

							$portfolio_category = $this->get_category_array( $params );							
								
							$params[ 'term_string' ] = $portfolio_category[0];
							$params[ 'term_subtitle' ] = $portfolio_category[1];

							$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );						
														
							$portfolio_project_type_method = 'render_portfolio_' . $portfolio_project_type . '_items';

							$this->$portfolio_project_type_method( $params );

						} 
						
					?>

				</div><!--End #grid-container-->			

			<?php } else { ?>	

				<div>
					<h1 class="err-msg">
						<?php esc_html_e( 'No portfolio found for the category.', 'minfolio' ); ?>
					</h1>
				</div>

			<?php } 

			wp_reset_postdata();	

		}

		private function get_archive_query_array( $type, $queried_object, $params ) {

			$inherit_orderby = minfolio_get_core_option( 'portfolio-order-by' ); 
			$inherit_order = minfolio_get_core_option( 'portfolio-order-arrangement' );	

			$orderby = $inherit_orderby;
			$order = $inherit_order;		
			
			if( $params[ 'orderby' ] != 'inherit' ) {
				$orderby = $params[ 'orderby' ];
			}
			
			if( $params[ 'order' ] != 'inherit' ) {
				$order = $params[ 'order' ];
			}

			$tax_query = array();

			if( $type == 'portfolio_category' ) {

				$tax_query[] = array(
									array(
										'taxonomy' => 'portfolio_category',
										'field'    => 'slug',
										'terms'    => $queried_object->slug,
										'operator' => 'IN'	
									)
								);		
			}
			else {
		
				$tax_query[] = array(
									array(
										'taxonomy' => 'portfolio_tag',
										'field'    => 'slug',
										'terms'    => $queried_object->slug,
										'operator' => 'IN'	
									)
								);								
			}			
			
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $params[ 'no_of_items' ],
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',		
				'tax_query'		 =>	$tax_query
			);	

			return $query_array;

		}

		public function get_related_grid_portfolio_items() {

			$params = array();		

			$params[ 'no_of_items' ] = -1;
			$params[ 'orderby' ] = 'date';	
			$params[ 'order' ] = 'ASC';			
					
			$params[ 'content_position' ] = 'content-under-img';	
			$params[ 'content_alignment' ] = 'center';	
			$params[ 'overlay_caption_animation' ] = 'default-effect';	
			$params[ 'under_image_caption_animation' ] = 'zoom-effect';	
						
			$params[ 'portfolio_columns' ] = 3;
			$params[ 'portfolio_columns_tablet' ] = 2;
			$params[ 'portfolio_columns_mobile_extra' ] = 2;
			$params[ 'portfolio_columns_mobile' ] = 1;				
				
			$params[ 'portfolio_layout' ] = 'grid';			
			$params[ 'filter_animation' ] = 'quicksand';
			$params[ 'vertical_space' ]  = '30';
			$params[ 'horizontal_space' ] = '30';

			$params[ 'show_title' ] = 'yes';	
			$params[ 'show_subtitle' ] = 'yes';	

			wp_enqueue_script( 'cubeportfolio' );
			wp_enqueue_script( 'magnific-popup' );			
			
			do_action( 'minfolio_enqueue_portfolio_scripts' );  

		?>

			<div class="clbr-related-portfolio wrap">				

				<?php $this->render_related_portfolio_container( $params ); ?>

			</div>


		<?php
		}

		private function render_related_portfolio_container( $params ) {

			global $post;

			$wrapper_classes = array( 'clbr-related-portfolio-grid', 'cbp' );

			$wrapper_classes[] = 'clbr-portfolio-' . $params[ 'content_position' ];	
			$wrapper_classes[] = $params[ 'portfolio_layout' ];		

			if( $params[ 'content_position' ] == 'content-under-img' ) {
				$wrapper_classes[] = 'clbr-portfolio-' . $params[ 'under_image_caption_animation' ];		
			}
			else {
				$wrapper_classes[] = 'clbr-portfolio-' . $params[ 'overlay_caption_animation' ];		
			}

			$wrapper_classes = implode( ' ', $wrapper_classes );	

			$query_array = $this->get_related_query_array( $params );
					
			$portfolio_query = new \WP_Query( $query_array );

			if( $portfolio_query -> have_posts() ) { ?>

				<div class="<?php echo esc_attr( $wrapper_classes ); ?>" <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >
					
					<?php
					
						foreach ( $portfolio_query -> posts as $post ) {	
							
							setup_postdata( $post );

							$params[ 'portfolio_id' ] = get_the_ID();

							$portfolio_category = $this->get_category_array( $params );							
								
							$params[ 'term_string' ] = $portfolio_category[0];
							$params[ 'term_subtitle' ] = $portfolio_category[1];

							$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );						
														
							$portfolio_project_type_method = 'render_portfolio_' . $portfolio_project_type . '_items';

							$this->$portfolio_project_type_method( $params );

						} 
						
					?>

				</div><!--End #grid-container-->			

			<?php } else { ?>	

				<div>
					<h1 class="err-msg">
						<?php esc_html_e( 'No portfolio found for the category.', 'minfolio' ); ?>
					</h1>
				</div>

			<?php } 

			wp_reset_postdata();	

		}

		public function get_related_carousel_portfolio_items() {

			global $post;

			$params = array();		

			$params[ 'no_of_items' ] = -1;
			$params[ 'orderby' ] = 'date';	
			$params[ 'order' ] = 'ASC';		
					
			$params[ 'content_position' ] = 'content-overlay';	
			$params[ 'content_alignment' ] = 'center';	
			$params[ 'overlay_caption_animation' ] = 'boxed-effect';				
			$params[ 'pagination' ]	= 'yes';
			$params[ 'show_title' ] = 'yes';	
			$params[ 'show_subtitle' ] = 'yes';	
								
			wp_enqueue_script( 'flickity' );	
			wp_enqueue_script( 'magnific-popup' );	
			
			do_action( 'minfolio_enqueue_portfolio_scripts' );  

		?>

			<div class="clbr-related-portfolio wrap">			
				
				<?php

					$wrapper_classes = array( 'clbr-related-portfolio-carousel', 'clbr-portfolio-content-overlay' );
					$wrapper_classes[] = 'clbr-portfolio-' . $params[ 'overlay_caption_animation' ];						

					$wrapper_classes = implode( ' ', $wrapper_classes );

					$query_array = $this->get_related_query_array( $params );
						
					$portfolio_query = new \WP_Query( $query_array );

					if( $portfolio_query -> have_posts() ) { ?>

						<div id="portfolio-carousel-related" class="<?php echo esc_attr( $wrapper_classes ); ?>" <?php echo minfolio_build_data_attr( $this->get_carousel_data_attributes( $params ) ); ?> >
					
							<?php

								foreach ( $portfolio_query -> posts as $post ) {	
									
									setup_postdata( $post );

									$params[ 'portfolio_id' ] = get_the_ID();						

									$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );						
									
									$portfolio_project_type_method = 'render_portfolio_carousel_' . $portfolio_project_type . '_items';

									$this->$portfolio_project_type_method( $params );

								} 
								
							?>																	
							
						</div><!--End #carousel-container-->

			<?php } else { ?>	

				<div>
					<h1 class="err-msg">
						<?php esc_html_e( 'No portfolio items added, Please add from admin.', 'minfolio' ); ?>
					</h1>
				</div>

			<?php } 

			wp_reset_postdata();	

			?>

		</div>

		<?php
		}


		private function get_related_query_array( $params ) {

			$inherit_orderby = minfolio_get_core_option( 'portfolio-order-by' ); 
			$inherit_order = minfolio_get_core_option( 'portfolio-order-arrangement' );	

			$orderby = $inherit_orderby;
			$order = $inherit_order;		
			
			if( $params[ 'orderby' ] != 'inherit' ) {
				$orderby = $params[ 'orderby' ];
			}
			
			if( $params[ 'order' ] != 'inherit' ) {
				$order = $params[ 'order' ];
			}

			$no_of_items = -1;

			$current_portfolio_id = get_the_ID();

			$include_categories = '';
			$include_portfolios = '';			
					
			$related_portfolio_filter = minfolio_get_post_meta( 'related_portfolio_filter' );
				
			if( $related_portfolio_filter == 'category' ) {				
				$include_categories = minfolio_get_post_meta( 'related_portfolio_filterby_category' );	
				$include_portfolios = array();	
			}
			else {				
				$include_portfolios = minfolio_get_post_meta( 'related_portfolio_filterby_portfolio', true );								
			}		
		
			$tax_query = array();

			if( !empty( $include_categories ) ) {		

				$tax_query[] = array(
									array(
										'taxonomy' => 'portfolio_category',
										'field'    => 'id',
										'terms'    => explode( ',', $include_categories ),
										'operator' => 'IN'	
									)
								);	
			}

			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__not_in'   => array( $current_portfolio_id ),			
				'tax_query'		 =>	$tax_query,
				'post__in'       => $include_portfolios
			);


			return $query_array;

		}

		private function get_data_attributes( $params ) {
			
			$data_attr = array();	
			$options = array();						
					
			$options[ 'filters' ] = '#filters-container, [id^=filters-container-subcategory]';
			$options[ 'defaultFilter' ] = '*';
			$options[ 'layoutMode' ] = ( $params[ 'portfolio_layout' ] ) ? $params[ 'portfolio_layout' ] : 'grid';
			$options[ 'sortToPreventGaps' ] = true;
			$options[ 'animationType' ] = ( $params[ 'filter_animation' ] ) ? $params[ 'filter_animation' ] : '';
			$options[ 'gapHorizontal' ] = ( $params[ 'horizontal_space' ] ) ? intval( $params[ 'horizontal_space' ] ) : 0;
			$options[ 'gapVertical' ] = ( $params[ 'vertical_space' ] ) ? intval( $params[ 'vertical_space' ] ) : 0;
			$options[ 'gridAdjustment' ] = 'responsive';
			$options[ 'caption' ] = 'fadeIn';
			$options[ 'displayType' ] = 'default';
			$options[ 'displayTypeSpeed' ] = 100;
			$options[ 'mediaQueries' ] = [ 
											[ 'width' => 1025, 'cols' => isset( $params[ 'portfolio_columns' ] ) ?  intval( $params[ 'portfolio_columns' ] ) : 4 ],  
											[ 'width' => 790, 'cols' => isset( $params[ 'portfolio_columns_tablet' ] ) ?  intval( $params[ 'portfolio_columns_tablet' ] ) : 3 ],  
											[ 'width' => 680, 'cols' => isset( $params[ 'portfolio_columns_mobile_extra' ] ) ?  intval( $params[ 'portfolio_columns_mobile_extra' ] ) : 2 ],  
											[ 'width' => 600, 'cols' => isset( $params[ 'portfolio_columns_mobile' ] ) ?  intval( $params[ 'portfolio_columns_mobile' ] ) : 1 ],  
										];


			$data_attr[ 'data-cbp-options' ] = stripslashes( wp_json_encode( $options ) );		
			
			return $data_attr;
	
		}

		private function get_carousel_data_attributes( $params ) {

			$data_attr = array();	
			$options = array();								
                      
            $options[ 'prevNextButtons' ] = false;
		    $options[ 'pageDots' ] = true;
		    $options[ 'wrapAround' ] = true;
		    $options[ 'cellAlign' ] = 'center';
		    $options[ 'draggable' ] = true;
		    $options[ 'autoPlay' ] = true;
		    $options[ 'pauseAutoPlayOnHover' ] = false;
		    $options[ 'contain' ] = true;
		    $options[ 'bgLazyLoad' ] = 1;	
		    $options[ 'bypassCheck' ] = true;

			$data_attr[ 'data-flickity-options' ] = stripslashes( wp_json_encode( $options ) );
			
			return $data_attr;		
	
		}


		public function render_portfolio_page_items( $params ) { ?>	

			<div class="clbr-portfolio-item cbp-item <?php echo esc_attr( $params[ 'term_string' ] ); ?>" >
	
				<a <?php echo minfolio_build_tag_attr( $this->get_page_anchor_tag_attributes( $params ) ); ?> >       
	
					<?php 
						$this->render_portfolio_item_thumbnail( $params );						
						$this->render_portfolio_item_meta( $params ); 
					?>					
	
				</a>
	
			</div>
	
		<?php }
	
		public function render_portfolio_external_items( $params ) { ?>	
	
			<div class="clbr-portfolio-item cbp-item <?php echo esc_attr( $params[ 'term_string' ] ); ?>" >
	
				<a <?php echo minfolio_build_tag_attr( $this->get_external_anchor_tag_attributes( $params ) ); ?> >       
	
					<?php 
						$this->render_portfolio_item_thumbnail( $params );						
						$this->render_portfolio_item_meta( $params ); 
					?>				
	
				</a>
	
			</div>
	
		<?php }
	
		public function render_portfolio_lightbox_items( $params ) {
	
			$portfolio_lightbox_type = minfolio_get_post_meta( 'portfolio_lightbox_type' ); 
	
			$achor_method = 'get_lightbox_' . $portfolio_lightbox_type . '_anchor_tag_attributes';  
		
		?>
		
			<div class="clbr-portfolio-item cbp-item <?php echo esc_attr( $params[ 'term_string' ] ); ?>" >
		
				<a <?php echo minfolio_build_tag_attr( $this->$achor_method( $params ) ); ?> >
			
					<?php 
						$this->render_portfolio_item_thumbnail( $params );						
						$this->render_portfolio_item_meta( $params ); 
					?>				
		
				</a>
		
				<?php if( $portfolio_lightbox_type == 'gallery' ) {
					echo $this->get_lightbox_gallery_anchor_tags( $params );
				} ?>
		
		
			</div>
	
		<?php }
	
	
		private function render_portfolio_item_meta( $params ) {
	
			$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );
			$thumbnail_sub_title = minfolio_get_post_meta( 'thumbnail_sub_title' );				
				
			//set thumbnail title
			if ( empty( $thumbnail_title ) ) {			
				$thumbnail_title = get_the_title();
			}	
		
			//set thumbnail sub title
			if ( empty( $thumbnail_sub_title ) ) {			
				$thumbnail_sub_title = substr( $params[ 'term_subtitle' ], 0, -3 );
			}	
			
			if( $params[ 'show_title' ] || $params[ 'show_subtitle' ] ) { ?>
			
				<div class="clbr-portfolio-content-wrap clbr-portfolio-content-align-<?php echo esc_attr( $params[ 'content_alignment' ] ); ?>">      
					<div class="clbr-portfolio-content-body">
	
						<?php if( $params[ 'show_title' ] ) { ?>
							<h3 class="clbr-portfolio-title">
								<?php echo esc_html( $thumbnail_title ); ?>
							</h3>
						<?php } ?>
	
						<?php if( $params[ 'show_subtitle' ] ) { ?>
							<div class="clbr-portfolio-desc">
								<?php echo esc_html( $thumbnail_sub_title ); ?>
							</div>
						<?php } ?>
	
					</div>
	
					<?php if( $params[ 'content_position' ] == 'content-overlay' && $params[ 'overlay_caption_animation' ] == 'ribbon-effect' ) { ?>
						<i class="fas fa-chevron-right"></i>
					<?php } ?>
	
				</div>
			
			<?php }      
	
		}
	
		private function render_portfolio_item_thumbnail( $params ) { ?>
							
			<div class="clbr-portfolio-img-wrap">							
				<?php $this->render_thumbnail_image( $params ); ?>						
			</div>
	
		<?php }

	
		private function render_thumbnail_image( $params ) {
	
			if ( '' !== get_the_post_thumbnail() ) {
						
				$size = 'full';
													
				if( $params[ 'portfolio_layout' ] == 'grid' ) {
					$size = 'minfolio-portfolio-grid-image';
				}
				elseif( $params[ 'portfolio_layout' ] == 'masonry' ) {
					$size = 'minfolio-portfolio-masonry-image';
				}
													
				$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
						
				$portfolio_thumbnail = '';		
											
				$portfolio_thumbnail = get_the_post_thumbnail( null, $size );		
								
				if( $lazy_load == 1 ) {
											
					$portfolio_thumbnail = preg_replace( '/src/', ' src="data:image/gif;base64,R0lGODlhAQABAPAAAP///////yH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==" data-cbp-src', $portfolio_thumbnail, 1 );
								
					$portfolio_thumbnail = preg_replace( '/srcset/', 'data-cbp-srcset', $portfolio_thumbnail, 1 );
								
					$portfolio_thumbnail = preg_replace( '/sizes/', 'data-sizes', $portfolio_thumbnail, 1 );		
							
				}
				
				echo $portfolio_thumbnail;
													
			} else { ?>
				<img src="<?php echo MINFOLIO_CORE_URL . 'public/assets/images/portfolio-thumbnail.png'; ?>" />
			<?php }	?>
	
		<?php } 

		private function get_category_array( $params ) {

			$terms	= wp_get_post_terms( $params[ 'portfolio_id' ], 'portfolio_category' );			

			$term_string = '';
			$term_subtitle = '';

			$portfolio_category = array();
							
			if ( !empty( $terms ) ) {
									
				foreach ( $terms as $key => $value ) {
					$term_string   .= ' ' . $value->slug;	
					$term_subtitle .= $value->name . ' / ';				
				}
			}	

			$portfolio_category[0] = $term_string;
			$portfolio_category[1] = $term_subtitle;

			return $portfolio_category;

		}

		private function get_image_caption( $image_id ) {

			$attributes = [];	
				
			$attachment = get_post( $image_id );   
		
			$image_caption = $attachment->post_excerpt;

			return $image_caption;

		}

		////Carousel Functions
		private function render_portfolio_carousel_page_items( $params ) { ?>
		
			<div class="carousel-cell" >
				<div class="clbr-portfolio-item">
	
					<a <?php echo minfolio_build_tag_attr( $this->get_page_anchor_tag_attributes( $params ) ); ?> >     
					
						<?php 
	
							$thumbnail_type	= minfolio_get_post_meta( 'thumbnail_type' );						
														
							$thumbnail_type_method = 'render_portfolio_carousel_item_thumbnail_' . $thumbnail_type;
	
							$this->$thumbnail_type_method( $params );
	
						?>
					
						<?php $this->render_portfolio_carousel_item_meta( $params ); ?>  				
					</a>
	
				 </div>	
			</div>
	
		<?php }
	
		private function render_portfolio_carousel_external_items( $params ) { ?>
	
			<div class="carousel-cell" >
				<div class="clbr-portfolio-item">				
	
					<a <?php echo minfolio_build_tag_attr( $this->get_external_anchor_tag_attributes( $params ) ); ?> >    
	
						<?php 
	
							$thumbnail_type	= minfolio_get_post_meta( 'thumbnail_type' );						
														
							$thumbnail_type_method = 'render_portfolio_carousel_item_thumbnail_' . $thumbnail_type;
	
							$this->$thumbnail_type_method( $params );
	
						?>
	
						<?php $this->render_portfolio_carousel_item_meta( $params ); ?>  		
					</a>
	
				</div>		
			</div>
	
		<?php }
	
		private function render_portfolio_carousel_lightbox_items( $params ) {	
	
			$portfolio_lightbox_type = minfolio_get_post_meta( 'portfolio_lightbox_type' ); 
	
			$achor_method = 'get_lightbox_' . $portfolio_lightbox_type . '_anchor_tag_attributes';  
		
		?>
		
			<div class="carousel-cell" >
				<div class="clbr-portfolio-item">
		
					<a <?php echo minfolio_build_tag_attr( $this->$achor_method( $params ) ); ?> >	
						
						<?php 
	
							$thumbnail_type	= minfolio_get_post_meta( 'thumbnail_type' );						
														
							$thumbnail_type_method = 'render_portfolio_carousel_item_thumbnail_' . $thumbnail_type;
	
							$this->$thumbnail_type_method( $params );
	
						?>
	
						<?php $this->render_portfolio_carousel_item_meta( $params ); ?>  
	
					</a>
				
					<?php if( $portfolio_lightbox_type == 'gallery' ) {
						echo $this->get_lightbox_gallery_anchor_tags( $params );
					} ?>	
		
				</div>
			</div>		
	
		<?php }
	
		private function render_portfolio_carousel_item_meta( $params ) {
	
			$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );
			$thumbnail_sub_title = minfolio_get_post_meta( 'thumbnail_sub_title' );				
				
			//set thumbnail title
			if ( empty( $thumbnail_title ) ) {			
				$thumbnail_title = get_the_title();
			}	
	
			//set thumbnail sub title
			if ( empty( $thumbnail_sub_title ) ) {			
				$thumbnail_sub_title = substr( $params[ 'term_subtitle' ], 0, -3 );
			}	
			
			if( $params[ 'show_title' ] || $params[ 'show_subtitle' ] ) { ?>
			
				<div class="clbr-portfolio-content-wrap clbr-portfolio-content-align-<?php echo esc_attr( $params[ 'content_alignment' ] ); ?>">      
					<div class="clbr-portfolio-content-body">
	
						<?php if( $params[ 'show_title' ] ) { ?>
							<h3 class="clbr-portfolio-title">
								<?php echo esc_html( $thumbnail_title ); ?>
							</h3>
						<?php } ?>
	
						<?php if( $params[ 'show_subtitle' ] ) { ?>
							<div class="clbr-portfolio-desc">
								<?php echo esc_html( $thumbnail_sub_title ); ?>
							</div>
						<?php } ?>
	
					</div>
	
					<?php if( $params[ 'overlay_caption_animation' ] == 'ribbon-effect' ) { ?>
						<i class="fas fa-chevron-right"></i>
					<?php } ?>
	
				</div>
			
			<?php }      
	
		}
	
		private function render_portfolio_carousel_item_thumbnail_image( $params ) { 
							
			$post_id = get_the_ID();
	
			$background_img_url = '';    
		
			if ( '' !== get_the_post_thumbnail() ) {			
				$background_img_url = get_the_post_thumbnail_url( $post_id, 'full' );
			}
			else {			
				$background_img_url = MINFOLIO_CORE_URL . 'public/assets/images/portfolio-thumbnail.png';
			}
		
		
		?>	
			<div class="clbr-portfolio-img-wrap">	
				<div class="clbr-portfolio-img" data-flickity-bg-lazyload="<?php echo esc_url( $background_img_url ); ?>" ></div>											
			</div>	
	
		<?php }
	
		
		private function render_portfolio_carousel_item_thumbnail_video( $params ) {
	
			
			$thumbnail_video_entries = get_post_meta( get_the_ID(), 'clbr_meta_thumbnail_video_upload', false );
	
		?>
					
			<div class="clbr-portfolio-video-wrap">
				<video loop muted="muted" class="bgvid" data-play="hover">
	
					<?php if( $thumbnail_video_entries ) {
	
						foreach ( $thumbnail_video_entries as $thumbnail_video_entry ) { ?>
	
							<source src="<?php echo wp_get_attachment_url( $thumbnail_video_entry ); ?>" type="video/mp4">
	
					<?php }
	
					} ?>
			
				</video>
			</div>	
	
		<?php } 

		//End

		private function get_page_anchor_tag_attributes( $params ) {

			$attr = array();

			$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
			$attr[ 'class' ] = 'clbr-portfolio-caption page';
			$attr[ 'href' ] = get_the_permalink();
			$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

			return $attr;

		}


		private function get_external_anchor_tag_attributes( $params ) {

			$attr = array();
			$external_target = '';	   

			$external_url	= minfolio_get_post_meta( 'external_url' );
			$external_target = minfolio_get_post_meta( 'external_target' );  

			$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
			$attr[ 'class' ] = 'clbr-portfolio-caption external';
			$attr[ 'href' ] = $external_url;
			$attr[ 'target' ] = $external_target;
			$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

			return $attr;

		}

		private function get_lightbox_image_anchor_tag_attributes( $params ) {

			$image_url = '';		
			$portfolio_lightbox_style = minfolio_get_core_option( 'portfolio-lightbox-switch' ); 
			$images_array = get_post_meta( get_the_ID(), 'clbr_meta_lightbox_image_url', false );
			$show_image_caption = minfolio_get_post_meta( 'lightbox_image_show_caption' ); 	

			$image_caption = '';					
				
			foreach ( $images_array as $image ) {	
					
				if ( $show_image_caption ) {
					$image_caption = $this->get_image_caption( $image );
				}             			
						
				$image_url = wp_get_attachment_url( $image );					
			}
			
			$attr = array();			

			$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
			$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-image';
			$attr[ 'href' ] = $image_url;
			$attr[ 'data-elementor-open-lightbox' ] = 'yes';	
			$attr[ 'data-elementor-lightbox-title' ] = $image_caption;

			if( $portfolio_lightbox_style == 'multiple' ) {
				$attr[ 'data-elementor-lightbox-slideshow' ] = 'slide-show-all';
			}     

			$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

			return $attr;


		}

		private function get_lightbox_gallery_anchor_tag_attributes( $params ) {

			$image_url = '';	
				
			$portfolio_lightbox_style = minfolio_get_core_option( 'portfolio-lightbox-switch' ); 
			$images_array = get_post_meta( get_the_ID(), 'clbr_meta_lightbox_gallery_images', false );	
			$show_image_caption = minfolio_get_post_meta( 'lightbox_image_show_caption' ); 		

			$image_caption = '';						
				
			foreach ( $images_array as $image ) {
						
				if ( $show_image_caption ) {
					$image_caption = $this->get_image_caption( $image );
				}        			
					
				$image_url = wp_get_attachment_url( $image );

				break;		
			}

			$attr = array();			

			$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
			$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-gallery';
			$attr[ 'href' ] = $image_url;
			$attr[ 'data-elementor-open-lightbox' ] = 'yes';	
			$attr[ 'data-elementor-lightbox-title' ] = $image_caption;

			if( $portfolio_lightbox_style == 'multiple' ) {
				$attr[ 'data-elementor-lightbox-slideshow' ] = 'slide-show-all';
			}     
			else {
				$attr[ 'data-elementor-lightbox-slideshow' ] = 'slide-show-' . $params[ 'portfolio_id' ];
			}

			$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

			return $attr;

		}

		private function get_lightbox_gallery_anchor_tags( $params ) {	
			
			$gallery_images_markup = '';
			$flag_first = true;
			
			$portfolio_lightbox_style = minfolio_get_core_option( 'portfolio-lightbox-switch' ); 
			$images_array = get_post_meta( get_the_ID(), 'clbr_meta_lightbox_gallery_images', false );			
						
			$show_image_caption = minfolio_get_post_meta( 'lightbox_image_show_caption' ); 					
				
			foreach ( $images_array as $image ) {
					
				if( $flag_first ) {					
					$flag_first = false;							  
				}
				else {											
					
					$gallery_image_caption = '';
											
					if ( $show_image_caption ) {
						$gallery_image_caption = $this->get_image_caption( $image );
					}        					 			 
					
					$gallery_image_url = wp_get_attachment_url( $image );	
						
					$gallery_images_markup .= '<a href="' . esc_url( $gallery_image_url ) . '" class="lightbox-gallery" ';						
					$gallery_images_markup .= ( $gallery_image_caption )  ? ' data-elementor-lightbox-title="' . esc_attr( $gallery_image_caption ) . '"' : '';
					$gallery_images_markup .= ' data-elementor-open-lightbox="yes" ';						

					if( $portfolio_lightbox_style == 'multiple' ) {
						$gallery_images_markup .= ' data-elementor-lightbox-slideshow="slide-show-all" ';
					}
					else {
						$gallery_images_markup .= ' data-elementor-lightbox-slideshow="slide-show-' . $params[ 'portfolio_id' ] . '"';						
					}

					$gallery_images_markup .= '></a>';

				}
			}

			return $gallery_images_markup;

		}

		private function get_lightbox_video_anchor_tag_attributes( $params ) {

			$attr = array();	
					
			$video_url = minfolio_get_post_meta( 'lightbox_video_url' );		

			$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
			$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-video';
			$attr[ 'href' ] = $video_url;
			$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

			return $attr;

		}

		private function get_lightbox_audio_anchor_tag_attributes( $params ) {

			$attr = array();	
					
			$audio = minfolio_get_post_meta( 'lightbox_audio_url' );			
			$audio_url = 'https://w.soundcloud.com/player/?url='.$audio.'&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true';	

			$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
			$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-audio';
			$attr[ 'href' ] = $audio_url;
			$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

			return $attr;

		}	
	
	}

	Minfolio_Portfolio_FrontEnd::getInstance();

}