<?php

if ( ! function_exists( 'minfolio_check_portfolio_categories' ) ) {	

	function minfolio_check_portfolio_categories( $categories_flag, $category, $exclude_categories ) {
		
		$show_category = false;
				
		if( !empty( $exclude_categories ) ) {
			
			if( $categories_flag == 'exclude' ) { 

				if( !in_array( $category, $exclude_categories ) ) {
					$show_category = true;
				}			
			}
			else {

				if( in_array( $category, $exclude_categories ) ) {
					$show_category = true;
				}			
			}
		}
		else {
			$show_category = true;
		}
					
		return $show_category;
	}	
}

if ( ! function_exists( 'minfolio_build_data_attr' ) ) {	

	function minfolio_build_data_attr( $data_attr ) {

		$data_attrs_array = array();

		foreach ( $data_attr as $key => $value ) {

			if ( ! empty( $value ) ) {			
				$data_attrs_array[] = $key . '="' . esc_attr( $value ) . '"';				
			}
		}

		return implode( ' ', $data_attrs_array );	
	}
}

if ( ! function_exists( 'minfolio_build_tag_attr' ) ) {	

	function minfolio_build_tag_attr( $data_attr ) {

		$data_attrs_array = array();

		foreach ( $data_attr as $key => $value ) {

			if ( ! empty( $value ) ) {	
				
				if( $key == 'href' ) {
					$data_attrs_array[] = $key . '="' . esc_url( $value ) . '"';				
				}
				else {
					$data_attrs_array[] = $key . '="' . esc_attr( $value ) . '"';				
				}
			}
		}

		return implode( ' ', $data_attrs_array );	
	}
}



if ( ! function_exists( 'minfolio_get_shortcode_template_part' ) ) {	

    function minfolio_get_shortcode_template_part( $template, $shortcode, $slug = '', $params = array() ) {

        //HTML Content from template
        $html          = '';
        $template_path = MINFOLIO_CORE_PATH . 'public/page-builder/' . $shortcode;
        
        $temp = $template_path . '/' . $template;
            
        if ( is_array( $params ) && count( $params ) ) {
            extract( $params );
        }
        
        $template = '';
        
        if ( ! empty( $temp ) ) {
            if ( ! empty( $slug ) ) {
                $template = "{$temp}-{$slug}.php";
                
                if ( ! file_exists( $template ) ) {
                    $template = $temp . '.php';
                }
            } else {
                $template = $temp . '.php';
            }
        }
        
        if ( $template ) {
            ob_start();
            include( $template );
            $html = ob_get_clean();
        }
        
        return $html;


    }

}
