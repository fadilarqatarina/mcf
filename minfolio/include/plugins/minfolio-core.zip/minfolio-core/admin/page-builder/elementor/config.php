<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! class_exists( 'Minfolio_Elementor_Config' ) ) {	

	class Minfolio_Elementor_Config {
		
		private static $_instance = null;
		
		public $widgets;	

		public function __construct() {

			$this->widgets = [		
				'portfolio-section-config',							
				'portfolio-carousel-config',											
				'team-member-config',				
				'testimonial-config',
				'recent-posts-config',
				'video-modal-config',
				'pricing-box-config',
				'icon-box-config',
				'image-box-config',			
				'hero-slider-config',			
				'button-config',						
				'counter-config',	
				'process-config',		
				'sidebar-menu-config',	
				'contact-form-7-config',			
				'google-map-config'				
			];		
			
			// Check if Elementor installed and activated
			if ( ! did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', array( $this, 'admin_notice_missing_main_plugin' ) );
				return;
			}

			$this->include_files();

			// Add Plugin actions
			add_action( 'elementor/controls/controls_registered', array( $this, 'register_custom_controls' ), 11 );
			
			add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ) );
			
			add_action( 'elementor/widgets/register', array( $this, 'init_widgets' ) );			
						
			add_action( 'wp_enqueue_scripts',  array( $this, 'enqueue_elementor_styles' ) );

			add_action( 'minfolio_enqueue_styles', array( $this, 'enqueue_elementor_kit_styles' ) );		
			
		}	
		
		public static function instance() {

			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;

		}

		private function include_files() {

			require_once( MINFOLIO_CORE_PATH . 'admin/page-builder/elementor/controls/control-manager.php' );
			require_once( MINFOLIO_CORE_PATH . 'admin/page-builder/elementor/controls/populate-list.php' );	

		}
			
		public function add_elementor_widget_categories( $elements_manager ) {
			
			$category  = 'minfolio';

			$elements_manager->add_category(
				$category,
				array(
					'title' => esc_html__( 'Minfolio Elements', 'minfolio' ),
					'icon'  => 'fa fa-plug',
				)			
			);
		}
		
		public function init_widgets( $widgetsManager ) {

			foreach ( $this->widgets as $widget ) {
				
				$template_file = MINFOLIO_CORE_PATH . 'admin/page-builder/elementor/widgets/' . $widget . '.php';						
				
				if ( file_exists( $template_file ) ) {
					require_once $template_file;
				}
			}		
			
		}	
		
		public function admin_notice_missing_main_plugin() {

			if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

			$message = sprintf(
				/* translators: 1: Plugin name 2: Elementor */
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'minfolio' ),
				'<strong>' . esc_html__( 'Minfolio', 'minfolio' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'minfolio' ) . '</strong>'
			);

			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

		}

		public function enqueue_elementor_styles() {

			wp_enqueue_style( 'elementor-icons' );
				
			wp_enqueue_style( 'elementor-animations' );
				
			wp_enqueue_style( 'elementor-frontend' );

		}	
	
		public function enqueue_elementor_kit_styles() {

			$elementor_global_switch  = minfolio_get_option( 'elementor-global-switch' );

			if( $elementor_global_switch == 1 ) {
				\Elementor\Plugin::$instance->kits_manager->frontend_before_enqueue_styles();
			}

		}		

		public function register_custom_controls( $controls_manager ) {

			$controls_manager->register_control( 'populate-list', new \Minfolio_Populate_List_Control() );

		}			
		
	}

	Minfolio_Elementor_Config::instance();

}