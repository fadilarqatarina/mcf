<?php
/**
 * Registers the sidebar menu shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Sidebar_Menu extends Widget_Base {
	
	public function get_name() {
		return 'clbr-sidebar-menu-widget';
	}

	public function get_title() {
		return esc_html__( 'Sidebar Menu', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-menu-toggle';
	}
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	public function get_menus(){

        $list = [];
        $menus = wp_get_nav_menus();

        foreach( $menus as $menu ) {
            $list[ $menu->slug ] = $menu->name;
        }

        return $list;
    }

	protected function register_controls() {

		$this->start_controls_section(
			'section_menu_settings',
			[
				'label' => esc_html__( 'Menu settings', 'minfolio' ),
			]
		);

		$this->add_control(
            'sidebar_nav_menu',
            [
                'label'     => esc_html__( 'Select menu', 'minfolio' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->get_menus(),
            ]
        );
		
		$this->end_controls_section();			
							
		$this->start_controls_section(
			'section_menu_style',
			[
				'label' => esc_html__( 'Menu', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu' => 'background-color: {{VALUE}}',
				],				
			]
		);

		$this->add_responsive_control(
			'border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-sidebar-nav-menu' => 'border-style: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu' => 'border-color: {{VALUE}}',
				],		
				'condition' => [
									'border_style!' => 'none',
								]		
			]
		);
		
		$this->add_responsive_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-sidebar-nav-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-sidebar-nav-menu',
			]
		);


		$this->add_responsive_control(
			'box_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-sidebar-nav-menu' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);		
						
		$this->end_controls_section();		
		
		$this->start_controls_section(
			'section_menu_item_style',
			[
				'label' => esc_html__( 'Menu Item', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);				
				
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'item_typography',		
				'selector' => '{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li',
			]
		);

		$this->start_controls_tabs( 'menu_item_tabs_style' );

		$this->start_controls_tab(
			'menu_item_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'item_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li' => 'color: {{VALUE}}',
				],				
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'menu_item_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'item_hover_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li:hover' => 'color: {{VALUE}}',
				],				
			]
		);

		$this->add_control(
			'item_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li:hover' => 'background-color: {{VALUE}}',
				],				
			]
		);

		$this->add_responsive_control(
			'item_hover_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'menu_item_tab_active',
			[
				'label' =>esc_html__( 'Active', 'minfolio' ),
			]
		);

		$this->add_control(
			'item_active_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li.current-menu-item' => 'color: {{VALUE}}',
				],				
			]
		);

		$this->add_control(
			'item_active_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li.current-menu-item' => 'background-color: {{VALUE}}',
				],				
			]
		);

		$this->add_responsive_control(
			'item_active_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-sidebar-nav-menu .clbr-sidebar-nav-menu-list li.current-menu-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();		
		
		$this->end_controls_section();			

	}

	protected function render( $instance = [] ) {	

		$params = $this->get_settings_for_display();

	?>	
		<div class="clbr-sidebar-nav-menu">

			<?php 
				wp_nav_menu( array(		
					'menu_id'       => 'sidebar-menu',					
					'menu'        	=> $params[ 'sidebar_nav_menu' ],
					'menu_class' 	=> 'clbr-sidebar-nav-menu-list', 
					'after'    		=> '<i class="fas fa-chevron-right"></i>',
					'container'     => false,						
				) ); 
			?>	

        </div>

		

	<?php
	}
	
	
}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Sidebar_Menu() );
