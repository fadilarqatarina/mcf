<?php
/**
 * Registers the hero slider shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Hero_Slider extends Widget_Base {
	
	public function get_name() {
		return 'clbr-hero-slider-widget';
	}

	public function get_title() {
		return esc_html__( 'Hero Slider', 'minfolio' );
	}

	public function get_script_depends() {
		return [ 'flickity', 'flickity-fade', 'minfolio-frontend' ];
	}		

	public function get_icon() {		
		return 'eicon-slides';
	}		
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_slider_layout',
			[
				'label' => esc_html__( 'Layout', 'minfolio' ),
			]
		);			

		$this->add_control(
			'slider_type',
			[
				'label' => esc_html__( 'Choose Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style-1',
				'options' => [
								'style-1' => esc_html__( 'Slider Style 1', 'minfolio' ),
								'style-2' => esc_html__( 'Slider Style 2', 'minfolio' ),											
							],						
			]
		);


		$this->end_controls_section();

		
		$this->start_controls_section(
			'section_slider_content',
			[
				'label' => esc_html__( 'Slider Content', 'minfolio' ),
			]
		);			

		$slider = new Repeater();

		$slider->add_control(
            'slide_image', 
			[
				'label' => esc_html__( 'Slide Image', 'minfolio' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],				
				'placeholder' => esc_html__( 'Select slide image.', 'minfolio' ),			
            ]
        );

		$slider->add_control(
            'title', 
			[
                'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Title',
				'placeholder' => esc_html__( 'Enter the title here.', 'minfolio' ),			
				'label_block' => true,
            ]
        );

		$slider->add_control(
            'heading', 
			[
                'label' => esc_html__( 'Heading', 'minfolio' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'Heading',
				'placeholder' => esc_html__( 'Enter the heading here.', 'minfolio' ),			
				'label_block' => true,
            ]
        );		

		$slider->start_controls_tabs( 'slider_tabs_style' );

		$slider->start_controls_tab(
			'slider_tab_btn_1',
			[
				'label' =>esc_html__( 'Button 1', 'minfolio' ),				
			]
		);

		$slider->add_control(
			'btn_1_text',
			[
				'label' =>esc_html__( 'Label', 'minfolio' ),
				//'description' => 'Button 1 is only applicable for slider style 1',
				'type' => Controls_Manager::TEXT,
				'default' =>esc_html__( 'Learn more', 'minfolio' ),
				'placeholder' =>esc_html__( 'Learn more', 'minfolio' ),
				'dynamic' => [
                    'active' => true,
                ],
			]
		);


		$slider->add_control(
			'btn_1_url',
			[
				'label' =>esc_html__( 'URL', 'minfolio' ),				
				'type' => Controls_Manager::URL,
				'placeholder' => '',
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => '#',
				],
			]
		);

		$slider->add_control(
            'btn_1_size',
            [
                'label' =>esc_html__( 'Size', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'sm' => esc_html__( 'Small', 'minfolio' ),
                    'md' => esc_html__( 'Medium', 'minfolio' ),
					'lg' => esc_html__( 'Large', 'minfolio' ),
					'xl' => esc_html__( 'Extra Large', 'minfolio' ),
					'block' => esc_html__( 'Block', 'minfolio' ),
                ],             
            ]
        );

		$slider->end_controls_tab();

		$slider->start_controls_tab(
			'slider_tab_btn_2',
			[
				'label' =>esc_html__( 'Button 2', 'minfolio' ),				
			]
		);

		$slider->add_control(
			'btn_2_text',
			[
				'label' =>esc_html__( 'Label', 'minfolio' ),
				'description' => 'Button 2 is only applicable for slider style 1',
				'type' => Controls_Manager::TEXT,
				'default' =>esc_html__( 'View Work', 'minfolio' ),
				'placeholder' =>esc_html__( 'Learn more', 'minfolio' ),
				'dynamic' => [
                    'active' => true,
                ],
			]
		);


		$slider->add_control(
			'btn_2_url',
			[
				'label' =>esc_html__( 'URL', 'minfolio' ),
				'type' => Controls_Manager::URL,
				'placeholder' => '',
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => '#',
				],
			]
		);

		$slider->add_control(
            'btn_2_size',
            [
                'label' =>esc_html__( 'Size', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'sm' => esc_html__( 'Small', 'minfolio' ),
                    'md' => esc_html__( 'Medium', 'minfolio' ),
					'lg' => esc_html__( 'Large', 'minfolio' ),
					'xl' => esc_html__( 'Extra Large', 'minfolio' ),
					'block' => esc_html__( 'Block', 'minfolio' ),
                ],             
            ]
        );

		$slider->end_controls_tab();

		$slider->end_controls_tabs();

		$slider->add_control(
            'footer_title', 
			[
                'label' => esc_html__( 'Footer Title', 'minfolio' ),
				'description' => 'Footer title is only applicable for slider style 2',
				'type' => Controls_Manager::TEXT,
				'default' => 'Footer Title',
				'placeholder' => esc_html__( 'Enter the footer title here.', 'minfolio' ),			
				'label_block' => true,
				'separator' => 'before'
            ]
        );

		$this->add_control(
            'slider_data',
            [
                'label' => esc_html__( 'Slider Data', 'minfolio' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [ 'title' => 'Title 1', 'heading' => 'Heading 1' ],
                    [ 'title' => 'Title 2', 'heading' => 'Heading 2' ],
                    [ 'title' => 'Title 3', 'heading' => 'Heading 3' ],
                ],

                'fields' => $slider->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
		);
		
		$this->add_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'text-align: {{VALUE}};',	
					'{{WRAPPER}} .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'text-align: {{VALUE}};',					
				],		
				'default' => 'center',				
			]
		);	

		$this->add_control(
			'alignment_left',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'align-items: flex-start;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::before' => 'display: none;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::after' => 'display: block;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap' => 'margin-left: -15px;',					
					'{{WRAPPER}} .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'align-items: flex-start;',			
				],	
				'condition' => [
                    'alignment' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_center',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [			
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'align-items: center;',		
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::before' => 'display: block;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::after' => 'display: block;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap' => 'margin-left: 0;',								
					'{{WRAPPER}} .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'align-items: center;',						
				],	
				'condition' => [
                    'alignment' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'alignment_right',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'align-items: flex-end;',
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::before' => 'display: block;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::after' => 'display: none;',	
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap' => 'margin-right: -15px;',					
					'{{WRAPPER}} .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content' => 'align-items: flex-end;',
				],	
				'condition' => [
                    'alignment' => 'right',                    
                ]
			]
		);	
	
		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(			
				'name'     => 'slide_background',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-image .clbr-hero-slider-overlay, .clbr-hero-slider.style-2 .clbr-hero-slider-image .clbr-hero-slider-overlay',					
            )
        );	

		$this->add_control(
			'slide_background_opacity',
			[
				'label' => esc_html__( 'Opacity', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 0,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1,
						'step' => 0.01

					],					
				],				
				'selectors' => [ 
									'{{WRAPPER}} .clbr-hero-slider.style-1 .carousel-cell .clbr-hero-slider-overlay' => 'opacity: {{SIZE}};',
				 			     	'{{WRAPPER}} .clbr-hero-slider.style-2 .carousel-cell .clbr-hero-slider-overlay' => 'opacity: {{SIZE}};'			
							   ]
			]
		);					
				
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_slider_controls',
			[
				'label' => esc_html__( 'Slider Controls', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,		
			]
		);	
		
		$this->add_control(
			'tranisition_effect',
			[
				'label' => esc_html__( 'Transition effect', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'slide',
				'options' => [								
								'slide' => esc_html__( 'Slide', 'minfolio' ),
								'fade'  => esc_html__( 'Fade', 'minfolio' ),																
							],
				'condition'	=> [ 'slider_type'	=> 'style-1' ]			
			]
		);					
		
		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);	
		
		$this->add_control(
			'autoplay_delay',
			[
				'label' => esc_html__( 'Delay', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 5000,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 8000,
						'step' => 500
					],					
				],				
				'description' => esc_html__( 'Delay between transitions (in ms).', 'minfolio' ),
				'condition' => [
								  'autoplay' => 'yes',       								          
								]					
			]
		);
		
		$this->add_control(
			'disable_on_interaction',
			[
				'label' => esc_html__( 'Disable on interaction', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Set to No and autoplay will not be disabled after user interactions (swipes), it will be restarted every time after interaction.', 'minfolio' ),			
				'condition' => [
								  'autoplay' => 'yes',       								          
								]	
			]
		);
		
		
		$this->end_controls_section();	
		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);				

		$this->add_control(
            'title_heading',
            [
                'label' => esc_html__( 'Title', 'minfolio' ),
                'type' => Controls_Manager::HEADING,               
            ]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span, .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content > p' => 'color: {{VALUE}}',
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::before, .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span::after' => 'background-color: {{VALUE}}',

				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content > span, .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content > p',
			]
		);

		$this->add_control(
            'heading_heading',
            [
                'label' => esc_html__( 'Heading', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'heading_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content h1, .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content h1' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',				
				'selector' => '{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content h1, .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content h1',
			]
		);

		$this->add_control(
            'heading_footer_title',
            [
                'label' => esc_html__( 'Footer Title', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
				'condition'	=> [ 'slider_type'	=> 'style-2' ]	
            ]
		);

		$this->add_control(
			'footer_title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content span.footer-title' => 'color: {{VALUE}}',
				],	
				'condition'	=> [ 'slider_type'	=> 'style-2' ]					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'footer_title_typography',				
				'selector' => '{{WRAPPER}} .clbr-hero-slider.style-2 .clbr-hero-slider-wrap .clbr-hero-slider-content span.footer-title',
				'condition'	=> [ 'slider_type'	=> 'style-2' ]	
			]
		);
		
		$this->end_controls_section();
						
		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE				
			]
		);	
		
		$this->start_controls_tabs( 'buttons_tabs_style' );

		$this->start_controls_tab(
			'button_1_style',
			[
				'label' =>esc_html__( 'Button 1', 'minfolio' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_1_typography',				
				'selector' => '{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn',
			]
		);		

		$this->add_control(
            'btn_1_normal_heading',
            [
                'label' => esc_html__( 'Normal', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'btn_1_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn' => 'color: {{VALUE}}',
				],					
			]
		);

		$this->add_control(
			'btn_1_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn' => 'background-color: {{VALUE}}',
				],					
			]
		);

		$this->add_responsive_control(
			'btn_1_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'solid',
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_1_border_dimensions',
			[
				'label' 	=> esc_html__( 'Width', 'minfolio' ),
				'type' 		=> Controls_Manager::DIMENSIONS,
				'condition'	=> [
					'btn_1_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'btn_1_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn' => 'border-color: {{VALUE}}',
				],	
				'condition'	=> [ 'btn_1_border_style!'	=> 'none' ]							
			]
		);

		$this->add_responsive_control(
			'btn_1_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
            'btn_1_hover_heading',
            [
                'label' => esc_html__( 'Hover', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'btn_1_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn:hover' => 'color: {{VALUE}}',
				],					
			]
		);


		$this->add_control(
			'btn_1_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn:hover' => 'background-color: {{VALUE}}',
				],					
			]
		);

		$this->add_responsive_control(
			'btn_1_hover_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'solid',
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn:hover' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_1_hover_border_dimensions',
			[
				'label' 	=> esc_html__( 'Width', 'minfolio' ),
				'type' 		=> Controls_Manager::DIMENSIONS,
				'condition'	=> [
					'btn_1_hover_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn:hover' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'btn_1_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn:hover' => 'border-color: {{VALUE}}',
				],		
				'condition'	=> [ 'btn_1_hover_border_style!'	=> 'none' ]					
			]
		);

		$this->add_responsive_control(
			'btn_1_hover_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-1 .clbr-btn:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);	
		

		$this->end_controls_tab();

		$this->start_controls_tab(
			'button_2_style',
			[
				'label' =>esc_html__( 'Button 2', 'minfolio' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_2_typography',				
				'selector' => '{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn',
			]
		);		

		$this->add_control(
            'btn_2_normal_heading',
            [
                'label' => esc_html__( 'Normal', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'btn_2_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn' => 'color: {{VALUE}}',
				],					
			]
		);

		$this->add_control(
			'btn_2_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn' => 'background-color: {{VALUE}}',
				],					
			]
		);

		$this->add_responsive_control(
			'btn_2_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'solid',
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_2_border_dimensions',
			[
				'label' 	=> esc_html__( 'Width', 'minfolio' ),
				'type' 		=> Controls_Manager::DIMENSIONS,
				'condition'	=> [
					'btn_2_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'btn_2_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn' => 'border-color: {{VALUE}}',
				],	
				'condition'	=> [ 'btn_1_border_style!'	=> 'none' ]							
			]
		);

		$this->add_responsive_control(
			'btn_2_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
            'btn_2_hover_heading',
            [
                'label' => esc_html__( 'Hover', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'btn_2_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn:hover' => 'color: {{VALUE}}',
				],					
			]
		);

		$this->add_control(
			'btn_2_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn:hover' => 'background-color: {{VALUE}}',
				],					
			]
		);

		$this->add_responsive_control(
			'btn_2_hover_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'solid',
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn:hover' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'btn_2_hover_border_dimensions',
			[
				'label' 	=> esc_html__( 'Width', 'minfolio' ),
				'type' 		=> Controls_Manager::DIMENSIONS,
				'condition'	=> [
					'btn_2_hover_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn:hover' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'btn_2_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn:hover' => 'border-color: {{VALUE}}',
				],		
				'condition'	=> [ 'btn_1_hover_border_style!'	=> 'none' ]					
			]
		);

		$this->add_responsive_control(
			'btn_2_hover_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-hero-slider.style-1 .clbr-hero-slider-wrap .clbr-hero-slider-content .clbr-hero-slider-btn-wrap .clbr-btn-wrapper.clbr-hero-slider-btn-2 .clbr-btn:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);	

		$this->end_controls_tab();

		$this->end_controls_tabs();
	
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_pagination_style',
			[
				'label' => esc_html__( 'Pagination', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
				'condition'	=> [ 'slider_type'	=> 'style-1' ]	
			]
		);				

		$this->add_control(
			'pagination_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .flickity-page-dots .dot' => 'background-color: {{VALUE}}',						
				],					
			]
		);

		$this->add_control(
			'pagination_active_color',
			[
				'label' => esc_html__( 'Active Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-hero-slider.style-1 .flickity-page-dots .dot.is-selected' => 'background-color: {{VALUE}}',						
				],					
			]
		);


		$this->end_controls_section();
		

	}

	protected function render( $instance = [] ) {			

		$params = $this->get_settings_for_display();
		
		$this->add_render_attribute( 'wrapper', 'class', 'clbr-hero-slider' );		
		$this->add_render_attribute( 'wrapper', 'class', $params[ 'slider_type' ] );			
			
		$slider_type_method = 'render_slider_item_' . str_replace( '-', '_', $params[ 'slider_type' ] );

	?>
	
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >          
        	
			<?php foreach ( $params[ 'slider_data' ] as $slider_data_items => $item ) {					

				$this->$slider_type_method( $params, $item );					

			} ?>	
		           
        </div>

	<?php }

	private function render_slider_item_style_1( $params, $item ) {

		$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 

		if( $lazy_load === 1 ) {		
			$this->add_render_attribute( 'slide-image', 'data-flickity-bg-lazyload', $item[ 'slide_image' ][ 'url' ], true );		
		} else {
			$this->add_render_attribute( 'slide-image', 'style', 'background-image:url( ' . $item[ 'slide_image' ][ 'url' ] . ' )', true );		
		}


	?>

		<div class="carousel-cell" <?php echo $this->get_render_attribute_string( 'slide-image' ); ?> >			
            <div class="clbr-hero-slider-image">
                <div class="clbr-hero-slider-overlay"></div>
                <div class="clbr-hero-slider-wrap">
        	        <div class="clbr-hero-slider-content">

                        <span><?php echo esc_html( $item[ 'title' ] ); ?></span>
                        <h1><?php echo wp_kses_post( $item[ 'heading' ] ); ?></h1>    

						<?php $this->render_slider_item_buttons( $item ); ?>

                	</div>
            	</div>
	        </div>
        </div>

	<?php }	

	private function render_slider_item_style_2( $params, $item ) {

		$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
		
		if( $lazy_load === 1 ) {		
			$this->add_render_attribute( 'slide-image', 'data-flickity-bg-lazyload', $item[ 'slide_image' ][ 'url' ], true );		
		} else {
			$this->add_render_attribute( 'slide-image', 'style', 'background-image:url( ' . $item[ 'slide_image' ][ 'url' ] . ' )', true );		
		}		
		
	?>

		<div class="carousel-cell" <?php echo $this->get_render_attribute_string( 'slide-image' ); ?> >			
			<div class="clbr-hero-slider-image">
				<div class="clbr-hero-slider-overlay"></div>
				<div class="clbr-hero-slider-wrap">

					<div class="clbr-hero-slider-content">
                        <div class="clbr-hero-slider-content-spacer"></div>

                        <p><?php echo esc_html( $item[ 'title' ] ); ?></p>                        
						<h1><?php echo wp_kses_post( $item[ 'heading' ] ); ?></h1>   

                        <?php $this->render_slider_item_button( $item ); ?>

						<span class="footer-title"><?php echo esc_html( $item[ 'footer_title' ] ); ?></span>                        

                    </div>				

				</div>
			</div>
		</div>

	<?php }	
	
	private function render_slider_item_buttons( $item ) {

		$this->add_render_attribute( 'button-1', 'class', 'clbr-btn clbr-btn-' . $item[ 'btn_1_size' ], true );
		$this->add_render_attribute( 'button-2', 'class', 'clbr-btn clbr-btn-' . $item[ 'btn_2_size' ], true );		

	?>
		<div class="clbr-hero-slider-btn-wrap">

			<?php if( $item[ 'btn_1_text' ] ) { ?>

				<div class="clbr-btn-wrapper clbr-hero-slider-btn-1">
					<a href="<?php echo esc_url( $item[ 'btn_1_url' ][ 'url' ] ); ?>" <?php echo $this->get_render_attribute_string( 'button-1' ); ?>>
						<span><?php echo esc_html( $item[ 'btn_1_text' ] ); ?></span>
					</a>				
				</div>

			<?php } ?>

			<?php if( $item[ 'btn_2_text' ] ) { ?>

				<div class="clbr-btn-wrapper clbr-hero-slider-btn-2">
					<a href="<?php echo esc_url( $item[ 'btn_2_url' ][ 'url' ] ); ?>" <?php echo $this->get_render_attribute_string( 'button-2' ); ?>>
						<span><?php echo esc_html( $item[ 'btn_2_text' ] ); ?></span>
					</a>
				</div>

			<?php } ?>	

		</div>

	<?php }


	private function render_slider_item_button( $item ) { 

		$this->add_render_attribute( 'button-1', 'class', 'clbr-btn clbr-btn-' . $item[ 'btn_1_size' ], true );
		
	?>		
	
		<div class="clbr-hero-slider-btn-wrap">

			<?php if( $item[ 'btn_1_text' ] ) { ?>

				<div class="clbr-btn-wrapper clbr-hero-slider-btn-1">
					<a href="<?php echo esc_url( $item[ 'btn_1_url' ][ 'url' ] ); ?>" <?php echo $this->get_render_attribute_string( 'button-1' ); ?>>
						<span><?php echo esc_html( $item[ 'btn_1_text' ] ); ?></span>
					</a>				
				</div>

			<?php } ?>		

		</div>

	<?php }


	private function get_data_attributes( $params ) {

		$data_attr = array();
		$options = array();

		$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 
	
		if ( $params[ 'slider_type' ] === 'style-1' ) {			
			$options[ 'fade' ] = ( $params[ 'tranisition_effect' ] === 'fade' ) ? true : false;			
		}

		if( $params[ 'autoplay' ] == 'yes' ) {
			$options[ 'autoPlay' ]    = isset( $params[ 'autoplay_delay' ][ 'size' ] ) ? $params[ 'autoplay_delay' ][ 'size' ] : '3000';
			$options[ 'pauseAutoPlayOnHover' ]  = ( isset( $params[ 'disable_on_interaction' ] ) && $params[ 'disable_on_interaction' ] == 'yes' ) ? true : false;
		}
		
		$options[ 'wrapAround' ] = true;		
		$options[ 'bgLazyLoad' ] = ( $lazy_load ) ? 1 : false;
		$options[ 'pageDots' ] = ( $params[ 'slider_type' ] === 'style-1' ) ? true : false;
		$options[ 'prevNextButtons' ] = false;				
		$options[ 'draggable' ] = true;
		$options[ 'bypassCheck' ] = true;

		$data_attr[ 'data-flickity-options' ] = stripslashes( wp_json_encode( $options ) );
				
		return $data_attr;

	}	


}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Hero_Slider() );
