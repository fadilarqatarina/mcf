<?php

defined( 'ABSPATH' ) || exit;

class Minfolio_Populate_List_Control extends \Elementor\Base_Data_Control {

	public function get_type() {		
		return 'populate-list';		
	}	

	public function enqueue() {
		// script
		wp_register_script( 'minfolio-ajaxchoose-control',  MINFOLIO_CORE_URL . 'admin/assets/js/elementor/ajaxchoose.js' );
		wp_enqueue_script( 'minfolio-ajaxchoose-control' );
	}

	protected function get_default_settings() {
		return [
			'options' => [],
			'multiple' => false,
			'select2options' => [],
		];
	}

	public function content_template() {
		$control_uid = $this->get_control_uid();
		?>
		<div class="elementor-control-field">
			<label for="<?php echo esc_attr( $control_uid ); ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">
				<# var multiple = ( data.multiple ) ? 'multiple' : ''; #>
				<select 
					id="<?php echo esc_attr( $control_uid ); ?>" 
					class="elementor-megamenuajaxselect2" 
					type="megamenuajaxselect2" {{ multiple }} 
					data-setting="{{ data.name }}"
					data-ajax-url="<?php echo esc_attr('/{{data.options}}/'); ?>"
				>
				</select>
			</div>
		</div>
		<# if ( data.description ) { #>
			<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}


}