<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class Elementor_Widget_Minfolio_Counter extends Widget_Base {

	public function get_name() {
		return 'clbr-counter-widget';
	}

	public function get_title() {
		return esc_html__( 'Counter', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-counter';
	}	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	public function get_script_depends() {
		return [ 'jquery-numerator', 'minfolio-frontend' ];
	}

	public function get_keywords() {
		return [ 'counter' ];
	}

	
	protected function register_controls() {

		$this->start_controls_section(
			'section_counter',
			[
				'label' => esc_html__( 'Counter', 'minfolio' ),
			]
		);

		$this->add_control(
			'starting_number',
			[
				'label' => esc_html__( 'Starting Number', 'minfolio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 0,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'ending_number',
			[
				'label' => esc_html__( 'Ending Number', 'minfolio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 100,
				'dynamic' => [
					'active' => true,
				],
			]
		);

		$this->add_control(
			'prefix',
			[
				'label' => esc_html__( 'Number Prefix', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'placeholder' => 1,
			]
		);

		$this->add_control(
			'suffix',
			[
				'label' => esc_html__( 'Number Suffix', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'placeholder' => esc_html__( 'Plus', 'minfolio' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Cool Number', 'minfolio' ),
				'placeholder' => esc_html__( 'Cool Number', 'minfolio' ),
			]
		);

		$this->add_control(
            'counter_settings',
            [
                'label' => esc_html__( 'Settings', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);	

		$this->add_responsive_control(
			'position',
			[
				'label' =>esc_html__( 'Position', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'flex-end' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',		
				'selectors' => [
					'{{WRAPPER}} .clbr-counter' => 'justify-content: {{VALUE}};',
				],		
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',	
				'selectors' => [
					'{{WRAPPER}} .clbr-counter' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'thousand_separator',
			[
				'label' => esc_html__( 'Thousand Separator', 'minfolio' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => esc_html__( 'Show', 'minfolio' ),
				'label_off' => esc_html__( 'Hide', 'minfolio' ),
			]
		);

		$this->add_control(
			'thousand_separator_char',
			[
				'label' => esc_html__( 'Separator', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'condition' => [
					'thousand_separator' => 'yes',
				],
				'options' => [
					'' => 'Default',
					'.' => 'Dot',
					' ' => 'Space',
				],
			]
		);

		$this->add_control(
			'duration',
			[
				'label' => esc_html__( 'Animation Duration', 'minfolio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 2000,
				'min' => 100,
				'step' => 100,
			]
		);
		
		$this->add_control(
			'view',
			[
				'label' => esc_html__( 'View', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_number',
			[
				'label' => esc_html__( 'Number', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'number_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
					'{{WRAPPER}} .clbr-counter .clbr-counter-number-wrap .clbr-counter-number' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_number',				
				'selector' => '{{WRAPPER}} .clbr-counter .clbr-counter-number-wrap .clbr-counter-number',
			]
		);	

		$this->end_controls_section();

		$this->start_controls_section(
			'section_prefix_suffix',
			[
				'label' => esc_html__( 'Prefix/Suffix', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'prefix_suffix_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
					'{{WRAPPER}} .clbr-counter .clbr-counter-number-wrap .clbr-counter-number-prefix, .clbr-counter .clbr-counter-number-wrap .clbr-counter-number-suffix' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_prefix_suffix',				
				'selector' => '{{WRAPPER}} .clbr-counter .clbr-counter-number-wrap .clbr-counter-number-prefix, .clbr-counter .clbr-counter-number-wrap .clbr-counter-number-suffix',
			]
		);	

		$this->end_controls_section();

		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,			
				'selectors' => [
					'{{WRAPPER}} .clbr-counter .clbr-counter-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_title',		
				'selector' => '{{WRAPPER}} .clbr-counter .clbr-counter-title',
			]
		);		

		$this->end_controls_section();

	}

	
	protected function render() {

		$params = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-counter' );

		$this->add_render_attribute( 'counter', [
			'class' => 'clbr-counter-number',
			'data-duration' => $params['duration'],
			'data-to-value' => $params['ending_number'],
			'data-from-value' => $params['starting_number'],
		] );

		if ( ! empty( $params['thousand_separator'] ) ) {
			$delimiter = empty( $params['thousand_separator_char'] ) ? ',' : $params['thousand_separator_char'];
			$this->add_render_attribute( 'counter', 'data-delimiter', $delimiter );
		}
		

		?>

		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >

            <div class="clbr-counter-content">
                <div class="clbr-counter-number-wrap">
					<span class="clbr-counter-number-prefix"><?php echo esc_html( $params[ 'prefix' ] ); ?></span>
                    <span <?php echo $this->get_render_attribute_string( 'counter' ); ?> ><?php echo esc_html( $params[ 'starting_number' ] ); ?></span>
                    <span class="clbr-counter-number-suffix"><?php echo esc_html( $params[ 'suffix' ] ); ?></span>
                </div>

				<?php if ( $params[ 'title' ] ) { ?>
					<h3 class="clbr-counter-title" >
						<?php echo esc_html( $params[ 'title' ] ); ?>
					</h3>
				<?php } ?>

            </div>

        </div>		

		<?php
	}

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Counter() );
