<?php
/**
 * Registers the team member shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Team_Member extends Widget_Base {
	
	public function get_name() {
		return 'clbr-team-member-widget';
	}

	public function get_title() {
		return esc_html__( 'Team Member', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-person';
	}
			
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
			]
		);

		$this->add_control(
			'member_image',
			[
				'label' => esc_html__( 'Member Image', 'minfolio' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src()
				],				
			]
		);

		$this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'member_image_thumbnail',
                'default' => 'full',
            ]
        );

		$this->add_control(
			'member_name',
			[
				'label' => esc_html__( 'Member Name', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'John Doe', 'minfolio' )				
			]
		);
		
		$this->add_control(
			'member_position',
			[
				'label' => esc_html__( 'Member Position', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Software Engineer', 'minfolio' )				
			]
		);		

		$this->add_responsive_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',				
				'selectors' => [
					'{{WRAPPER}} .clbr-team-member' => 'text-align: {{VALUE}};',					
				],		
			]
		);

		$this->add_control(
			'alignment_left',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [
					'{{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-left: 30px;',			
					'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap img' => 'margin-right: auto;margin-left: 0;',									
				],	
				'condition' => [
                    'alignment' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_center',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [					
					'{{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-left: 0;padding-right: 0;',			
					'{{WRAPPER}} .clbr-team-member  .clbr-member-img-wrap img' => 'margin-right: auto;margin-left: auto;',								
				],	
				'condition' => [
                    'alignment' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'alignment_right',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'{{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-right: 30px;',			
					'{{WRAPPER}} .clbr-team-member  .clbr-member-img-wrap img' => 'margin-right: 0;margin-left: auto;',			
				],	
				'condition' => [
                    'alignment' => 'right',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_tablet_left',
			[
				'label' =>esc_html__( 'Tablet Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [
					'(tablet) {{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-left: 30px;',			
					'(tablet) {{WRAPPER}} .clbr-team-member .clbr-member-img-wrap img' => 'margin-right: auto;margin-left: 0;',									
				],	
				'condition' => [
                    'alignment_tablet' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_tablet_center',
			[
				'label' =>esc_html__( 'Tablet Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [	
					'(tablet) {{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-left: 0;padding-right: 0;',							
					'(tablet) {{WRAPPER}} .clbr-team-member  .clbr-member-img-wrap img' => 'margin-right: auto;margin-left: auto;',								
				],	
				'condition' => [
                    'alignment_tablet' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'alignment_tablet_right',
			[
				'label' =>esc_html__( 'Tablet Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'(tablet) {{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-right: 30px;',			
					'(tablet) {{WRAPPER}} .clbr-team-member  .clbr-member-img-wrap img' => 'margin-right: 0;margin-left: auto;',			
				],	
				'condition' => [
                    'alignment_tablet' => 'right',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_mobile_left',
			[
				'label' =>esc_html__( 'Mobile Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [
					'(mobile) {{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-left: 30px;',			
					'(mobile) {{WRAPPER}} .clbr-team-member .clbr-member-img-wrap img' => 'margin-right: auto;margin-left: 0;',									
				],	
				'condition' => [
                    'alignment_mobile' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_mobile_center',
			[
				'label' =>esc_html__( 'Mobile Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [				
					'(mobile) {{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-left: 0;padding-right: 0;',		
					'(mobile) {{WRAPPER}} .clbr-team-member  .clbr-member-img-wrap img' => 'margin-right: auto;margin-left: auto;',								
				],	
				'condition' => [
                    'alignment_mobile' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'alignment_mobile_right',
			[
				'label' =>esc_html__( 'Mobile Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'(mobile) {{WRAPPER}} .clbr-team-member .clbr-member-img-overlay' => 'padding-right: 30px;',			
					'(mobile) {{WRAPPER}} .clbr-team-member  .clbr-member-img-wrap img' => 'margin-right: 0;margin-left: auto;',			
				],	
				'condition' => [
                    'alignment_mobile' => 'right',                    
                ]
			]
		);	
		
		
		$this->end_controls_section();

		$this->start_controls_section(
			'overlay_info',
			[
				'label' => esc_html__( 'Overlay Info', 'minfolio' ),			
			]
		);

		$this->add_control(
			'overlay_info_text',
			[
				'label' => esc_html__( 'Info Text', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'FOLLOW ME', 'minfolio' ),							
			]
		);		

		$this->end_controls_section();
		
		$this->start_controls_section(
  			'member_social_profiles',
  			[
  				'label' => esc_html__( 'Social Profiles', 'minfolio' ),			
  			]
  		);

		$this->add_control(
			'enable_social_media_profiles',
			[
				'label' => esc_html__( 'Display Social Profiles?', 'minfolio' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'minfolio' ),
                'label_off' => esc_html__( 'Hide', 'minfolio' ),
                'return_value' => 'yes',
                'default' => 'yes',
			]
		);		

		$social = new Repeater();

        $social->add_control(
            'social_media_icon',
            [
                'label' => esc_html__( 'Icon', 'minfolio' ),
                'label_block' => true,
                'type' => Controls_Manager::ICONS,             
                'default' => [
					'value' => 'fab fa-facebook-f',
					'library' => 'fa-solid',
                ],
            ]
        );

        $social->add_control(
            'social_media_label',
            [
                'label' => esc_html__( 'Label', 'minfolio' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Facebook',
            ]
        );

        $social->add_control(
            'social_media_link',
            [
                'label' => esc_html__( 'Link', 'minfolio' ),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );	

		$this->add_control(
            'member_social_medias',
            [
                'label' => esc_html__( 'Add Icon', 'minfolio' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $social->get_controls(),
                'default' => [
                    [
                        'social_media_label' => esc_html__( 'Facebook', 'minfolio' ),
                        'social_media_icon' => [
							'value' => 'fab fa-facebook-f',
							'library' => 'fa-solid',
                        ],                        
                    ],
                    [
                        'social_media_label' => esc_html__( 'Twitter', 'minfolio' ),
                        'social_media_icon' => [
							'value' => 'fab fa-twitter',
							'library' => 'fa-solid',
						],                       
                    ],
                    [
                        'social_media_label' => esc_html__( 'LinkedIn', 'minfolio' ),
                        'social_media_icon' => [
							'value' => 'fab fa-linkedin-in',
							'library' => 'fa-solid',
						],                       
                    ],
					[
                        'social_media_label' => esc_html__( 'Behance', 'minfolio' ),
                        'social_media_icon' => [
							'value' => 'fab fa-behance',
							'library' => 'fa-solid',
						],                       
                    ],
                ],
                'title_field' => '{{{ social_media_label }}}',
                'condition' => [
                    'enable_social_media_profiles' => 'yes'
                ]
            ]
        );
	
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_member_name_style',
			[
				'label' => esc_html__( 'Name', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);						
		
		$this->add_control(
			'member_name_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-team-member .clbr-member-info .clbr-member-name' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'member_name_typography',				
				'selector' => '{{WRAPPER}} .clbr-team-member .clbr-member-info .clbr-member-name',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_member_position_style',
			[
				'label' => esc_html__( 'Position', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);								
		
		$this->add_control(
			'member_position_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-team-member .clbr-member-info .clbr-member-position' => 'color: {{VALUE}}',
				],			
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'member_position_typography',				
				'selector' => '{{WRAPPER}} .clbr-team-member .clbr-member-info .clbr-member-position',
			]
		);
	
		
		$this->end_controls_section();	
		
		$this->start_controls_section(
			'section_overlay_style',
			[
				'label' => esc_html__( 'Overlay Style', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);								
		
		$this->add_control(
			'overlay_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),	
				'type' => Controls_Manager::COLOR,			
				'selectors' => [
						'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay span' => 'color: {{VALUE}}',
				],			
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'overlay_text_typography',				
				'selector' => '{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay span',
			]
		);
		
		$this->add_control(
			'overlay_color',
			[
				'label' => esc_html__( 'Overlay Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay' => 'background-color: {{VALUE}}',
				],			
			]
		);
		
		$this->end_controls_section();			

		
		$this->start_controls_section(
			'section_social_style',
			[
				'label' => esc_html__( 'Social', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);								

		$this->start_controls_tabs( 'social_tabs_style' );

		$this->start_controls_tab(
			'social_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);
		
		$this->add_control(
			'social_icon_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay .clbr-member-social-profile a i' => 'color: {{VALUE}}',
						'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay .clbr-member-social-profile a svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],			
			]
		);	
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'social_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'social_icon_hover_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay .clbr-member-social-profile a:hover i' => 'color: {{VALUE}}',
						'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap .clbr-member-img-overlay .clbr-member-social-profile a:hover svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],			
			]
		);	


		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'section_member_image_style',
			[
				'label' => esc_html__( 'Image ', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);						

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
            'image_bottom_margin',
            [
                'label'         => esc_html__( 'Bottom Space', 'minfolio'),
                'type'          => Controls_Manager::SLIDER,
                'size_units'    => ['px', 'em'],              
                'selectors' => [
                    '{{WRAPPER}} .clbr-team-member .clbr-member-img-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );		
		
		$this->end_controls_section();				
		
	}

	protected function render( $instance = [] ) { 
		
		$params = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-team-member' );
		
	?>
		
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >

			<div class="clbr-member-img-wrap">
				
				<?php echo $this->render_member_image( $params ); ?>

				<div class="clbr-member-img-overlay">

					<span class="spacer"></span>

					<span><?php echo esc_html( $params[ 'overlay_info_text' ] ); ?></span>

					<?php $this->render_member_social_profiles( $params ); ?>
										
				</div>

			</div>

			<?php $this->render_member_info( $params ); ?>
			

		</div>
	
	
	<?php }

	private function render_member_image( $params ) {

		if ( ! empty( $params[ 'member_image' ][ 'url' ] ) ) {

			$this->add_render_attribute( 'image', 'src', $params[ 'member_image' ][ 'url' ] );
			$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $params[ 'member_image' ] ) );
			$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $params[ 'member_image' ] ) );

			$image_html = Group_Control_Image_Size::get_attachment_image_html( $params, 'member_image_thumbnail', 'member_image' );

			return $image_html;

		}

	}	

	private function render_member_info( $params ) { ?>

		<div class="clbr-member-info">
			<h3 class="clbr-member-name"><?php echo esc_html( $params[ 'member_name' ] ); ?></h3>
			<div class="clbr-member-position"><?php echo esc_html( $params[ 'member_position' ] ); ?></div>
		</div>

	<?php
	}

	private function render_member_social_profiles( $params ) { ?>

		<div class="clbr-member-social-profile">

			<?php foreach ( $params[ 'member_social_medias' ] as $media => $item ) { ?>

				<a href="<?php echo esc_url( $item[ 'social_media_link' ][ 'url' ] ); ?>" title="<?php echo esc_url( $item[ 'social_media_label' ] ); ?>" >
					<?php Icons_Manager::render_icon( $item[ 'social_media_icon' ], [ 'aria-hidden' => 'true' ] ); ?>				
				</a>

			<?php } ?>
			
		</div>		

	<?php }


}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Team_Member() );
