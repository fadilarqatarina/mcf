<?php
/**
 * Registers the pricing box shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Pricing_Box extends Widget_Base {
	
	public function get_name() {
		return 'clbr-pricing-box-widget';
	}

	public function get_title() {
		return esc_html__( 'Pricing Box', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-price-table';
	}
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {
		
		$this->start_controls_section(
			'section_header',
			[
				'label' => esc_html__( 'Header', 'minfolio' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'minfolio' ),								
			]
		);

		$this->add_control(
            'enable_featured',
            [
                'label' => esc_html__( 'Enable featured?', 'minfolio'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' =>esc_html__( 'Yes', 'minfolio' ),
                'label_off' =>esc_html__( 'No', 'minfolio' ),				
            ]
		);

		$this->add_control(
			'featured_label',
			[
				'label' => esc_html__( 'Featured Label', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'POPULAR', 'minfolio' ),				
				'condition'	=> [
					'enable_featured'	=> 'yes'
				]								
			]
		);

		$this->add_control(	
			'currency',
			[
				'label' => esc_html__( 'Currency', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '$', 'minfolio' ),				
				'separator' => 'before',				
			]
		);		
		
		$this->add_control(	
			'price',
			[
				'label' => esc_html__( 'Price', 'minfolio' ),				
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '29', 'minfolio' ),				
			]
		);		

		$this->add_control(	
			'duration',
			[
				'label' => esc_html__( 'Duration', 'minfolio' ),				
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Monthly', 'minfolio' ),				
			]
		);		

		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_features',
			[
				'label' => esc_html__( 'Features', 'minfolio' ),
			]
		);	

		$this->add_control(
			'features_content',
			[				
				'type' => Controls_Manager::WYSIWYG,				
				'label_block' => true,
				'default' => '<ul class="clbr-pricing-lists">
								<li>upto 30 photos</li>
                                <li>high quality camera</li>
                                <li>retouched photos</li>
                                <li>no photoproofing</li>
                                <li>no stylist assistance</li>
							 </ul>',								
			]
		);		


		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_buttton',
			[
				'label' => esc_html__( 'Button', 'minfolio' ),
			]
		);			
		
		$this->add_control(
			'btn_text',
			[
				'label' =>esc_html__( 'Label', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' =>esc_html__( 'Learn more', 'minfolio' ),
				'placeholder' =>esc_html__( 'Learn more', 'minfolio' ),
				'dynamic' => [
                    'active' => true,
                ],
			]
		);


		$this->add_control(
			'btn_url',
			[
				'label' =>esc_html__( 'URL', 'minfolio' ),
				'type' => Controls_Manager::URL,
				'placeholder' => '',
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => '#',
				],
			]
		);
		
		$this->add_control(
            'btn_size',
            [
                'label' =>esc_html__( 'Size', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'sm' => esc_html__( 'Small', 'minfolio' ),
                    'md' => esc_html__( 'Medium', 'minfolio' ),
					'lg' => esc_html__( 'Large', 'minfolio' ),
					'xl' => esc_html__( 'Extra Large', 'minfolio' ),
					'block' => esc_html__( 'Block', 'minfolio' ),
                ],             
            ]
        );

		$this->add_control(
            'btn_icon_heading',
            [
                'label' => esc_html__( 'Icon', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);
		
		$this->add_control(
            'btn_icon_switch',
            [
                'label' => esc_html__('Add icon? ', 'minfolio'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' =>esc_html__( 'Yes', 'minfolio' ),
                'label_off' =>esc_html__( 'No', 'minfolio' ),
            ]
		);
		
		$this->add_control(
			'btn_icon',
			[
				'label' =>esc_html__( 'Icon', 'minfolio' ),
				'type' => Controls_Manager::ICONS,			
				'label_block' => true,
				'default' => [
                    'value' => '',
				],		
				'condition'	=> [
					'btn_icon_switch'	=> 'yes'
				]		
			]
		);

        $this->add_control(
            'btn_icon_align',
            [
                'label' =>esc_html__( 'Icon Position', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' =>esc_html__( 'Before', 'minfolio' ),
                    'right' =>esc_html__( 'After', 'minfolio' ),
                ],     
				'condition'	=> [
					'btn_icon_switch'	=> 'yes'
				]	          
            ]
        );
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_pricing_box_style',
			[
				'label' => esc_html__( 'Box', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);					

		$this->add_control(
			'box_bg_color',
			[
				'label' =>esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing' => 'background-color: {{VALUE}};',					
				],
			]
		);

		$this->add_responsive_control(
			'box_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-pricing' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_border',
			[
				'label' =>esc_html__( 'Border Width', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-pricing' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],		
				'condition'	=> [
					'box_border_style!' => 'none'
				],		
			]
		);

		$this->add_control(
			'box_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing' => 'border-color: {{VALUE}}',
				],				
			]
		);	


		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-pricing' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-pricing',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_pricing_featured_box_style',
			[
				'label' => esc_html__( 'Featured Box', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);					

		$this->add_control(
			'featured_box_bg_color',
			[
				'label' =>esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-header .clbr-pricing-featured' => 'background-color: {{VALUE}};',					
				],
			]
		);

		$this->add_responsive_control(
			'featured_box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-pricing .clbr-pricing-header .clbr-pricing-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		

		$this->add_control(
			'featured_box_title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,			
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-header .clbr-pricing-featured' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'featured_box_title_typography',				
				'selector' => '{{WRAPPER}} .clbr-pricing .clbr-pricing-header .clbr-pricing-featured',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);						
		
		$this->add_control(
            'pricing_title_heading',
            [
                'label' => esc_html__( 'Title', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-header .clbr-pricing-title' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .clbr-pricing .clbr-pricing-header .clbr-pricing-title',
			]
		);

		$this->add_control(
            'pricing_price_heading',
            [
                'label' => esc_html__( 'Price', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-price-wrap .clbr-pricing-price' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',				
				'selector' => '{{WRAPPER}} .clbr-pricing .clbr-pricing-price-wrap .clbr-pricing-price',
			]
		);

		$this->add_control(
            'pricing_duration_heading',
            [
                'label' => esc_html__( 'Duration', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'duration_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-price-wrap .clbr-pricing-tenure' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'duration_typography',				
				'selector' => '{{WRAPPER}} .clbr-pricing .clbr-pricing-price-wrap .clbr-pricing-tenure',
			]
		);

		$this->add_control(
            'pricing_features_list_heading',
            [
                'label' => esc_html__( 'Features List', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_control(
			'features_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-content ul li' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'features_typography',				
				'selector' => '{{WRAPPER}} .clbr-pricing .clbr-pricing-content ul li',
			]
		);

		$this->add_control(
			'separator_color',
			[
				'label' => esc_html__( 'Separator Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-pricing .clbr-pricing-content ul li' => 'border-bottom-color: {{VALUE}}',
				],				
			]
		);	
		
		$this->end_controls_section();		

		$this->start_controls_section(
			'btn_section_style',
			[
				'label' =>esc_html__( 'Button', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'label' =>esc_html__( 'Typography', 'minfolio' ),
				'selector' => '{{WRAPPER}} .clbr-btn-wrapper .clbr-btn',
			]
		);

		$this->start_controls_tabs( 'btn_tabs_style' );

		$this->start_controls_tab(
			'btn_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_text_color',
			[
				'label' =>esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn' => 'color: {{VALUE}};',
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'btn_bg_color',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-btn-wrapper .clbr-btn',
            )
        );		
		
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_tab_button_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_hover_color',
			[
				'label' =>esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn:hover svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],
			]
		);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    array(
			    'name'     => 'btn_bg_hover_color',
			    'default' => '',
			    'selector' => '{{WRAPPER}} .clbr-btn-wrapper .clbr-btn:hover',
		    )
	    );
		
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'btn_text_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
     
		$this->add_control(
            'btn_border_heading',
            [
                'label' => esc_html__( 'Border', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_responsive_control(
			'btn_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'btn_border_dimensions',
			[
				'label' 	=> esc_html__( 'Width', 'minfolio' ),
				'type' 		=> Controls_Manager::DIMENSIONS,
				'condition'	=> [
					'btn_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'xs_tabs_button_border_style' );
		$this->start_controls_tab(
			'btn_tab_border_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_border_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'btn_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '' ,
					'left' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_tab_button_border_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);
		$this->add_control(
			'btn_hover_border_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn:hover' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'btn_border_radius_h',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
            'btn_shadow_heading',
            [
                'label' => esc_html__( 'Shadow', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->start_controls_tabs( 'btn_shadow_tabs_style' );

		$this->start_controls_tab(
			'btn_shadow_tabnormal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'btn_box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-btn-wrapper .clbr-btn',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_shadow_tab_button_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'btn_hover_box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-btn-wrapper .clbr-btn:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
            'btn_icon_style_heading',
            [
                'label' => esc_html__( 'Icon', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);

		$this->add_responsive_control(
			'btn_normal_icon_font_size',
			array(
				'label'      => esc_html__( 'Font Size', 'minfolio' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px', 'em', 'rem',
				),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn i'   => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn svg' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);
		$this->add_responsive_control(
			'btn_normal_icon_padding_left',
			[
				'label' => esc_html__( 'Add space after icon', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn i, {{WRAPPER}} .clbr-btn-wrapper .clbr-btn svg' => 'margin-right: {{SIZE}}{{UNIT}};',					
				],
				'condition' => [
					'btn_icon_align' => 'left'
				]
			]
		);
		$this->add_responsive_control(
			'btn_normal_icon_padding_right',
			[
				'label' => esc_html__( 'Add space before icon', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' =>1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper .clbr-btn i, {{WRAPPER}} .clbr-btn-wrapper .clbr-btn svg' => 'margin-left: {{SIZE}}{{UNIT}};',					
				],
				'condition' => [
					'btn_icon_align' => 'right'
				]
			]
		);

        $this->add_responsive_control(
            'btn_normal_icon_vertical_align',
            array(
                'label'      => esc_html__( 'Move icon  Vertically', 'minfolio' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array(
                    'px', 'em', 'rem',
                ),
                'range'      => array(
                    'px' => array(
                        'min' => -20,
                        'max' => 20,
                    ),
                    'em' => array(
                        'min' => -5,
                        'max' => 5,
                    ),
                    'rem' => array(
                        'min' => -5,
                        'max' => 5,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .clbr-btn-wrapper .clbr-btn i, {{WRAPPER}} .clbr-btn-wrapper .clbr-btn svg' => ' -webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}})',
                ),
            )
        );

		$this->end_controls_section();

		
		
	}

	protected function render( $instance = [] ) {

		$params = $this->get_settings_for_display();		
		
	?>

		<div class="clbr-pricing">
			<div class="clbr-pricing-header">

				<?php if( $params[ 'enable_featured' ] == 'yes' ) { ?>
					<span class="clbr-pricing-featured">
						<?php echo esc_html( $params[ 'featured_label' ] ); ?>
					</span>
				<?php } ?>

				<h3 class="clbr-pricing-title">
					<?php echo esc_html( $params[ 'title' ] ); ?>
				</h3>
			</div>
			<div class="clbr-pricing-price-wrap">
				<div class="clbr-pricing-price">
					<?php echo esc_html( $params[ 'currency' ] ); ?><?php echo esc_html( $params[ 'price' ] ); ?>					
				</div>
				<div class="clbr-pricing-tenure">
					<?php echo esc_html( $params[ 'duration' ] ); ?>
				</div>
			</div>
			<div class="clbr-pricing-content ">				
				<?php echo $this->parse_text_editor( $params[ 'features_content' ] ); ?>
			</div>

			<?php $this->render_button( $params ); ?>
			
		</div>

	<?php }		
	
	private function render_button( $params ) { 

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-pricing-btn-wrap clbr-btn-wrapper' );
		$this->add_render_attribute( 'button', 'class', 'clbr-pricing-btn clbr-btn' );
		

		if ( ! empty( $params[ 'btn_url' ][ 'url' ] ) ) {
			$this->add_link_attributes( 'button', $params[ 'btn_url' ] );			
		}
		
		if ( ! empty( $params[ 'btn_size' ] ) ) {
			$this->add_render_attribute( 'button', 'class', 'clbr-btn-' . $params[ 'btn_size' ] );
		}
		
		?>
		
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<a <?php echo $this->get_render_attribute_string( 'button' ); ?>>
				<?php $this->render_button_text( $params ); ?>
			</a>
		</div>	

	<?php }

	private function render_button_text( $params ) { ?>		

		<?php if ( ! empty( $params[ 'btn_icon_switch' ] ) && $params[ 'btn_icon_switch' ] == 'yes' ) { 
			
			$this->add_render_attribute( 'icon', 'class', 'clbr-btn-icon' );

			if ( ! empty( $params[ 'btn_icon_align' ] ) ) {
				$this->add_render_attribute( 'icon', 'class', 'clbr-btn-icon-' . $params[ 'btn_icon_align' ] );
			}						
			
		?>

			<?php if ( $params[ 'btn_icon_align' ] == 'right' ) { ?>
				<span><?php echo esc_html( $params[ 'btn_text' ] ); ?></span>
			<?php } ?>

			<?php if( ! empty( $params[ 'btn_icon' ][ 'value' ] ) ) { ?>
				<span <?php echo $this->get_render_attribute_string( 'icon' ); ?> >				
					<?php Icons_Manager::render_icon( $params[ 'btn_icon' ], [ 'aria-hidden' => 'true' ] ); ?>				
				</span>
			<?php } ?>

			<?php if ( $params[ 'btn_icon_align' ] == 'left' ) { ?>
				<span><?php echo esc_html( $params[ 'btn_text' ] ); ?></span>
			<?php } ?>

		<?php } else { ?> 

			<span><?php echo esc_html( $params[ 'btn_text' ] ); ?></span>		

		<?php } ?>


	<?php }

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Pricing_Box() );
