<?php
/**
 * Registers the portfolio carousel shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Portfolio_Carousel extends Widget_Base {
	
	public function get_name() {
		return 'clbr-portfolio-carousel-widget';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Carousel', 'minfolio' );
	}

	public function get_script_depends() {
		return [ 'flickity', 'minfolio-frontend' ];
	}		

	public function get_icon() {		
		return 'eicon-slider-push';
	}	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {

		$this->start_controls_section(
			'section_thumbnail_appearance',
			[
				'label' => esc_html__( 'Thumbnail Appearance', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,		
			]
		);		

		$this->add_control(
			'show_title',
			[
				'label' => esc_html__( 'Show title', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',		
			]
		);
		
		$this->add_control(
			'show_subtitle',
			[
				'label' => esc_html__( 'Show sub title', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',	
			]
		);				
				
		$this->add_control(
			'overlay_caption_animation',
			[
				'label' => esc_html__( 'Hover Effect', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'default-effect',
				'options' => [	
								'default-effect' => esc_html__( 'Default', 'minfolio' ),									
								'boxed-effect'	=> esc_html__( 'Boxed', 'minfolio' ),													
								'ribbon-effect'  => esc_html__( 'Ribbon', 'minfolio' ),			
							 ],						
			]
		);				
		
		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__( 'Content alignment', 'minfolio' ),				
				'type' => Controls_Manager::CHOOSE,
				'default' => 'center',			
				'options' => [
								'left'    => [
									'title' => esc_html__( 'Left', 'minfolio' ),
									'icon' => 'eicon-text-align-left',
								],
								'center' => [
									'title' => esc_html__( 'Center', 'minfolio' ),
									'icon' => 'eicon-text-align-center',
								],	
								'right' => [
									'title' => esc_html__( 'Right', 'minfolio' ),
									'icon' => 'eicon-text-align-right',
								],										
							],	
				'condition'   => [ 'overlay_caption_animation' => 'boxed-effect' ],									
			]
		);
		
		$this->end_controls_section();
		
				
		$this->start_controls_section(
			'section_query',
			[
				'label' => esc_html__( 'Query', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
					
		$this->add_control(
			'no_of_items',
			[
				'label' => esc_html__( 'No of items', 'minfolio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '',
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order by', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [									
								"date"		 => esc_html__( "Date", 'minfolio' ),
								"ID"		 => esc_html__( "ID", 'minfolio' ),
								"author"	 => esc_html__( "Author", 'minfolio' ),
								"title"		 => esc_html__( "Title", 'minfolio' ),
								"modified"	 => esc_html__( "Last Modified", 'minfolio' ),	
								"rand"		 => esc_html__( "Random", 'minfolio' ),				
								"menu_order" => esc_html__( "Custom Sort", 'minfolio' ),
								"inherit"	 => esc_html__( "Inherit", 'minfolio' ),
							 ],			
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order arrangement', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [									
								"ASC"		 => esc_html__( "Ascending", 'minfolio' ),
								"DESC"		 => esc_html__( "Descending", 'minfolio' ),
								"inherit"	 => esc_html__( "Inherit", 'minfolio' ),								
							 ],	
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'categories_flag',
			[
				'label' => esc_html__( 'Exclude/Include portfolio categories', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'exclude',
				'label_block' => true,
				'options' => [									
								"exclude"	=> esc_html__( "Exclude", 'minfolio' ),
								"include"	=> esc_html__( "Include", 'minfolio' ),									
							 ],			
			]
		);
		
		$this->add_control(
			'exclude_categories',
			[
				'label' => esc_html__( 'Portfolio categories', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,					
				'description' => esc_html__( 'Enter portfolio categories slug to exclude those records (Note: separate values by commas (,)). Example branding,mobile-app.', 'minfolio' ),				
			]
		);		
		
		$this->add_control(
			'portfolio_items_flag',
			[
				'label' => esc_html__( 'Exclude/Include portfolio items', 'minfolio' ),
				'label_block' => true,						
				'type' => Controls_Manager::SELECT,
				'default' => 'exclude',
				'options' => [									
								"exclude"	=> esc_html__( "Exclude", "minfolio" ),
								"include"	=> esc_html__( "Include", "minfolio" ),									
							 ],			
			]
		);
		
		$this->add_control(
			'exclude_portfolio',
			[
				'label' => esc_html__( 'Portfolio IDs', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,			
				'description' => esc_html__( 'Enter portfolio IDs to exclude those records (Note: separate values by commas (,)).Example 2533,231.', 'minfolio' ),				
			]
		);			
		
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_slide_settings',
			[
				'label' => esc_html__( 'Slide Settings', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,							
			]
		);	
		
		$this->add_responsive_control(
			'carousel_height',
			[
				'label' => esc_html__( 'Carousel height', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 450,
				],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 1000,
					],					
				],						
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-carousel.clbr-portfolio-content-overlay .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-img-wrap' => 'height: {{SIZE}}{{UNIT}}',					
				],			
			]
		);	
	
		$this->add_responsive_control(
			'no_of_slides',
			[
				'label' => esc_html__( 'No of Slides', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
						'step' => 0.5,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],				
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-carousel .flickity-slider .carousel-cell' => 'width: calc(100% / {{SIZE}}); flex-basis: calc(100% / {{SIZE}});',
				],			
			]
		);

		$this->add_responsive_control(
			'space_between_slides',
			[
				'label' => esc_html__( 'Space between slides', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],				
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],					
				],	
				'default' => [
					'unit' => 'px',
					'size' => 15,
				],			
				'description' => esc_html__( 'Distance between slides in px.', 'minfolio' ),		
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-carousel .flickity-slider .carousel-cell' => 'padding-inline-start: {{SIZE}}{{UNIT}}; padding-inline-end: {{SIZE}}{{UNIT}};',				
				],		
			]
		);

		$this->add_control(
			'slides_align',
			[
				'label' => esc_html__( 'Slides Alignment', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
								'left'   => esc_html__( 'Left', 'minfolio' ),
								'center' => esc_html__( 'Center', 'minfolio' ),																				
								'right'  => esc_html__( 'Right', 'minfolio' ),																				
							],					
			]
		);	

		$this->add_control(
			'group_slides',
			[
				'label' => esc_html__( 'Group Slides', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'no',			
				'description' => esc_html__( 'Enable this option if you want the navigation being mapped to grouped slides, not individual slides.', 'minfolio' ),												
			]
		);		

						
		$this->add_control(
			'loop',
			[
				'label' => esc_html__( 'Loop', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Set to true to enable continuous loop mode.', 'minfolio' ),												
			]
		);		

		$this->add_control(
			'free_mode',
			[
				'label' => esc_html__( 'Free Mode', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Enables free mode functionality.', 'minfolio' ),				
			]
		);		

		$this->add_control(
			'dragger',
			[
				'label' => esc_html__( 'Dragger', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'no',			
				'description' => esc_html__( 'Enables dragger functionality.', 'minfolio' ),				
			]
		);		
		
		$this->end_controls_section();		
		
		
		$this->start_controls_section(
			'section_carousel_controls',
			[
				'label' => esc_html__( 'Carousel Controls', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,					
			]
		);	
		
		$this->add_control(
			'navigation',
			[
				'label' => esc_html__( 'Show Navigation', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Show navigation on slider.', 'minfolio' ),				
			]
		);
		
		$this->add_responsive_control(
			'navigation_alignment',
			[
				'label' => esc_html__( 'Navigation alignment', 'minfolio' ),				
				'type' => Controls_Manager::CHOOSE,
				'default' => 'flex-end',			
				'options' => [
								'flex-start'    => [
									'title' => esc_html__( 'Left', 'minfolio' ),
									'icon' => 'eicon-text-align-left',
								],
								'center' => [
									'title' => esc_html__( 'Center', 'minfolio' ),
									'icon' => 'eicon-text-align-center',
								],	
								'flex-end' => [
									'title' => esc_html__( 'Right', 'minfolio' ),
									'icon' => 'eicon-text-align-right',
								],										
							],	
				'selectors' => [					
								'{{WRAPPER}} .clbr-portfolio-carousel .flickity-button-wrap' => 'justify-content: {{VALUE}};',						
							],				
				'condition'   => [ 'navigation' => 'yes' ],									
			]
		);
		
		$this->add_control(
			'pagination',
			[
				'label' => esc_html__( 'Show Pagination', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Show pagination on slider.', 'minfolio' ),							
			]
		);				
			
		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);	
		
		$this->add_control(
			'autoplay_delay',
			[
				'label' => esc_html__( 'Delay', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 5000,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 8000,
						'step' => 500
					],					
				],				
				'description' => esc_html__( 'Delay between transitions (in ms).', 'minfolio' ),
				'condition' => [
								  'autoplay' => 'yes',       								          
								]					
			]
		);
		
		$this->add_control(
			'disable_on_interaction',
			[
				'label' => esc_html__( 'Disable on interaction', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Set to No and autoplay will not be disabled after user interactions (swipes), it will be restarted every time after interaction.', 'minfolio' ),			
				'condition' => [
								  'autoplay' => 'yes',       								          
								]	
			]
		);
		
		$this->end_controls_section();		
				
		
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap .clbr-portfolio-content-body .clbr-portfolio-title' => 'color: {{VALUE}}',					
				],			
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap .clbr-portfolio-content-body .clbr-portfolio-title'							  
			]
		);
		
		$this->end_controls_section();			
		
		$this->start_controls_section(
			'section_subtitle_style',
			[
				'label' => esc_html__( 'Category/Sub Title', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap .clbr-portfolio-content-body .clbr-portfolio-desc' => 'color: {{VALUE}}',
				],			
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',				
				'selector' => '{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap .clbr-portfolio-content-body .clbr-portfolio-desc',
				
			]
		);				
		
		
		$this->end_controls_section();		

		$this->start_controls_section(
			'section_thumbnail_style',
			[
				'label' => esc_html__( 'Thumbnail', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,					
			]
		);

		$this->add_responsive_control(
			'thumnail_image_border_radius',
			[
				'label' =>esc_html__( 'Image Roundness', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(		
				'label'	=> 'Overlay Color',
				'name'     => 'thumnail_overlay_color',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap',					
            )
        );	

		$this->add_responsive_control(
			'thumnail_overlay_border_radius',
			[
				'label' =>esc_html__( 'Overlay Roundness', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-carousel .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'thumnail_arrow_icon_color',
			[
				'label' => esc_html__( 'Arrow icon color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,							
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-section.clbr-portfolio-ribbon-effect .clbr-portfolio-item .clbr-clbr-portfolio-caption .clbr-portfolio-content-wrap i' => 'color: {{VALUE}}',
				],		
				'condition'   => [ 'overlay_caption_animation' => 'ribbon-effect' ],				
			]
		);


		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_navigation_style',
			[
				'label' => esc_html__( 'Navigation', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
				'condition'	=> [ 'navigation'	=> 'yes' ]	
			]
		);				

		$this->add_control(
			'navigation_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-carousel .flickity-button-wrap .flickity-prev-next-button' => 'border-color: {{VALUE}} !important',						
						'{{WRAPPER}} .clbr-portfolio-carousel .flickity-button-wrap button.flickity-button svg' => 'fill: {{VALUE}}',						
				],					
			]
		);		

		$this->end_controls_section();

		$this->start_controls_section(
			'section_pagination_style',
			[
				'label' => esc_html__( 'Pagination', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
				'condition'	=> [ 'pagination'	=> 'yes' ]	
			]
		);				

		$this->add_control(
			'pagination_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-carousel .flickity-page-dots .dot' => 'background-color: {{VALUE}}',						
				],					
			]
		);

		$this->add_control(
			'pagination_active_color',
			[
				'label' => esc_html__( 'Active Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-carousel .flickity-page-dots .dot.is-selected' => 'background-color: {{VALUE}}',						
				],					
			]
		);


		$this->end_controls_section();
		
	}

	protected function render( $instance = [] ) {

		global $post;

		$params = $this->get_settings_for_display();	
	
		$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-carousel' );
		$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-content-overlay' );					
	
		$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-' . $params[ 'overlay_caption_animation' ] );		
		
		
		$query_array = $this->get_query_array( $params );
					
		$portfolio_query = new \WP_Query( $query_array );

		if( $portfolio_query -> have_posts() ) { ?>

			<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >				
				
				<?php
					
					foreach ( $portfolio_query -> posts as $post ) {	
							
						setup_postdata( $post );

						$params[ 'portfolio_id' ] = get_the_ID();	

						$portfolio_category = $this->get_category_array( $params );							
							
						$params[ 'term_string' ] = $portfolio_category[0];
						$params[ 'term_subtitle' ] = $portfolio_category[1];

						$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );						
							
						$portfolio_project_type_method = 'render_portfolio_' . $portfolio_project_type . '_items';

						$this->$portfolio_project_type_method( $params );

					} 
						
				?>		
			
			</div><!--End #carousel-container-->

		<?php } else { ?>	

			<div>
				<h1 class="err-msg">
					<?php esc_html_e( 'No portfolio items added, Please add from admin.', 'minfolio' ); ?>
				</h1>
			</div>

		<?php } 

		wp_reset_postdata();	

	 }

	private function render_portfolio_page_items( $params ) { ?>
		
		<div class="carousel-cell" >
			<div class="clbr-portfolio-item">

				<a <?php echo minfolio_build_tag_attr( $this->get_page_anchor_tag_attributes( $params ) ); ?> >     
				
					<?php 

						$thumbnail_type	= minfolio_get_post_meta( 'thumbnail_type' );						
													
						$thumbnail_type_method = 'render_portfolio_item_thumbnail_' . $thumbnail_type;

						$this->$thumbnail_type_method( $params );

					?>
				
					<?php $this->render_portfolio_item_meta( $params ); ?>  				
				</a>

 			</div>	
		</div>

	<?php }

	private function render_portfolio_external_items( $params ) { ?>

		<div class="carousel-cell" >
			<div class="clbr-portfolio-item">				

				<a <?php echo minfolio_build_tag_attr( $this->get_external_anchor_tag_attributes( $params ) ); ?> >    

					<?php 

						$thumbnail_type	= minfolio_get_post_meta( 'thumbnail_type' );						
													
						$thumbnail_type_method = 'render_portfolio_item_thumbnail_' . $thumbnail_type;

						$this->$thumbnail_type_method( $params );

					?>

					<?php $this->render_portfolio_item_meta( $params ); ?>  		
				</a>

			</div>		
		</div>

	<?php }

	private function render_portfolio_lightbox_items( $params ) {	

		$portfolio_lightbox_type = minfolio_get_post_meta( 'portfolio_lightbox_type' ); 

		$achor_method = 'get_lightbox_' . $portfolio_lightbox_type . '_anchor_tag_attributes';  
	
	?>
	
		<div class="carousel-cell" >
			<div class="clbr-portfolio-item">
	
				<a <?php echo minfolio_build_tag_attr( $this->$achor_method( $params ) ); ?> >	
					
					<?php 

						$thumbnail_type	= minfolio_get_post_meta( 'thumbnail_type' );						
													
						$thumbnail_type_method = 'render_portfolio_item_thumbnail_' . $thumbnail_type;

						$this->$thumbnail_type_method( $params );

					?>

					<?php $this->render_portfolio_item_meta( $params ); ?>  

				</a>
			
				<?php if( $portfolio_lightbox_type == 'gallery' ) {
					echo $this->get_lightbox_gallery_anchor_tags( $params );
				} ?>	
	
			</div>
		</div>		

	<?php }

	private function render_portfolio_item_meta( $params ) {

		$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );
		$thumbnail_sub_title = minfolio_get_post_meta( 'thumbnail_sub_title' );				
			
		//set thumbnail title
		if ( empty( $thumbnail_title ) ) {			
			$thumbnail_title = get_the_title();
		}	

		//set thumbnail sub title
		if ( empty( $thumbnail_sub_title ) ) {			
			$thumbnail_sub_title = substr( $params[ 'term_subtitle' ], 0, -3 );
		}	
		
		if( $params[ 'show_title' ] || $params[ 'show_subtitle' ] ) { ?>
		
			<div class="clbr-portfolio-content-wrap clbr-portfolio-content-align-<?php echo esc_attr( $params[ 'content_alignment' ] ); ?>">      
				<div class="clbr-portfolio-content-body">

					<?php if( $params[ 'overlay_caption_animation' ] == 'default-effect' ) { ?>

						<div class="clbr-portfolio-content">

							<?php if( $params[ 'show_subtitle' ] ) { ?>
								<div class="clbr-portfolio-desc">
									<?php echo esc_html( $thumbnail_sub_title ); ?>
								</div>
							<?php } ?>

							<?php if( $params[ 'show_title' ] ) { ?>
								<h3 class="clbr-portfolio-title">
									<?php echo esc_html( $thumbnail_title ); ?>
								</h3>
							<?php } ?>

						</div>

					<?php } else { ?>

						<?php if( $params[ 'show_title' ] ) { ?>
							<h3 class="clbr-portfolio-title">
								<?php echo esc_html( $thumbnail_title ); ?>
							</h3>
						<?php } ?>

						<?php if( $params[ 'show_subtitle' ] ) { ?>
							<div class="clbr-portfolio-desc">
								<?php echo esc_html( $thumbnail_sub_title ); ?>
							</div>
						<?php } ?>
					
					<?php } ?>

				</div>

				<?php if( $params[ 'overlay_caption_animation' ] == 'default-effect' ) { ?>
					<div class="clbr-portfolio-icon">
        				<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M22.6666 9.33337L9.33331 22.6667" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							<path d="M10.6667 9.33337H22.6667V21.3334" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
    				</div>			
				<?php } ?>

				<?php if( $params[ 'overlay_caption_animation' ] == 'ribbon-effect' ) { ?>
					<i class="fas fa-chevron-right"></i>
				<?php } ?>

			</div>
		
		<?php }      

	}

	private function render_portfolio_item_thumbnail_image( $params ) { 
						
		$post_id = get_the_ID();
		$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 

		$background_img_url = '';    
	
		if ( '' !== get_the_post_thumbnail() ) {			
			$background_img_url = get_the_post_thumbnail_url( $post_id, 'full' );
		}
		else {			
			$background_img_url = MINFOLIO_CORE_URL . 'public/assets/images/portfolio-thumbnail.png';
		}
	
	
	?>	
		<div class="clbr-portfolio-img-wrap">

			<?php if( $lazy_load === 1 ) { ?>
				<div class="clbr-portfolio-img" data-flickity-bg-lazyload="<?php echo esc_url( $background_img_url ); ?>" ></div>				
			<?php } else { ?>
				<div class="clbr-portfolio-img" style="background-image: url( '<?php echo esc_url( $background_img_url ); ?>' )" ></div>				
			<?php } ?>

		</div>	

	<?php }

	
	private function render_portfolio_item_thumbnail_video( $params ) {

		
		$thumbnail_video_entries = get_post_meta( get_the_ID(), 'clbr_meta_thumbnail_video_upload', false );

	?>
				
		<div class="clbr-portfolio-video-wrap">
			<video loop muted="muted" class="bgvid" data-play="hover">

				<?php if( $thumbnail_video_entries ) {

					foreach ( $thumbnail_video_entries as $thumbnail_video_entry ) { ?>

						<source src="<?php echo wp_get_attachment_url( $thumbnail_video_entry ); ?>" type="video/mp4">

				<?php }

				} ?>
		
			</video>
		</div>	

	<?php } 
	

	private function get_query_array( $params ) {

		$inherit_orderby = minfolio_get_core_option( 'portfolio-order-by' ); 
		$inherit_order = minfolio_get_core_option( 'portfolio-order-arrangement' );	
		
		$no_of_items = -1;
		$exclude_portfolio_items = null;
		$exclude_category_items = null;

		$orderby = $inherit_orderby;
		$order = $inherit_order;

				
		if( !empty( $params[ 'no_of_items' ] ) ) {
			$no_of_items = $params[ 'no_of_items' ];
		}		
		
		if( $params[ 'orderby' ] != 'inherit' ) {
			$orderby = $params[ 'orderby' ];
		}
		
		if( $params[ 'order' ] != 'inherit' ) {
			$order = $params[ 'order' ];
		}
			
		if( $params[ 'exclude_portfolio' ] ) {	
			$exclude_portfolio_items  = explode( ',', $params[ 'exclude_portfolio' ] );
		}
		
		if( $params[ 'exclude_categories' ] ) {
			$exclude_category_items = explode( ',', $params[ 'exclude_categories' ] );
		}
		
		$tax_query = array();
			
		if( !empty( $exclude_category_items ) ) {		
				
			$tax_query[] = array(
								array(
									'taxonomy' => 'portfolio_category',
									'field'    => 'slug',
									'terms'    => $exclude_category_items,
									'operator' => ( $params[ 'categories_flag' ] == 'exclude' ) ? 'NOT IN' : 'IN'	
								)
							);	
								
		}
		
		if( $params[ 'portfolio_items_flag' ] == 'exclude' ) {		
					
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__not_in'   => $exclude_portfolio_items,			
				'tax_query'		 =>	$tax_query
			);
		}
		else {
				
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__in'       => $exclude_portfolio_items,			
				'tax_query'		 =>	$tax_query
			);			
		}	

		return $query_array;

	}

	private function get_data_attributes( $params ) {

		$data_attr = array();
		$options = array();	

		$lazy_load = minfolio_get_core_option( 'lazy-load-switch' ); 

		$options[ 'cellAlign' ] = ( $params[ 'slides_align' ] ) ? $params[ 'slides_align' ] : 'left';		
		$options[ 'groupCells' ] = ( $params[ 'group_slides' ] === 'yes' ) ? true : false;
		$options[ 'wrapAround' ] = ( $params[ 'loop' ] === 'yes' ) ? true : false;		
		$options[ 'freeScroll' ] = ( $params[ 'free_mode' ] === 'yes' ) ? true : false;					
		$options[ 'draggable' ] = ( $params[ 'dragger' ] === 'yes' ) ? true : false;
		$options[ 'prevNextButtons' ] = ( $params[ 'navigation' ] === 'yes' ) ? true : false;
		$options[ 'pageDots' ] =  ( $params[ 'pagination' ] === 'yes' ) ? true : false;
		$options[ 'bgLazyLoad' ] = ( $lazy_load ) ? 3 : false;
		$options[ 'bypassCheck' ] = true;

		if( $params[ 'autoplay' ] === 'yes' ) {
			$options[ 'autoPlay' ]    = isset( $params[ 'autoplay_delay' ][ 'size' ] ) ? $params[ 'autoplay_delay' ][ 'size' ] : '3000';
			$options[ 'pauseAutoPlayOnHover' ]  = ( isset( $params[ 'disable_on_interaction' ] ) && $params[ 'disable_on_interaction' ] == 'yes' ) ? true : false;
		}		

		$data_attr[ 'data-flickity-options' ] = stripslashes( wp_json_encode( $options ) );		
		
		return $data_attr;

	}	

	private function get_category_array( $params ) {

		$terms	= wp_get_post_terms( $params[ 'portfolio_id' ], 'portfolio_category' );			

		$term_string = '';
		$term_subtitle = '';

		$portfolio_category = array();
						 
		if ( !empty( $terms ) ) {
								
			foreach ( $terms as $key => $value ) {
				$term_string   .= ' ' . $value->slug;	
				$term_subtitle .= $value->name . ' / ';				
			}
		}	

		$portfolio_category[0] = $term_string;
		$portfolio_category[1] = $term_subtitle;

		return $portfolio_category;

	}

	
	private function get_image_caption( $image_id ) {

		$attributes = [];	
            
		$attachment = get_post( $image_id );   
	  
		$image_caption = $attachment->post_excerpt;

		return $image_caption;

	}

	private function get_page_anchor_tag_attributes( $params ) {

		$attr = array();

		$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
		$attr[ 'class' ] = 'clbr-portfolio-caption page';
		$attr[ 'href' ] = get_the_permalink();
		$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];				

		return $attr;

	}


	private function get_external_anchor_tag_attributes( $params ) {

		$attr = array();
		$external_target = '';	   

    	$external_url	= minfolio_get_post_meta( 'external_url' );
    	$external_target = minfolio_get_post_meta( 'external_target' );  
    
		$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
		$attr[ 'class' ] = 'clbr-portfolio-caption external';
		$attr[ 'href' ] = $external_url;
		$attr[ 'target' ] = $external_target;
		$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];	

		return $attr;

	}

	private function get_lightbox_image_anchor_tag_attributes( $params ) {

		$image_url = '';		
		$portfolio_lightbox_style = minfolio_get_core_option( 'portfolio-lightbox-switch' ); 
		$images_array = get_post_meta( get_the_ID(), 'clbr_meta_lightbox_image_url', false );
		$show_image_caption = minfolio_get_post_meta( 'lightbox_image_show_caption' ); 	

		$image_caption = '';					
			
		foreach ( $images_array as $image ) {	
				
		   	if ( $show_image_caption ) {
				$image_caption = $this->get_image_caption( $image );
			}            					
					
			$image_url = wp_get_attachment_url( $image );					
		}
		
		$attr = array();			

		$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
		$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-image';
		$attr[ 'href' ] = $image_url;
		$attr[ 'data-elementor-open-lightbox' ] = 'yes';	
		$attr[ 'data-elementor-lightbox-title' ] = $image_caption;

		if( $portfolio_lightbox_style == 'multiple' ) {
			$attr[ 'data-elementor-lightbox-slideshow' ] = 'slide-show-all';
		}     

		$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

		return $attr;

	}

	private function get_lightbox_gallery_anchor_tag_attributes( $params ) {

		$image_url = '';	
			
		$portfolio_lightbox_style = minfolio_get_core_option( 'portfolio-lightbox-switch' ); 
		$images_array = get_post_meta( get_the_ID(), 'clbr_meta_lightbox_gallery_images', false );	
	    $show_image_caption = minfolio_get_post_meta( 'lightbox_image_show_caption' ); 		

		$image_caption = '';						
			
		foreach ( $images_array as $image ) {
					
			if ( $show_image_caption ) {
				$image_caption = $this->get_image_caption( $image );
			}        							
				
			$image_url = wp_get_attachment_url( $image );

			break;		
		}

		$attr = array();			

		$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
		$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-gallery';
		$attr[ 'href' ] = $image_url;
		$attr[ 'data-elementor-open-lightbox' ] = 'yes';	
		$attr[ 'data-elementor-lightbox-title' ] = $image_caption;

		if( $portfolio_lightbox_style == 'multiple' ) {
			$attr[ 'data-elementor-lightbox-slideshow' ] = 'slide-show-all';
		}     
		else {
			$attr[ 'data-elementor-lightbox-slideshow' ] = 'slide-show-' . $params[ 'portfolio_id' ];
		}

		$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

		return $attr;

	}

	private function get_lightbox_gallery_anchor_tags( $params ) {	
		
		$gallery_images_markup = '';
		$flag_first = true;
		
		$portfolio_lightbox_style = minfolio_get_core_option( 'portfolio-lightbox-switch' ); 
		$images_array = get_post_meta( get_the_ID(), 'clbr_meta_lightbox_gallery_images', false );			
					
	    $show_image_caption = minfolio_get_post_meta( 'lightbox_image_show_caption' ); 							
			
		foreach ( $images_array as $image ) {
				
			if( $flag_first ) {					
				$flag_first = false;							  
			}
			else {											
				
				$gallery_image_caption = '';
										
			    if ( $show_image_caption ) {
					$gallery_image_caption = $this->get_image_caption( $image );
				}        							 			 
				
				$gallery_image_url = wp_get_attachment_url( $image );	
					
				$gallery_images_markup .= '<a href="' . esc_url( $gallery_image_url ) . '" class="cbp-gallery" ';						
			    $gallery_images_markup .= ( $gallery_image_caption )  ? ' data-elementor-lightbox-title="' . esc_attr( $gallery_image_caption ) . '"' : '';
				$gallery_images_markup .= ' data-elementor-open-lightbox="yes" ';						
	
				if( $portfolio_lightbox_style == 'multiple' ) {
					$gallery_images_markup .= ' data-elementor-lightbox-slideshow="slide-show-all" ';
				}
				else {
					$gallery_images_markup .= ' data-elementor-lightbox-slideshow="slide-show-' . $params[ 'portfolio_id' ] . '"';						
				}
	
				$gallery_images_markup .= '></a>';
	
			}
		}

		return $gallery_images_markup;

	}

	private function get_lightbox_video_anchor_tag_attributes( $params ) {

		$attr = array();	
                
		$video_url = minfolio_get_post_meta( 'lightbox_video_url' );		

		$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
		$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-video';
		$attr[ 'href' ] = $video_url;
		$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

		return $attr;
	}

	private function get_lightbox_audio_anchor_tag_attributes( $params ) {

		$attr = array();	
                
		$audio = minfolio_get_post_meta( 'lightbox_audio_url' );			
		$audio_url = 'https://w.soundcloud.com/player/?url='.$audio.'&amp;auto_play=true&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true';	

		$attr[ 'id' ] = 'item-' . $params[ 'portfolio_id' ];
		$attr[ 'class' ] = 'clbr-portfolio-caption lightbox-audio';
		$attr[ 'href' ] = $audio_url;
		$attr[ 'data-portfolio-id' ] = $params[ 'portfolio_id' ];

		return $attr;

	}


}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Portfolio_Carousel() );
