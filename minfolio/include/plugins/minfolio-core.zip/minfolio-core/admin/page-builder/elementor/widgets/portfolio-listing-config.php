<?php
/**
 * Registers the portfolio listing shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Portfolio_Listing extends Widget_Base {
	
	public function get_name() {
		return 'clbr-portfolio-listing-widget';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Listing', 'minfolio' );
	}	

	public function get_icon() {		
		return 'eicon-post-list';
	}	

	public function get_script_depends() {	
		return [ 'parallax', 'jquery-hoverplay', 'minfolio-frontend' ];
	}	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {
		
		$this->start_controls_section(
			'section_portfolio_listing',
			[
				'label' => esc_html__( 'Portfolio Listing', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);		
		
		$this->add_control(
			'listing_type',
			[
				'label' => esc_html__( 'Listing Layout', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'listing-vertical',
				'options' => [
								'listing-vertical' => esc_html__( 'Vertical', 'minfolio' ),																
								'listing-zigzag' => esc_html__( 'Zig Zag', 'minfolio' ),																
								'listing-vertical-alt' => esc_html__( 'Boxed', 'minfolio' ),	
								'listing-fullwidth-parallax' => esc_html__( 'Full Width Parallax', 'minfolio' ),																			
							 ],
				'description' => esc_html__( 'Set layout mode for portfolio listing.', 'minfolio' ),				
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'no_of_items',
			[
				'label' => esc_html__( 'No of items', 'minfolio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '',
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order by', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [									
								"date"		 => esc_html__( "Date", "minfolio" ),
								"ID"		 => esc_html__( "ID", "minfolio" ),
								"author"	 => esc_html__( "Author", "minfolio" ),
								"title"		 => esc_html__( "Title", "minfolio" ),
								"modified"	 => esc_html__( "Last Modified", "minfolio" ),	
								"rand"		 => esc_html__( "Random", "minfolio" ),				
								"menu_order" => esc_html__( "Custom Sort", "minfolio" ),
								"inherit"	 => esc_html__( "Inherit", "minfolio" ),
							 ],			
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order arrangement', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [									
								"ASC"		 => esc_html__( "Ascending", "minfolio" ),
								"DESC"		 => esc_html__( "Descending", "minfolio" ),
								"inherit"	 => esc_html__( "Inherit", "minfolio" ),								
							 ],	
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'categories_flag',
			[
				'label' => esc_html__( 'Exclude/Include portfolio categories', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'exclude',
				'label_block' => true,
				'options' => [									
								"exclude"	=> esc_html__( "Exclude", "minfolio" ),
								"include"	=> esc_html__( "Include", "minfolio" ),									
							 ],			
			]
		);
		
		$this->add_control(
			'exclude_categories',
			[
				'label' => esc_html__( 'Exclude portfolio categories', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,					
				'description' => esc_html__( 'Enter portfolio categories slug to exclude those records (Note: separate values by commas (,)). Example branding,mobile-app.', 'minfolio' ),		
				'separator' => 'after'
			]
		);		
		
		$this->add_control(
			'portfolio_items_flag',
			[
				'label' => esc_html__( 'Exclude/Include portfolio items', 'minfolio' ),
				'label_block' => true,						
				'type' => Controls_Manager::SELECT,
				'default' => 'exclude',
				'options' => [									
								"exclude"	=> esc_html__( "Exclude", "minfolio" ),
								"include"	=> esc_html__( "Include", "minfolio" ),									
							 ],			
			]
		);
		
		$this->add_control(
			'exclude_portfolio',
			[
				'label' => esc_html__( 'Exclude portfolio', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,			
				'description' => esc_html__( 'Enter portfolio IDs to exclude those records (Note: separate values by commas (,)).Example 2533,231.', 'minfolio' ),		
				'separator' => 'after'
			]
		);		
		
		$this->add_control(
			'portfolio_link_text',
			[
				'label' => esc_html__( 'Link Text', 'minfolio' ),				
				'type' => Controls_Manager::TEXT,
				'default' => 'View Project',		
				'description' => esc_html__( 'Portfolio Link Text.', 'minfolio'),			
			]
		);		
		
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_parallax_settings',
			[
				'label' => esc_html__( 'Parallax Settings', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,	
				'condition'   => [ 'listing_type' => 'listing-fullwidth-parallax' ],	
			]
		);	

		$this->add_control(
			'parallax_speed',
			[
				'label' => esc_html__( 'Parallax Speed', 'minfolio' ),				
				'type' => Controls_Manager::TEXT,
				'default' => '1',				
			]
		);			
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_link_style',
			[
				'label' => esc_html__( 'Link Style', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,	
				'condition'   => [ 'listing_type!' => 'listing-fullwidth-parallax' ],	
			]
		);			
		
		$this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Link color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .portfolio-listing-wrap .btn-container a' => 'color: {{VALUE}}',
				],				
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',				
				'selector' => '{{WRAPPER}} .portfolio-listing-wrap .btn-container a',
			]
		);
		
		$this->end_controls_section();	

		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button Style', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,	
				'condition'   => [ 'listing_type' => 'listing-fullwidth-parallax' ],	
			]
		);			
		
		$this->add_control(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'light',
				'options' => [									
								"light"	=> esc_html__( "Light", "minfolio" ),
								"dark"  => esc_html__( "Dark", "minfolio" ),									
							 ],										
			]
		);

		$this->end_controls_section();	
		
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title Style', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
						
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,					
				'selectors' => [
						'{{WRAPPER}} .portfolio-listing-wrap .portfolio-list .pl-content h1' => 'color: {{VALUE}}',
				],			
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .portfolio-listing-wrap .portfolio-list .pl-content h1',
			]
		);
		
		$this->end_controls_section();	
		
		$this->start_controls_section(
			'section_desc_style',
			[
				'label' => esc_html__( 'Sub Title / Description Style', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .portfolio-listing-wrap .portfolio-list .pl-content p' => 'color: {{VALUE}}',
				],			
			]
		);		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',				
				'selector' => '{{WRAPPER}} .portfolio-listing-wrap .portfolio-list .pl-content p',
			]
		);		
		
		$this->end_controls_section();		
	
	}


	protected function render( $instance = [] ) {
		
		global $post;		
		
		$params = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'portfolio-listing-wrap ' . $params[ 'listing_type' ] );

		if( $params[ 'listing_type' ] === 'listing-vertical' ) {
			$this->add_render_attribute( 'wrapper', 'class', 'effect-fade-in-up' );					
		}			
		
		$query_array = $this->get_query_array( $params );					
		$portfolio_query = new \WP_Query( $query_array );				
						
	?>

		<div id="widget-portfolio-listing" <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >

			<?php if( $portfolio_query -> have_posts() ) {
				
				foreach ( $portfolio_query -> posts as $post ) {	
					
					setup_postdata( $post );		

					// Post Vars			
					$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );					
						
					if( $params[ 'listing_type' ] === 'listing-vertical-alt' ) {	
						$this->portfolio_listing_boxed_item( $params );
					}
					elseif( $params[ 'listing_type' ] === 'listing-vertical' ) {	
						$this->portfolio_listing_vertical_item( $params );
					}			
					elseif( $params[ 'listing_type' ] === 'listing-zigzag' ) {
						$this->portfolio_listing_zigzag_item( $params );
					}		
					elseif( $params[ 'listing_type' ] === 'listing-fullwidth-parallax' ) {
						$this->portfolio_listing_fullwidth_parallax_item( $params );
					}	
					
				} 	
			
			} else { ?>
				
				<div>
					<h1 class="err-msg"><?php esc_html_e( 'No portfolio added, Please add from admin.', 'minfolio' ); ?></h1>
				</div>
				
			<?php }

			wp_reset_postdata();		
			
			?>
			
		</div>
		
<?php }

	
	private function portfolio_listing_boxed_item( $params ) {

		// Post Vars
		$post_id			= get_the_ID();		

		$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );	
		
		$thumbnail_type		= minfolio_get_post_meta( 'thumbnail_type' );		
		$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );				
		$thumbnail_desc		= minfolio_get_post_meta( 'thumbnail_desc' );			
		
		//set thumbnail title
		if ( empty( $thumbnail_title ) ) {			
			$thumbnail_title = get_the_title( $post_id );
		}										
		
		$external_target = '';		
		$portfolio_url = '';
					
		if( $portfolio_project_type === 'page' ) {			
			$portfolio_url = get_the_permalink();			
		}
		elseif( $portfolio_project_type === 'external' ) {
			
			$external_url	= minfolio_get_post_meta( 'external_url' );
			$external_target = minfolio_get_post_meta( 'external_target' );
			
			$portfolio_url = $external_url;
			$external_target = 'target=' . $external_target;
			
		}	

	?>

		<div class="portfolio-list">
		
			<div class="pl-content-wrap">
				<div class="pl-media">

					<a href="<?php echo esc_url( $portfolio_url ); ?>"  <?php echo esc_attr( $external_target ); ?> >		
		
						<?php if( $thumbnail_type === 'video-hover' ) {				
							$this->portfolio_item_thumbnail_video();							
						} 
						else {				

							if ( '' !== get_the_post_thumbnail() ) {

								$size = 'full';																		
								$this->portfolio_item_thumbnail_image( $size );
											
							} else { ?>
								<img src="<?php echo get_theme_file_uri( '/assets/images/portfolio-thumbnail.png' ); ?>" />
					<?php	}		

						} ?>
		
					</a>

				</div>

				<div class="pl-content">
		
					<h1><?php echo esc_html( $thumbnail_title ); ?></h1>
					<p><?php echo wp_kses_post( $thumbnail_desc ); ?></p>
	
					<div class="btn-container">
						<a href="<?php echo esc_url( $portfolio_url ); ?>" <?php echo esc_attr( $external_target ); ?> >
							<?php echo esc_html( $params[ 'portfolio_link_text' ] ); ?>
						</a>
					</div>

				</div>
			</div>';

		</div>

	<?php 
	}

	private function portfolio_listing_vertical_item( $params ) {

		// Post Vars
		$post_id			= get_the_ID();		

		$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );	
		
		$thumbnail_type		= minfolio_get_post_meta( 'thumbnail_type' );	
		$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );	
		$thumbnail_sub_title = minfolio_get_post_meta( 'thumbnail_sub_title' );						
					
		//set thumbnail title
		if ( empty( $thumbnail_title ) ) {			
			$thumbnail_title = get_the_title( $post_id );
		}										
			
		$external_target = '';		
		$portfolio_url = '';

						
		if( $portfolio_project_type === 'page' ) {				
			$portfolio_url = get_the_permalink();				
		}
		elseif( $portfolio_project_type === 'external' ) {
				
			$external_url	= minfolio_get_post_meta( 'external_url' );
			$external_target = minfolio_get_post_meta( 'external_target' );
				
			$portfolio_url = $external_url;
			$external_target = 'target=' . $external_target;
				
		}	

	?>
	
		<div class="portfolio-list">
			
			<div class="pl-content-wrap">
				<div class="pl-media">
	
					<a href="<?php echo esc_url( $portfolio_url ); ?>" <?php echo esc_attr( $external_target ); ?> >				
		
						<?php if( $thumbnail_type === 'video-hover' ) {				
							$this->portfolio_item_thumbnail_video();							
						}
						else {		

							if ( '' !== get_the_post_thumbnail() ) {		

								$size = 'full';						
												
								$this->portfolio_item_thumbnail_image( $size );
												
							} else { ?>
								<img src="<?php echo get_theme_file_uri( '/assets/images/portfolio-thumbnail.png' ); ?>" />
						<?php }								
						} 	?>	
			
					</a>
	
				</div>	

				<div class="pl-content">
	
					<p><?php echo esc_html( $thumbnail_sub_title ); ?></p>
					<h1><?php echo esc_html( $thumbnail_title ); ?></h1>

					<div class="btn-container">
						<a href="<?php echo esc_url( $portfolio_url ); ?>"  <?php echo esc_attr( $external_target ); ?> >
							<?php echo esc_html( $params[ 'portfolio_link_text' ] ); ?>
						</a>
					</div>
	
				</div>
			</div>
	
		</div>
	
	<?php }

	
	private function portfolio_listing_zigzag_item( $params ) {

		// Post Vars
		$post_id			= get_the_ID();		

		$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );	
		
		$thumbnail_type		= minfolio_get_post_meta( 'thumbnail_type' );	
		$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );				
		$thumbnail_desc		= minfolio_get_post_meta( 'thumbnail_desc' );			
			
		//set thumbnail title
		if ( empty( $thumbnail_title ) ) {			
			$thumbnail_title = get_the_title( $post_id );
		}										
		
		$external_target = '';		
		$portfolio_url = '';	
		
					
		if( $portfolio_project_type === 'page' ) {				
			$portfolio_url = get_the_permalink();				
		}
		elseif( $portfolio_project_type === 'external' ) {
				
			$external_url	= minfolio_get_post_meta( 'external_url' );
			$external_target = minfolio_get_post_meta( 'external_target' );
				
			$portfolio_url = $external_url;
			$external_target = 'target=' . $external_target;
			
		}	

	?>
	
		<div class="portfolio-list">
			
			<div class="pl-content-wrap">
				<div class="pl-media">
	
					<a href="<?php echo esc_url( $portfolio_url ); ?>" <?php echo esc_attr( $external_target ); ?> >

						<?php if( $thumbnail_type === 'video-hover' ) {	
			
							$this->portfolio_item_thumbnail_video();							
						}
						else {					

							if ( '' !== get_the_post_thumbnail() ) {
						
								$size = 'full';							
																
								$this->portfolio_item_thumbnail_image( $size );
																
							} else { ?>
								<img src="<?php echo get_theme_file_uri( '/assets/images/portfolio-thumbnail.png' ); ?>" />
						<?php }								

						} ?>
			
					</a>
	
				</div>
	
				<div class="pl-content">	
			
					<h1><?php echo esc_html( $thumbnail_title ); ?></h1>
					<p><?php echo wp_kses_post( $thumbnail_desc ); ?></p>
	
					<div class="btn-container">
						<a href="<?php echo esc_url( $portfolio_url ); ?>"  <?php echo esc_attr( $external_target ); ?> >
							<?php echo esc_html( $params[ 'portfolio_link_text' ] ); ?>
						</a>
					</div>
	
				</div>
			</div>
	
		</div>

	<?php }

	private function portfolio_listing_fullwidth_parallax_item( $params ) {

		// Post Vars
		$post_id = get_the_ID();	

		$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );	
		
		$thumbnail_type		= minfolio_get_post_meta( 'thumbnail_type' );	
		$thumbnail_title	= minfolio_get_post_meta( 'thumbnail_title' );				
		$thumbnail_sub_title = minfolio_get_post_meta( 'thumbnail_sub_title' );		
			
		//set thumbnail title
		if ( empty( $thumbnail_title ) ) {			
			$thumbnail_title = get_the_title( $post_id );
		}										
			
		$external_target = '';		
		$portfolio_url = '';
		
						
		if( $portfolio_project_type === 'page' ) {				
			$portfolio_url = get_the_permalink();				
		}
		elseif( $portfolio_project_type === 'external' ) {
				
			$external_url	= minfolio_get_post_meta( 'external_url' );
			$external_target = minfolio_get_post_meta( 'external_target' );
			
			$portfolio_url = $external_url;
			$external_target = 'target=' . $external_target;
				
		}	

	?>	

		<div class="portfolio-list">

		<?php 
		
			if( $thumbnail_type === 'video-hover' ) { ?>

				<div class="pl-content-wrap">
			
					<?php $this->portfolio_item_thumbnail_video(); 
			}
			else {					
				
				$background_img_url = '';
			
				if ( '' !== get_the_post_thumbnail() ) {					
					$background_img_url = get_the_post_thumbnail_url( $post_id, 'full' );
				}
				else {					
					$background_img_url = get_theme_file_uri( '/assets/images/portfolio-thumbnail.png' );
				}
			?>
			
			<div class="pl-content-wrap" data-parallax-bg-speed="<?php echo $parallax_speed; ?>" data-parallax-bg-image="<?php echo esc_url( $background_img_url ); ?>" >

		<?php } ?>
	
				<div class="pl-content">
				
					<p><?php echo esc_html( $thumbnail_sub_title ); ?></p>
					<h1><?php echo esc_html( $thumbnail_title ); ?></h1>

					<div class="button <?php echo $button_style; ?>">
						<a href="<?php echo esc_url( $portfolio_url ); ?>"  <?php echo esc_attr( $external_target ); ?> >
							<?php echo esc_html( $params[ 'portfolio_link_text' ] ); ?>
						</a>
					</div>

				</div>

			</div>

		</div>			

	<?php }

	private function portfolio_item_thumbnail_video() {	
		
		$thumbnail_video_entries = get_post_meta( get_the_ID(), 'clbr_meta_thumbnail_video_upload', false );
	?>				
		<div class="thumbnail-video-wrapper">
			<video loop muted="muted" class="bgvid" data-play="hover">

				<?php if( $thumbnail_video_entries ) {

					foreach ( $thumbnail_video_entries as $thumbnail_video_entry ) { ?>
						<source src="<?php echo wp_get_attachment_url( $thumbnail_video_entry ); ?>" type="video/mp4">
					<?php }
				} ?>
		
			</video>
		</div>			
					
	<?php }

	private	function portfolio_item_thumbnail_image( $size = 'post-thumbnail', $attr = '' ) {		

		$lazy_load = minfolio_get_option( 'lazy-load-switch' ); 

		$portfolio_thumbnail_markup = get_the_post_thumbnail( null, $size, $attr );	

		if( $lazy_load == 1 ) {	

			$portfolio_thumbnail_markup =  preg_replace( '/class="/', 'class="lazyload ', $portfolio_thumbnail_markup, 2 );
				
			$portfolio_thumbnail_markup = preg_replace( '/src/', 'data-src', $portfolio_thumbnail_markup, 1 );

			$portfolio_thumbnail_markup = preg_replace( '/srcset/', 'data-srcset', $portfolio_thumbnail_markup, 1 );
		
			$portfolio_thumbnail_markup = preg_replace( '/sizes/', 'data-sizes', $portfolio_thumbnail_markup, 1 );					

		}

	?>		
		<figure class="portfolio-thumbnail" >			
			<?php echo wp_kses_post( $portfolio_thumbnail_markup ); ?> 
		</figure>		
		
	<?php }

	private function get_query_array( $params ) {

		$inherit_orderby = minfolio_get_core_option( 'portfolio-order-by' ); 
		$inherit_order = minfolio_get_core_option( 'portfolio-order-arrangement' );	
		
		$no_of_items = -1;
		$exclude_portfolio_items = null;
		$exclude_category_items = null;

		$orderby = $inherit_orderby;
		$order = $inherit_order;

				
		if( !empty( $params[ 'no_of_items' ] ) ) {
			$no_of_items = $params[ 'no_of_items' ];
		}		
		
		if( $params[ 'orderby' ] != 'inherit' ) {
			$orderby = $params[ 'orderby' ];
		}
		
		if( $params[ 'order' ] != 'inherit' ) {
			$order = $params[ 'order' ];
		}
			
		if( $params[ 'exclude_portfolio' ] ) {	
			$exclude_portfolio_items  = explode( ',', $params[ 'exclude_portfolio' ] );
		}
		
		if( $params[ 'exclude_categories' ] ) {
			$exclude_category_items = explode( ',', $params[ 'exclude_categories' ] );
		}
		
		$tax_query = array();
			
		if( !empty( $exclude_category_items ) ) {		
				
			$tax_query[] = array(
								array(
									'taxonomy' => 'portfolio_category',
									'field'    => 'slug',
									'terms'    => $exclude_category_items,
									'operator' => ( $params[ 'categories_flag' ] == 'exclude' ) ? 'NOT IN' : 'IN'	
								)
							);	
								
		}
		
		if( $params[ 'portfolio_items_flag' ] == 'exclude' ) {		
					
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__not_in'   => $exclude_portfolio_items,			
				'tax_query'		 =>	$tax_query
			);
		}
		else {
				
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__in'       => $exclude_portfolio_items,			
				'tax_query'		 =>	$tax_query
			);			
		}	

		return $query_array;

	}




}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Portfolio_Listing() );
