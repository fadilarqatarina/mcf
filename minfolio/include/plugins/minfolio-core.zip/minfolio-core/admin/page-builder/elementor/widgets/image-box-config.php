<?php
/**
 * Registers the image box shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Image_Box extends Widget_Base {
	
	public function get_name() {
		return 'clbr-image-box-widget';
	}

	public function get_title() {
		return esc_html__( 'Image Box', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-image-box';
	}
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_image_box_content',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
			]
		);

		$this->add_control(
			'box_image',
			[
				'label' => esc_html__( 'Choose Image', 'minfolio' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'image_size', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
				'default' => 'full',				
			]
		);

		$this->add_control(
			'title_text',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'This is the heading', 'minfolio' ),
				'placeholder' => esc_html__( 'Enter your title', 'minfolio' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'title_size',
			[
				'label' => esc_html__( 'Title HTML Tag', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h3',
			]
		);

		$this->add_control(
			'description_text',
			[
				'label' => esc_html__( 'Description', 'minfolio' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'minfolio' ),
				'placeholder' => esc_html__( 'Enter your description', 'minfolio' ),
				'separator' => 'none',
				'rows' => 10,				
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-image-box .clbr-image-box-content' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',				
			]
		);	
		
		
		$this->add_control(
            'enable_link',
            [
                'label' => esc_html__( 'Enable Link?', 'minfolio'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' =>esc_html__( 'Yes', 'minfolio' ),
                'label_off' =>esc_html__( 'No', 'minfolio' ),
            ]
		);

		$this->add_control(
			'link_url',
			[
				'label' =>esc_html__( 'URL', 'minfolio' ),
				'type' => Controls_Manager::URL,
				'default' => [
					'url' => '#',
				],
				'condition'	=> [
					'enable_link'	=> 'yes'
				]		
			]
		);	
				
		$this->end_controls_section();	
			
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);		

		$this->add_control(
			'heading_title',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'title_bottom_space',
			[
				'label' => esc_html__( 'Spacing', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content .clbr-image-box-heading' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',		
				'selector' => '{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content .clbr-image-box-heading',
			]
		);		

		$this->start_controls_tabs( 'title_tabs_style' );

		$this->start_controls_tab(
			'title_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content .clbr-image-box-heading' => 'color: {{VALUE}}',
				],				
			]
		);	

		$this->add_control(
			'title_sep_color',
			[
				'label' => esc_html__( 'Separator Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content .clbr-image-box-heading ' => 'border-bottom-color: {{VALUE}}',
				],				
			]
		);	
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'title_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link:hover .clbr-image-box-content .clbr-image-box-heading' => 'color: {{VALUE}}',
				],				
			]
		);	

		$this->add_control(
			'title_hover_sep_color',
			[
				'label' => esc_html__( 'Separator Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link:hover .clbr-image-box-content .clbr-image-box-heading ' => 'border-bottom-color: {{VALUE}}',
				],				
			]
		);	

		$this->end_controls_tab();
		$this->end_controls_tabs();
				
		$this->add_control(
			'heading_description',
			[
				'label' => esc_html__( 'Description', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',		
				'selector' => '{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content .clbr-image-box-desc',
			]
		);
		
		$this->start_controls_tabs( 'desc_tabs_style' );

		$this->start_controls_tab(
			'desc_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content .clbr-image-box-desc' => 'color: {{VALUE}}',
				],				
			]
		);	
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'desc_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'desc_hover_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link:hover .clbr-image-box-content .clbr-image-box-desc' => 'color: {{VALUE}}',
				],				
			]
		);	

		$this->end_controls_tab();
		$this->end_controls_tabs();
		
		$this->end_controls_section();	

		$this->start_controls_section(
			'section_box_style',
			[
				'label' => esc_html__( 'Box', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);				

		$this->add_control(
			'heading_image',
			[
				'label' => esc_html__( 'Image', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_box',
			[
				'label' => esc_html__( 'Box', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);

		$this->start_controls_tabs( 'box_tabs_style' );

		$this->start_controls_tab(
			'box_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'box_background',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content',
            )
        );	
		
		$this->add_control(
			'box_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link .clbr-image-box-content' => 'border-color: {{VALUE}}',
				],				
			]
		);	

		$this->end_controls_tab();

		$this->start_controls_tab(
			'box_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'box_hover_background',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-image-box .clbr-image-box-link:hover .clbr-image-box-content',
            )
        );	
		
		$this->add_control(
			'box_border_hover_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-image-box .clbr-image-box-link:hover .clbr-image-box-content' => 'border-color: {{VALUE}}',
				],				
			]
		);	

		$this->end_controls_tab();
		$this->end_controls_tabs();


		$this->end_controls_section();	


	}


	protected function render( $instance = [] ) {			
		
		$params = $this->get_settings_for_display();	

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-image-box' );
		$this->add_render_attribute( 'box-link', 'class', 'clbr-image-box-link' );
		$this->add_render_attribute( 'title-text', 'class', 'clbr-image-box-heading' );		
						
		
		if( $params[ 'enable_link' ] == 'yes' ) {
		
			if ( ! empty( $params[ 'link_url' ][ 'url' ] ) ) {
				$this->add_link_attributes( 'box-link', $params[ 'link_url' ] );			
			}
		}
		else {

			$this->add_link_attributes( 'box-link', array( 'url' => '#' ) );
			$this->add_render_attribute( 'box-link', 'class', 'clbr-image-box-link-disabled' );	
		}


	?>
		
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >

			<a <?php echo $this->get_render_attribute_string( 'box-link' ); ?> >			

                <div class="clbr-image-box-img">

					<?php echo $this->render_box_image( $params ); ?>

                </div>

                <div class="clbr-image-box-content">
				    <?php echo sprintf( '<%1$s %2$s>%3$s</%1$s>', Utils::validate_html_tag( $params[ 'title_size' ] ), $this->get_render_attribute_string( 'title-text' ), $params[ 'title_text' ] ); ?>                   
                    <p class="clbr-image-box-desc"><?php echo esc_html( $params[ 'description_text' ] ); ?></p>
                </div>
		
            </a>			

        </div>		

	<?php
	}	

	private function render_box_image( $params ) {

		if ( ! empty( $params[ 'box_image' ][ 'url' ] ) ) {

			$this->add_render_attribute( 'image', 'src', $params[ 'box_image' ][ 'url' ] );
			$this->add_render_attribute( 'image', 'alt', Control_Media::get_image_alt( $params[ 'box_image' ] ) );
			$this->add_render_attribute( 'image', 'title', Control_Media::get_image_title( $params[ 'box_image' ] ) );

			$image_html = Group_Control_Image_Size::get_attachment_image_html( $params, 'image_size', 'box_image' );

			return $image_html;

		}

	}	

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Image_Box() );
