<?php
/**
 * Registers the recent posts shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Recent_Posts extends Widget_Base {
	
	public function get_name() {
		return 'clbr-recent-posts-widget';
	}

	public function get_title() {
		return esc_html__( 'Recent Posts', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-gallery-grid';
	}
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		 // Layout
		$this->start_controls_section(
			'recent_posts_content',
			[
				'label' => esc_html__( 'Layout', 'minfolio' ),
			]
		);

		$this->add_control(
			'posts_layout_style',
			[
				'label'     => esc_html__( 'Layout Style', 'minfolio' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
									'3' => esc_html__( '3 Column', 'minfolio' ),
									'4' => esc_html__( '4 Column', 'minfolio' ),					
								],
				'default'   => '3',
			]
		);
 
		$this->add_control(
			'show_posts_feature_img',
			[
				'label'     => esc_html__( 'Show Featured Image', 'minfolio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'default'   => 'yes',			
			]
		);		
	
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name' => 'posts_feature_img_size', // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
				'default' => 'full',				
				'condition' => [
					'show_posts_feature_img'   => 'yes',					
				],
			]
		);
		


		$this->add_control(
			'show_posts_content',
			[
				'label'     => esc_html__( 'Show Content', 'minfolio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'default'   => 'yes',
			]
		);
		
 		$this->add_control(
			'show_posts_read_more',
			[
				'label'     => esc_html__( 'Show Read More', 'minfolio' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'default'   => 'yes',				
			]
		);	
		
		$this->add_control(
			'more_link_text',
			[
				'label' => esc_html__( 'Link Text', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Read More',			
				'condition' => [
					'show_posts_read_more' => 'yes',					
				],	
			]
		);
		
 
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_recent_post',
			[
				'label' => esc_html__( 'Query Params', 'minfolio' ),
			]
		);
		
		$this->add_control(
			'category_in',
			[
				'label' => esc_html__( 'Category', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'description' => esc_html__( 'A list of comma separated category slugs to include (e.g., latest-news,my-blog-category)', 'minfolio' )
			]
		);

		$this->add_control(
			'include_post',
			[
				'label' => esc_html__( 'Include Items', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'description' => esc_html__( 'A list of comma separated IDs of items to include (e.g., 12,36,10)', 'minfolio' )
			]
		);

		$this->add_control(
			'exclude_post',
			[
				'label' => esc_html__( 'Exclude Items', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'description' => esc_html__( 'A list of comma separated IDs of items to exclude (e.g., 12,36,10)', 'minfolio')
			]
		);

		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'menu_order' => esc_html__( 'Menu Order', 'minfolio' ),
					'date' => esc_html__( 'Date', 'minfolio' ),
					'title' => esc_html__( 'Title', 'minfolio' ),
					'modified' => esc_html__( 'Date Modified', 'minfolio' ),
					'rand' => esc_html__( 'Random', 'minfolio' ),
				],
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [
					'ASC' => esc_html__( 'Ascending', 'minfolio' ),
					'DESC' => esc_html__( 'Descending', 'minfolio' ),
				],
			]
		);
		
		
		$this->end_controls_section();
		
			
		
		$this->start_controls_section(
			'section_featured_image_style',
			[
				'label' => esc_html__( 'Featured Image', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);				
		
		$this->add_responsive_control(
			'featured_image_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-thumbnail' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		
				
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);			

		$this->add_control(
			'meta_heading',
			[
				'label' => esc_html__( 'Post Meta', 'minfolio' ),
				'type' => Controls_Manager::HEADING,				
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-entry-meta time' => 'color: {{VALUE}}',
				],						
			]
		);	
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',		
				'selector' => '{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-entry-meta time',
			]
		);
		
		$this->add_control(
			'title_heading',
			[
				'label' => esc_html__( 'Post Title', 'minfolio' ),
				'type' => Controls_Manager::HEADING,		
				'separator' => 'before'		
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',		
				'selector' => '{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content h3.clbr-entry-title a',
			]
		);

		$this->start_controls_tabs( 'title_tabs_style' );

		$this->start_controls_tab(
			'title_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,								
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content h3.clbr-entry-title a' => 'color: {{VALUE}}',
				],						
			]
		);	
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'title_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,								
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content h3.clbr-entry-title a:hover' => 'color: {{VALUE}}',
				],						
			]
		);	

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_control(
			'excerpt_heading',
			[
				'label' => esc_html__( 'Post Excerpt', 'minfolio' ),
				'type' => Controls_Manager::HEADING,	
				'separator' => 'before'				
			]
		);

		$this->add_control(
			'excerpt_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-excerpt p' => 'color: {{VALUE}}',
				],						
			]
		);	
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',		
				'selector' => '{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-excerpt p',
			]
		);

		$this->add_control(
			'link_heading',
			[
				'label' => esc_html__( 'Link', 'minfolio' ),
				'type' => Controls_Manager::HEADING,	
				'separator' => 'before'				
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',		
				'selector' => '{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-read-more a',
			]
		);

		$this->start_controls_tabs( 'link_tabs_style' );

		$this->start_controls_tab(
			'link_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,					
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-read-more a' => 'color: {{VALUE}}',
				],						
			]
		);	

		$this->add_control(
			'link_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,					
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-read-more a' => 'border-bottom-color: {{VALUE}}',
				],						
			]
		);	

		$this->end_controls_tab();

		$this->start_controls_tab(
			'link_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'link_hover_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-read-more a:hover' => 'color: {{VALUE}}',
				],						
			]
		);	

		$this->add_control(
			'link_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,					
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post .clbr-recent-post-content .clbr-recent-post-read-more a:hover' => 'border-bottom-color: {{VALUE}}',
				],						
			]
		);	

		$this->end_controls_tab();
		$this->end_controls_tabs();
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_box_style',
			[
				'label' => esc_html__( 'Box', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);			

		$this->add_control(
			'box_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post' => 'background-color: {{VALUE}}',
				],						
			]
		);	

		$this->add_responsive_control(
			'box_padding',
			[
				'label' => esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-recent-post-section .clbr-recent-post' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		


		$this->end_controls_section();



	}

	protected function render( $instance = [] ) {
		
		global $post;
		
		$params = $this->get_settings_for_display();	

		$index = 0;		

		$query_array = $this->get_query_array( $params );
					
		$blog_post_query = new \WP_Query( $query_array );

	?>

		<?php if( $blog_post_query -> have_posts() ) { ?>

			<article class="clbr-recent-post-section clbr-recent-post-four-col">			

				<?php foreach ( $blog_post_query -> posts as $post ) {			
								
					setup_postdata( $post );

					$date_time = get_the_date( DATE_W3C );			
					$post_date = get_the_date();

					if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {

						$date_time = get_the_modified_date( DATE_W3C );
						$post_date = get_the_modified_date();

					}

				?>        
					<div class="clbr-recent-post">

						<?php if( $params[ 'show_posts_feature_img' ] == 'yes' ) { ?>

							<div class="clbr-recent-post-thumbnail">

								<a href="<?php the_permalink(); ?>">								
									<?php echo $this->render_post_featured_image( $params ); ?>																		
								</a>

							</div>

						<?php } ?>

						<div class="clbr-recent-post-content">

							<div class="clbr-entry-meta">
								<time datetime="<?php echo esc_attr( $date_time ); ?>">
									<?php echo esc_html( $post_date ); ?>
								</time>
							</div>
						
							<?php the_title( '<h3 class="clbr-entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' ); ?>
							
							<?php if( $params[ 'show_posts_content' ] == 'yes' ) { ?>

								<div class="clbr-recent-post-excerpt">
									<?php the_excerpt(); ?>
								</div>

							<?php } ?>

							<?php if( $params[ 'show_posts_read_more' ] == 'yes' ) { ?>

								<div class="clbr-recent-post-read-more">
									<a href="<?php the_permalink(); ?>"><?php echo esc_html( $params[ 'more_link_text' ] ); ?></a>
								</div>

							<?php } ?>

						</div>
					</div>

					<?php 
					
						$index++; 

						if( $index < $params[ 'posts_layout_style' ] ) { ?>	 	 
							<div class="clbr-recent-post-spacer"></div>
						<?php } ?>

				<?php } ?>
								
			</article>
		
		<?php }	else { ?>
		
			<div>
				<h1 class="err-msg"><?php esc_html_e( 'No Post Found, Please Add Post.', 'minfolio' ); ?></h1>
			</div>

		<?php }
			
			wp_reset_query();
				
		?>		


	<?php
	}

	private function render_post_featured_image( $params ) {

		if ( has_post_thumbnail() ) {

			$params[ 'posts_feature_img_size' ] = [
				'id' => get_post_thumbnail_id(),
			];

			$thumbnail_html = Group_Control_Image_Size::get_attachment_image_html( $params, 'posts_feature_img_size' );			

			return $thumbnail_html;

		}

	}	

	private function get_query_array( $params ) {

		$include_post = array();
		$category_in  = array();

		if( $params[ 'include_post' ] ) {
			$include_post  = explode( ',', $params[ 'include_post' ] );
		}			

		if( $params[ 'category_in' ] ) {
			$category_in = explode( ',', $params[ 'category_in' ] );
		}	

		$exclude_post  = explode( ',', $params[ 'exclude_post' ] );

		$limit = $params[ 'posts_layout_style' ];			

		$query_array = array(
			'post_type'      => 'post',
			'posts_per_page' => $limit,
			'order'          => $params[ 'order' ],
			'orderby'        => $params[ 'orderby' ],		
			'post_status'	 => 'publish',
			'post__in'       => $include_post,
			'post__not_in'   => $exclude_post,
			'category__in'   => minfolio_get_category_ids( $category_in )		
		);		

		return $query_array;

	}	
	
}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Recent_Posts() );
