<?php
/**
 * Registers the testimonial shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Testimonial extends Widget_Base {
	
	public function get_name() {
		return 'clbr-testimonial-widget';
	}

	public function get_title() {
		return esc_html__( 'Testimonial', 'minfolio' );
	}

	public function get_script_depends() {
		return [ 'flickity', 'minfolio-frontend' ];
	}		

	public function get_icon() {		
		return 'eicon-blockquote';
	}
		
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
            'section_testimonial_type',
            [
                'label' => esc_html__( 'Layout', 'minfolio' ),
            ]
        );

		$this->add_control(
			'testimonial_type',
			[
				'label' => esc_html__( 'Choose Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'static',
				'options' => [
								'static' => esc_html__( 'Static', 'minfolio' ),
								'carousel' => esc_html__( 'Carousel', 'minfolio' ),											
							],						
			]
		);	

		$this->end_controls_section();		
		
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'condition'	=> [
					'testimonial_type'	=> 'static'
				]		
			]
		);	

		$this->add_control(
            'quote_icon_enable',
            [
                'label' => esc_html__( 'Enable Quote Icon', 'minfolio' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'minfolio' ),
                'label_off' => esc_html__( 'No', 'minfolio' ),
                'return_value' => 'yes',
				'default' => 'yes',				
            ]
		);

		$this->add_control(
            'quote_icon',
            [
                'label' => esc_html__( 'Quote Icon', 'minfolio' ),
                'label_block' => true,
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'fa-solid',
				],
                'condition' => [
					'quote_icon_enable' => 'yes',					
				],
            ]
		);
				
		$this->add_control(
			'review',
			[
				'label' => esc_html__( 'Review', 'minfolio' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
				'placeholder' => esc_html__( 'Enter review here', 'minfolio' ),			
			]
		);

		$this->add_control(
			'avatar',
			[
				'label' => esc_html__( 'Avatar', 'minfolio' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
							'url' => Utils::get_placeholder_image_src(),
						],
				'label_block' => true,
				'placeholder' => esc_html__( 'Select the avatar image.', 'minfolio' ),	
			]
		);

		$this->add_control(
			'author',
			[
				'label' => esc_html__( 'Name', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Name',
				'placeholder' => esc_html__( 'Enter the name here.', 'minfolio' ),			
			]
		);
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title / Position', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Title/Position',
				'placeholder' => esc_html__( 'Enter title/position here', 'minfolio' ),	
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',				
			]
		);	
		
		$this->end_controls_section();		

		$this->start_controls_section(
			'section_carousel_content',
			[
				'label' => esc_html__( 'Carousel Content', 'minfolio' ),
				'condition'	=> [
					'testimonial_type'	=> 'carousel'
				]		
			]
		);	

		$this->add_control(
            'carousel_quote_icon_enable',
            [
                'label' => esc_html__( 'Enable Quote Icon', 'minfolio' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'minfolio' ),
                'label_off' => esc_html__( 'No', 'minfolio' ),
                'return_value' => 'yes',
				'default' => 'yes',				
            ]
		);

		$this->add_control(
            'carousel_quote_icon',
            [
                'label' => esc_html__( 'Quote Icon', 'minfolio' ),
                'label_block' => true,
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'fa-solid',
				],
                'condition' => [
					'carousel_quote_icon_enable' => 'yes',					
				],
            ]
		);

		$testimonial = new Repeater();

		$testimonial->add_control(
            'review', 
			[
				'label' => esc_html__( 'Review', 'minfolio' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.',
				'placeholder' => esc_html__( 'Enter review here', 'minfolio' ),			
            ]
        );

		$testimonial->add_control(
            'avatar', 
			[
				'label' => esc_html__( 'Avatar', 'minfolio' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'placeholder' => esc_html__( 'Select the avatar image.', 'minfolio' ),	
            ]
        );

        $testimonial->add_control(
            'author', 
			[
                'label' => esc_html__( 'Name', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Name',
				'placeholder' => esc_html__( 'Enter the name here.', 'minfolio' ),			
				'label_block' => true,
            ]
        );
		
        $testimonial->add_control(
            'title', 
			[
                'label' => esc_html__( 'Title / Position', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Title/Position',
				'placeholder' => esc_html__( 'Enter title/position here', 'minfolio' ),	
            ]
        );  

		$this->add_control(
            'testimonial_data',
            [
                'label' => esc_html__( 'Testimonial', 'minfolio' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [ 'author' => esc_html__('Testimonial #1', 'minfolio') ],
                    [ 'author' => esc_html__('Testimonial #2', 'minfolio') ],
                    [ 'author' => esc_html__('Testimonial #3', 'minfolio') ],
                ],

                'fields' => $testimonial->get_controls(),
                'title_field' => '{{{ author }}}',
            ]
		);

		$this->add_responsive_control(
			'slide_alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial-carousel .clbr-testimonial' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',				
			]
		);	

		$this->end_controls_section();		

		$this->start_controls_section(
			'section_slide_settings',
			[
				'label' => esc_html__( 'Carousel Settings', 'minfolio' ),
				'condition'	=> [
					'testimonial_type'	=> 'carousel'
				]							
			]
		);	

		$this->add_responsive_control(
			'no_of_slides',
			[
				'label' => esc_html__( 'No of Slides', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 10,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 3,
				],				
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial-carousel .flickity-slider .carousel-cell' => 'width: calc(100% / {{SIZE}}); flex-basis: calc(100% / {{SIZE}});',
				],			
			]
		);			
			
		$this->add_responsive_control(
			'space_between_slides',
			[
				'label' => esc_html__( 'Space between slides', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],				
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],					
				],	
				'default' => [
					'unit' => 'px',
					'size' => 30,
				],
				'description' => esc_html__( 'Distance between slides in px.', 'minfolio' ),		
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial-carousel .flickity-slider .carousel-cell' => 'padding-inline-start: {{SIZE}}{{UNIT}}; padding-inline-end: {{SIZE}}{{UNIT}};',					
				],		
			]
		);

		$this->add_control(
			'slides_align',
			[
				'label' => esc_html__( 'Slides Alignment', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
								'left'   => esc_html__( 'Left', 'minfolio' ),
								'center' => esc_html__( 'Center', 'minfolio' ),																				
								'right'  => esc_html__( 'Right', 'minfolio' ),																				
							],					
			]
		);				
	
		$this->add_control(
			'group_slides',
			[
				'label' => esc_html__( 'Group Slides', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'no',			
				'description' => esc_html__( 'Enable this option if you want the navigation being mapped to grouped slides, not individual slides.', 'minfolio' ),												
			]
		);				
								
		$this->add_control(
			'loop',
			[
				'label' => esc_html__( 'Loop', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Set to true to enable continuous loop mode.', 'minfolio' ),							
			]
		);

		$this->add_control(
			'free_mode',
			[
				'label' => esc_html__( 'Free Mode', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Enables free mode functionality.', 'minfolio' ),				
			]
		);	
		
		$this->add_control(
			'dragger',
			[
				'label' => esc_html__( 'Dragger', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'no',			
				'description' => esc_html__( 'Enables dragger functionality.', 'minfolio' ),				
			]
		);		
			
		$this->end_controls_section();		

		$this->start_controls_section(
			'section_carousel_controls',
			[
				'label' => esc_html__( 'Carousel Controls', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,		
				'condition'	=> [
					'testimonial_type'	=> 'carousel'
				]		
			]
		);	
		
		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);	
		
		$this->add_control(
			'autoplay_delay',
			[
				'label' => esc_html__( 'Delay', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 5000,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 8000,
						'step' => 500
					],					
				],				
				'description' => esc_html__( 'Delay between transitions (in ms).', 'minfolio' ),
				'condition' => [
								  'autoplay' => 'yes',       								          
								]					
			]
		);
		
		$this->add_control(
			'disable_on_interaction',
			[
				'label' => esc_html__( 'Disable on interaction', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Set to No and autoplay will not be disabled after user interactions (swipes), it will be restarted every time after interaction.', 'minfolio' ),			
				'condition' => [
								  'autoplay' => 'yes',       								          
								]	
			]
		);
		
		
		$this->end_controls_section();			
		
		$this->start_controls_section(
			'section_box_style',
			[
				'label' => esc_html__( 'Box', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	

		$this->add_responsive_control(
			'box_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial.static-style' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);

		$this->add_responsive_control(
			'box_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial.static-style' => 'border-style: {{VALUE}};',
					'{{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell' => 'border-style: {{VALUE}};',
				],
				'separator' => 'before'
			]
		);

		$this->add_responsive_control(
			'box_border_width',
			[
				'label' =>esc_html__( 'Border Width', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial.static-style' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial.static-style' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'box_background',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-testimonial.static-style, {{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell',			
            )
        );	

		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-testimonial.static-style' => 'border-color: {{VALUE}}',		
						'{{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell' => 'border-color: {{VALUE}}',										
				],								
			]
		);		

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .clbr-testimonial.static-style, {{WRAPPER}} .clbr-testimonial-carousel.carousel-style .carousel-cell',				
			]
		);

		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__( 'Icon', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	

		$this->add_control (
			'icon_size',
			[
				'label' => esc_html__( 'Size', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-review-wrap .clbr-testimonial-quote-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],				
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-review-wrap .clbr-testimonial-quote-icon i' => 'color: {{VALUE}}',	
						'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-review-wrap .clbr-testimonial-quote-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',			
				],		
				'condition'	=> [
					'carousel_quote_icon_enable'	=> 'yes'
				]						
			]
		);		

		$this->end_controls_section();

		$this->start_controls_section(
			'section_avatar_style',
			[
				'label' => esc_html__( 'Avatar', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	

		$this->add_control (
			'avatar_size',
			[
				'label' => esc_html__( 'Image Size', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-client-avatar img' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}}',
				],				
			]
		);
		
		$this->add_responsive_control(
			'avatar_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-client-avatar img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		

		$this->end_controls_section();

			
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'review_title',
			[
				'label' => esc_html__( 'Review', 'minfolio' ),
				'type' => Controls_Manager::HEADING,				
			]
		);
		
		$this->add_control(
			'review_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-review-wrap .clbr-testimonial-review' => 'color: {{VALUE}}',
				],					
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'review_typography',				
				'selector' => '{{WRAPPER}} .clbr-testimonial .clbr-testimonial-review-wrap .clbr-testimonial-review',
			]
		);
		
		$this->add_control(
			'author_title',
			[
				'label' => esc_html__( 'Author', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
	
		
		$this->add_control(
			'author_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-client-info .clbr-testimonial-client-name' => 'color: {{VALUE}}',
				],						
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'author_typography',				
				'selector' => '{{WRAPPER}} .clbr-testimonial .clbr-testimonial-client-info .clbr-testimonial-client-name',
			]
		);
		
		$this->add_control(
			'position_title',
			[
				'label' => esc_html__( 'Title/Position', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
			
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-testimonial .clbr-testimonial-client-info .clbr-testimonail-client-designation' => 'color: {{VALUE}}',
				],										
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .clbr-testimonial .clbr-testimonial-client-info .clbr-testimonail-client-designation',
			]
		);
		
		$this->end_controls_section();								

	}


	protected function render( $instance = [] ) {			
		
		$params = $this->get_settings_for_display();		
		
		if( $params[ 'testimonial_type' ] == 'carousel' ) {	
			$this->add_render_attribute( 'wrapper', 'class', 'clbr-testimonial-carousel' );		
			$this->add_render_attribute( 'wrapper', 'class', 'carousel-style' );
		}
		else {
			$this->add_render_attribute( 'wrapper', 'class', 'clbr-testimonial' );
			$this->add_render_attribute( 'wrapper', 'class', 'static-style' );
		}	
				

	?>

		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >

			<?php if( $params[ 'testimonial_type' ] == 'carousel' ) {  				
				$this->render_testimonial_carousel_content( $params ); 
			} else { 
				$this->render_testimonial_static_content( $params ); 
			} ?>
			
        </div>
		
	<?php }	

	private function render_testimonial_carousel_content( $params ) { 

		$this->add_render_attribute( 'slide-wrapper', 'class', 'clbr-testimonial' );
		
	?>	

		<?php foreach ( $params[ 'testimonial_data' ] as $testimonial_items => $item ) { ?>

				<div class="carousel-cell">

					<div <?php echo $this->get_render_attribute_string( 'slide-wrapper' ); ?> >

						<?php $this->render_testimonial_author_image( $item ); ?>

						    <div class="clbr-testimonial-review-wrap">

								<?php if( $params[ 'carousel_quote_icon_enable' ] === 'yes' ) { ?>
									<span class="clbr-testimonial-quote-icon">
										<?php Icons_Manager::render_icon( $params[ 'carousel_quote_icon' ], [ 'aria-hidden' => 'true' ] ); ?>		
									</span>
								<?php } ?>

								<span class="clbr-testimonial-review"><?php echo esc_html( $item[ 'review' ] ); ?></span>

							</div>		

						<div class="clbr-testimonial-client-info">
							<h3 class="clbr-testimonial-client-name"><?php echo esc_html( $item[ 'author' ] ); ?></h3>
							<div class="clbr-testimonail-client-designation"><?php echo esc_html( $item[ 'title' ] ); ?></div>
						</div>	

					</div>	
					
				</div>

		<?php } ?>		
		
	<?php }

	private function render_testimonial_static_content( $params ) { ?>			

		<?php $this->render_testimonial_author_image( $params ); ?>

        <div class="clbr-testimonial-review-wrap">

			<?php if( $params[ 'quote_icon_enable' ] == 'yes' ) { ?>
				<span class="clbr-testimonial-quote-icon">
					<?php Icons_Manager::render_icon( $params[ 'quote_icon' ], [ 'aria-hidden' => 'true' ] ); ?>		
				</span>
			<?php } ?>

            <span class="clbr-testimonial-review"><?php echo esc_html( $params[ 'review' ] ); ?></span>

        </div>	

        <div class="clbr-testimonial-client-info">
            <h3 class="clbr-testimonial-client-name"><?php echo esc_html( $params[ 'author' ] ); ?></h3>
            <div class="clbr-testimonail-client-designation"><?php echo esc_html( $params[ 'title' ] ); ?></div>
        </div>	

	<?php }

	private function render_testimonial_author_image( $params ) {

		if ( ! empty( $params[ 'avatar' ][ 'url' ] ) ) {

			$this->add_render_attribute( 'author-image', 'src', $params[ 'avatar' ][ 'url' ], true );
			$this->add_render_attribute( 'author-image', 'alt', Control_Media::get_image_alt( $params[ 'avatar' ] ), true );
			$this->add_render_attribute( 'author-image', 'title', Control_Media::get_image_title( $params[ 'avatar' ] ), true );

		?>
			<div class="clbr-testimonial-client-avatar">
				<img <?php echo $this->get_render_attribute_string( 'author-image' ); ?> >			
			</div>

		<?php
		}

	}	

	private function get_data_attributes( $params ) {

		$data_attr = array();
		$options = array();

		if( $params[ 'testimonial_type' ] === 'static' ) {
			return $data_attr;
		}

		$options[ 'cellAlign' ] = ( $params[ 'slides_align' ] ) ? $params[ 'slides_align' ] : 'left';		
		$options[ 'groupCells' ] = ( $params[ 'group_slides' ] == 'yes' ) ? true : false;
		$options[ 'wrapAround' ] = ( $params[ 'loop' ] === 'yes' ) ? true : false;		
		$options[ 'freeScroll' ] = ( $params[ 'free_mode' ] == 'yes' ) ? true : false;					
		$options[ 'draggable' ] = ( $params[ 'dragger' ] == 'yes' ) ? true : false;
		$options[ 'pageDots' ] = true;
		$options[ 'prevNextButtons' ] = false;		
		$options[ 'imagesLoaded' ] = true;
		$options[ 'bypassCheck' ] = true;

		if( $params[ 'autoplay' ] == 'yes' ) {
			$options[ 'autoPlay' ]    = isset( $params[ 'autoplay_delay' ][ 'size' ] ) ? $params[ 'autoplay_delay' ][ 'size' ] : '3000';
			$options[ 'pauseAutoPlayOnHover' ]  = ( isset( $params[ 'disable_on_interaction' ] ) && $params[ 'disable_on_interaction' ] == 'yes' ) ? true : false;
		}	

		$data_attr[ 'data-flickity-options' ] = stripslashes( wp_json_encode( $options ) );

		return $data_attr;	
		
	}	

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Testimonial() );
