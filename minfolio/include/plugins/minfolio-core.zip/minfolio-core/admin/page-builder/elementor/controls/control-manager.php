<?php

defined( 'ABSPATH' ) || exit;

class Minfolio_Controls_Manager extends \Elementor\Controls_Manager {    
    
    const POPULATE_LIST = 'populate-list';
   
}