<?php
/**
 * Registers the video modal shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Video_Modal extends Widget_Base {
	
	public function get_name() {
		return 'clbr-video-modal-widget';
	}

	public function get_title() {
		return esc_html__( 'Video Modal', 'minfolio' );
	}

	public function get_script_depends() {
		return [ 'magnific-popup', 'minfolio-frontend' ];
	}		

	public function get_icon() {		
		return 'eicon-video-playlist';
	}	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
			]
		);			
					
		$this->add_control(
			'link_url',
			[
				'label' => esc_html__( 'Video Link', 'minfolio' ),
				'type' => Controls_Manager::URL,				
				'placeholder' => esc_html__( 'https://your-link.com', 'minfolio' ),				
			]
		);	
		
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,
				'default' => 'Video Title',												
			]
		);	

		$this->add_responsive_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-video-modal' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',				
			]
		);

		$this->add_control(
            'animation_switch',
            [
                'label' => esc_html__( 'Animation', 'minfolio'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' =>esc_html__( 'Yes', 'minfolio' ),
                'label_off' =>esc_html__( 'No', 'minfolio' ),
            ]
		);
						
		$this->end_controls_section();	

		$this->start_controls_section(
			'icon_bg_style',
			[
				'label' =>esc_html__( 'Icon Background', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'background_size',
			array(
				'label'      => esc_html__( 'Background Size', 'minfolio' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px', 'em', 'rem',
				),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .clbr-video-modal a .clbr-video-modal-icon'   => 'height: {{SIZE}}{{UNIT}};width: {{SIZE}}{{UNIT}};',					
				),
			)
		);

		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
					'{{WRAPPER}} .clbr-video-modal a .clbr-video-modal-icon' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'roundness',
			array(
				'label'      => esc_html__( 'Roundness', 'minfolio' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px', 'em', 'rem',
				),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .clbr-video-modal a .clbr-video-modal-icon'   => 'border-radius: {{SIZE}}{{UNIT}};',					
				),
			)
		);

		$this->end_controls_section();	

		$this->start_controls_section(
			'icon_style',
			[
				'label' =>esc_html__( 'Icon', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_size',
			array(
				'label'      => esc_html__( 'Icon Size', 'minfolio' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px', 'em', 'rem',
				),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors'  => array(					
					'{{WRAPPER}} .clbr-video-modal a .clbr-video-modal-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
					'{{WRAPPER}} .clbr-video-modal a .clbr-video-modal-icon svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();	

	}

	protected function render( $instance = [] ) {	

		$params = $this->get_settings_for_display();	
		
		$this->add_render_attribute( 'wrapper', 'class', 'clbr-video-modal' );			

		if ( ! empty( $params[ 'link_url' ][ 'url' ] ) ) {
			$this->add_link_attributes( 'video-link', $params[ 'link_url' ] );			
		}

		$this->add_render_attribute( 'video-link', 'data-title', $params[ 'title' ] );			

		$this->add_render_attribute( 'video-icon', 'class', 'clbr-video-modal-icon' );				

		if ( $params[ 'animation_switch' ] != 'yes' ) {
			$this->add_render_attribute( 'video-icon', 'class', 'clbr-video-modal-icon-no-animation' );		
		}				

	?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >
            <a <?php echo $this->get_render_attribute_string( 'video-link' ); ?> >

                <div <?php echo $this->get_render_attribute_string( 'video-icon' ); ?> >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 22v-20l18 10-18 10z"/></svg>
                </div>   

            </a>
        </div>      
	
	<?php 
	}

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Video_Modal() );
