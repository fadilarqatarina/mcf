<?php
/**
 * Registers the portfolio section shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Portfolio_Section extends Widget_Base {

	private $first_category_slug = '*';
	
	public function get_name() {
		return 'clbr-portfolio-section-widget';
	}

	public function get_title() {
		return esc_html__( 'Portfolio Section', 'minfolio' );
	}

	public function get_script_depends() {
		return [ 'cubeportfolio', 'magnific-popup', 'minfolio-frontend' ];
	}		

	public function get_icon() {		
		return 'eicon-gallery-grid';
	}
		
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {
		
		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__( 'Layout', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'portfolio_layout',
			[
				'label' => esc_html__( 'Layout', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => [								
								'grid'    => esc_html__( 'Grid', 'minfolio' ),
								'masonry' => esc_html__( 'Masonry', 'minfolio' ),
								'mosaic'  => esc_html__( 'Mosaic', 'minfolio' )	
							 ]
			]
		);

		$this->add_responsive_control(
			'portfolio_columns',
			[
				'label' => esc_html__( 'Columns', 'minfolio' ),
				'type' => Controls_Manager::SELECT,		
				'default' => '3',	
				'options' => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '5',
					'6' => '6',
					'7' => '7',
					'8' => '8',
				]			
			]
		);	
				
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_query',
			[
				'label' => esc_html__( 'Query', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'no_of_items',
			[
				'label' => esc_html__( 'No of items', 'minfolio' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '',
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order by', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [									
								"date"		 => esc_html__( "Date", "minfolio" ),
								"ID"		 => esc_html__( "ID", "minfolio" ),
								"author"	 => esc_html__( "Author", "minfolio" ),
								"title"		 => esc_html__( "Title", "minfolio" ),
								"modified"	 => esc_html__( "Last Modified", "minfolio" ),	
								"rand"		 => esc_html__( "Random", "minfolio" ),				
								"menu_order" => esc_html__( "Custom Sort", "minfolio" ),
								"inherit"	 => esc_html__( "Inherit", "minfolio" ),
							 ],			
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order arrangement', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [									
								"ASC"		 => esc_html__( "Ascending", "minfolio" ),
								"DESC"		 => esc_html__( "Descending", "minfolio" ),
								"inherit"	 => esc_html__( "Inherit", "minfolio" ),								
							 ],	
				'separator' => 'after'
			]
		);
		
		$this->add_control(
			'categories_flag',
			[
				'label' => esc_html__( 'Exclude/Include portfolio categories', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'exclude',
				'label_block' => true,
				'options' => [									
								"exclude"	=> esc_html__( "Exclude", "minfolio" ),
								"include"	=> esc_html__( "Include", "minfolio" ),									
							 ],			
			]
		);
		
		$this->add_control(
			'exclude_categories',
			[
				'label' => esc_html__( 'Portfolio categories', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,					
				'description' => esc_html__( 'Enter portfolio categories slug to exclude those records (Note: separate values by commas (,)). Example branding,mobile-app.', 'minfolio' ),				
			]
		);		
		
		$this->add_control(
			'portfolio_items_flag',
			[
				'label' => esc_html__( 'Exclude/Include portfolio items', 'minfolio' ),
				'label_block' => true,						
				'type' => Controls_Manager::SELECT,
				'default' => 'exclude',
				'options' => [									
								"exclude"	=> esc_html__( "Exclude", "minfolio" ),
								"include"	=> esc_html__( "Include", "minfolio" ),									
							 ],			
			]
		);
		
		$this->add_control(
			'exclude_portfolio',
			[
				'label' => esc_html__( 'Portfolio IDs', 'minfolio' ),
				'label_block' => true,
				'type' => Controls_Manager::TEXT,			
				'description' => esc_html__( 'Enter portfolio IDs to exclude those records (Note: separate values by commas (,)).Example 2533,231.', 'minfolio' ),				
			]
		);			
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_thumbnail_appearance',
			[
				'label' => esc_html__( 'Thumbnail Appearance', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,		
			]
		);

		$this->add_control(
			'show_title',
			[
				'label' => esc_html__( 'Show Title', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',		
			]
		);

		$this->add_control(
			'show_subtitle',
			[
				'label' => esc_html__( 'Show Sub Title', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
			]
		);
		
		$this->add_control(
			'content_position',
			[
				'label' => esc_html__( 'Content position', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'content-under-img',
				'options' => [	
								'content-under-img' => esc_html__( 'Content Under Image', 'minfolio' ),													
								'content-overlay'   => esc_html__( 'Content Overlay', 'minfolio' ),								
							],				
			]
		);
				
		$this->add_control(
			'overlay_caption_animation',
			[
				'label' => esc_html__( 'Hover Effect', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'default-effect',
				'options' => [	
								'default-effect' => esc_html__( 'Default', 'minfolio' ),									
								'boxed-effect'	=> esc_html__( 'Boxed', 'minfolio' ),													
								'ribbon-effect'  => esc_html__( 'Ribbon', 'minfolio' ),			
							 ],	
				'condition'   => [ 'content_position' => 'content-overlay' ],										
			]
		);
		
		$this->add_control(
			'under_image_caption_animation',
			[
				'label' => esc_html__( 'Hover Effect', 'minfolio' ),			
				'type' => Controls_Manager::SELECT,
				'default' => 'zoom-effect',
				'options' => [								
								'no-effect' => esc_html__( 'None', 'minfolio' ),
								'zoom-effect' => esc_html__( 'Zoom', 'minfolio' ),													
							 ],				
				'condition'   => [ 'content_position' => 'content-under-img' ],
			]
		);	
		
		$this->add_control(
			'content_alignment',
			[
				'label' => esc_html__( 'Content alignment', 'minfolio' ),				
				'type' => Controls_Manager::CHOOSE,
				'default' => 'center',			
				'options' => [
								'left'    => [
									'title' => esc_html__( 'Left', 'minfolio' ),
									'icon' => 'eicon-text-align-left',
								],
								'center' => [
									'title' => esc_html__( 'Center', 'minfolio' ),
									'icon' => 'eicon-text-align-center',
								],	
								'right' => [
									'title' => esc_html__( 'Right', 'minfolio' ),
									'icon' => 'eicon-text-align-right',
								],										
							],	
				'condition'   => [ 'overlay_caption_animation!' => 'ribbon-effect' ],									
			]
		);
				
		$this->add_control(
			'horizontal_space',
			[
				'label' => esc_html__( 'Rows Gap', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],				
			]
		);

		$this->add_control(
			'vertical_space',
			[
				'label' => esc_html__( 'Columns Gap', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],					
			]
		);		
		
	
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_filter_bar',
			[
				'label' => esc_html__( 'Filter Bar', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,		
			]
		);
		
		$this->add_control(
			'show_filter',
			[
				'label' => esc_html__( 'Show category filter', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'description' => esc_html__( 'Check to show the filters in a portfolio section.', 'minfolio' ),			
			]
		);	

		$this->add_control(
			'show_sub_category',
			[
				'label' => esc_html__( 'Show Sub category', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'condition'   => [ 'show_filter' => 'yes' ],
				'description' => esc_html__( 'Check to show sub categories filter in portfolio section.', 'minfolio' ),			
			]
		);	

		$this->add_control(
			'show_filter_in_container',
			[
				'label' => esc_html__( 'Show Filter in Container', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',			
				'condition'   => [ 'show_filter' => 'yes' ],
				'description' => esc_html__( 'Check to show filter bar in box container.', 'minfolio' ),			
			]
		);
		
		$this->add_control(
			'show_all_category',
			[
				'label' => esc_html__( 'Show All filter', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'yes',		
				'condition'   => [ 'show_filter' => 'yes' ],
				'description' => esc_html__( 'Choose to show/hide All filter by default in portfolio section.', 'minfolio' ),			
			]
		);		

		$this->add_control(
			'all_category_text',
			[
				'label' => esc_html__( 'All Category Text', 'minfolio' ),			
				'type' => Controls_Manager::TEXT,
				'default' => 'All',								
				'condition'   => [ 'show_filter' => 'yes', 'show_all_category' => 'yes' ],				
			]
		);		
						
		$this->add_responsive_control(
			'filter_position',
			[
				'label' => esc_html__( 'Alignment', 'minfolio' ),				
				'type' => Controls_Manager::CHOOSE,
				'default' => 'right',			
				'options' => [
								'left'    => [
									'title' => __( 'Left', 'minfolio' ),
									'icon' => 'eicon-text-align-left',
								],
								'center' => [
									'title' => __( 'Center', 'minfolio' ),
									'icon' => 'eicon-text-align-center',
								],
								'right' => [
									'title' => __( 'Right', 'minfolio' ),
									'icon' => 'eicon-text-align-right',
								],								
							],
				'selectors' => [
								'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text' => 'text-align: {{VALUE}}',
								'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-subfilters' => 'text-align: {{VALUE}}'
							],				
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);
		
		$this->add_control(
			'filter_animation',
			[
				'label' => esc_html__( 'Animation', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'quicksand',
				'options' => [								
								'fadeOut'		=> esc_html__( 'fadeOut', 'minfolio' ),
								'quicksand'		=> esc_html__( 'quicksand', 'minfolio' ),	
								'bounceLeft'	=> esc_html__( 'bounceLeft', 'minfolio' ),	
								'bounceTop'		=> esc_html__( 'bounceTop', 'minfolio' ),	
								'bounceBottom'  => esc_html__( 'bounceBottom', 'minfolio' ),	
								'moveLeft'		=> esc_html__( 'moveLeft', 'minfolio' ),	
								'slideLeft'		=> esc_html__( 'slideLeft', 'minfolio' ),	
								'fadeOutTop'	=> esc_html__( 'fadeOutTop', 'minfolio' ),	
								'sequentially'  => esc_html__( 'sequentially', 'minfolio' ),	
								'skew'			=> esc_html__( 'skew', 'minfolio' ),	
								'slideDelay'	=> esc_html__( 'slideDelay', 'minfolio' ),	
								'3dFlip'		=> esc_html__( '3dFlip', 'minfolio' ),	
								'rotateSides'	=> esc_html__( 'rotateSides', 'minfolio' ),	
								'flipOutDelay'  => esc_html__( 'flipOutDelay', 'minfolio' ),	
								'flipOut'		=> esc_html__( 'flipOut', 'minfolio' ),	
								'unfold'		=> esc_html__( 'unfold', 'minfolio' ),	
								'foldLeft'		=> esc_html__( 'foldLeft', 'minfolio' ),	
								'scaleDown'		=> esc_html__( 'scaleDown', 'minfolio' ),	
								'scaleSides'	=> esc_html__( 'scaleSides', 'minfolio' ),	
								'frontRow'		=> esc_html__( 'frontRow', 'minfolio' ),	
								'flipBottom'	=> esc_html__( 'flipBottom', 'minfolio' ),	
								'rotateRoom'	=> esc_html__( 'rotateRoom', 'minfolio' ),	
							 ],						
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);
		
		$this->add_control(
			'filter_orderby',
			[
				'label' => esc_html__( 'Order by', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'name',
				'options' => [								
								'name'	  => esc_html__( 'Name', 'minfolio' ),
								'term_id' => esc_html__( 'ID', 'minfolio' ),	
								'count'   => esc_html__( 'Count', 'minfolio' ),	
								'slug'    => esc_html__( 'Slug', 'minfolio' ),	
							 ],						
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);
		
		$this->add_control(
			'filter_order',
			[
				'label' => esc_html__( 'Order', 'minfolio' ),				
				'type' => Controls_Manager::SELECT,
				'default' => 'ASC',
				'options' => [								
								'ASC'	=> esc_html__( 'Ascending', 'minfolio' ),
								'DESC'  => esc_html__( 'Descending', 'minfolio' ),	
								
							 ],								
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);
		
		$this->add_responsive_control(
			'filter_margin_bottom',
			[
				'label' => esc_html__( 'Margin botom', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 80,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text' => 'margin-bottom: {{SIZE}}{{UNIT}}',
				],
				'description' => esc_html__( 'Set the margin bottom for filter example: 10px.', 'minfolio' ),
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);	

		$this->add_responsive_control(
			'filter_space_between',
			[
				'label' => esc_html__( 'Space between', 'minfolio' ),				
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 12,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text .cbp-filter-item' => 'margin-left: {{SIZE}}{{UNIT}};margin-right: {{SIZE}}{{UNIT}}',
				],
				'description' => esc_html__( 'Set the space between filter items.', 'minfolio' ),
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);	
		
		$this->end_controls_section();	

		$this->start_controls_section(
			'section_load_more',
			[
				'label' => esc_html__( 'Load More', 'minfolio' ),
				'tab' => Controls_Manager::TAB_CONTENT,			
			]
		);

		$this->add_control(
			'load_more_feature',
			[
				'label' => esc_html__( 'Load more', 'minfolio' ),			
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'minfolio' ),
				'label_off' => esc_html__( 'No', 'minfolio' ),
				'return_value' => 'yes',
				'default' => 'no',			
				'description' => esc_html__( 'Check to enable load more feature for portfolio section.', 'minfolio' ),			
			]
		);
		
		$this->add_control(
			'load_more_using',
			[
				'label' => esc_html__( 'Type', 'minfolio' ),			
				'type' => Controls_Manager::SELECT,
				'default' => 'click',
				'options' => [								
								'click' => esc_html__( 'Button click', 'minfolio' ),
								'auto'  => esc_html__( 'Scroll', 'minfolio' ),													
							 ],				
				'condition'   => [ 'load_more_feature' => 'yes' ],
			]
		);

		$this->add_control(
            'btn_size',
            [
                'label' =>esc_html__( 'Size', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'sm' => esc_html__( 'Small', 'minfolio' ),
                    'md' => esc_html__( 'Medium', 'minfolio' ),
					'lg' => esc_html__( 'Large', 'minfolio' ),
					'xl' => esc_html__( 'Extra Large', 'minfolio' ),
					'block' => esc_html__( 'Block', 'minfolio' ),
                ],    
				'condition'   => [ 'load_more_feature' => 'yes' ],         
            ]
        );
		
		$this->add_control(
			'load_no_of_items',
			[
				'label' => esc_html__( 'No of items', 'minfolio' ),				
				'type' => Controls_Manager::TEXT,							
				'condition'   => [ 'load_more_feature' => 'yes' ],				
			]
		);		
		
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Button text', 'minfolio' ),				
				'type' => Controls_Manager::TEXT,
				'default' => 'Load More',							
				'condition'   => [ 'load_more_feature' => 'yes', 'load_more_using' => 'click' ],				
			]
		);	

		$this->add_control(
			'button_loading_text',
			[
				'label' => esc_html__( 'Loading text', 'minfolio' ),			
				'type' => Controls_Manager::TEXT,
				'default' => 'Loading',								
				'condition'   => [ 'load_more_feature' => 'yes', 'load_more_using' => 'click' ],				
			]
		);		
		
		$this->add_control(
			'button_load_text',
			[
				'label' => esc_html__( 'After load text', 'minfolio' ),			
				'type' => Controls_Manager::TEXT,
				'default' => 'No more works',								
				'condition'   => [ 'load_more_feature' => 'yes' ],				
			]
		);		
		
		
		$this->end_controls_section();
			
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-body .clbr-portfolio-title' => 'color: {{VALUE}}',
				],			
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-body .clbr-portfolio-title',
			]
		);
		
		$this->end_controls_section();	
		
		$this->start_controls_section(
			'section_subtitle_style',
			[
				'label' => esc_html__( 'Sub Title', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);
		
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-body .clbr-portfolio-desc' => 'color: {{VALUE}}',
				],			
			]
		);		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',				
				'selector' => '{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-body .clbr-portfolio-desc',
			]
		);

		$this->end_controls_section();	


		$this->start_controls_section(
			'section_category_filter_style',
			[
				'label' => esc_html__( 'Category Filter', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,	
				'condition'   => [ 'show_filter' => 'yes' ],	
			]
		);

		$this->add_control(
			'category_text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,							
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text .cbp-filter-item:not(.cbp-filter-item-active)' => 'color: {{VALUE}}',
				],				
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);

		$this->add_control(
			'active_category_text_color',
			[
				'label' => esc_html__( 'Active Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,							
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text .cbp-filter-item.cbp-filter-item-active' => 'color: {{VALUE}}',
				],				
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);

		$this->add_control(
			'active_border_color',
			[
				'label' => esc_html__( 'Active Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text .cbp-filter-item:after' => 'background: {{VALUE}}',
				],				
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'category_text_typography',				
				'selector' => '{{WRAPPER}} .clbr-portfolio-wrap .cbp-l-filters-text .cbp-filter-item',
				'condition'   => [ 'show_filter' => 'yes' ],
			]
		);
	
		
		$this->end_controls_section();	

		$this->start_controls_section(
			'section_thumbnail_style',
			[
				'label' => esc_html__( 'Thumbnail', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,					
			]
		);

		$this->add_responsive_control(
			'thumnail_image_border_radius',
			[
				'label' =>esc_html__( 'Image Roundness', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-img-wrap' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
	
		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(		
				'label'	=> 'Overlay Color',
				'name'     => 'thumnail_overlay_color',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap',					
				'condition'   => [ 'content_position' => 'content-overlay' ]										
            )
        );	

		$this->add_responsive_control(
			'thumnail_overlay_border_radius',
			[
				'label' =>esc_html__( 'Overlay Roundness', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-section .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'   => [ 'content_position' => 'content-overlay' ],			
			]
		);

		$this->add_control(
			'thumnail_arrow_icon_color',
			[
				'label' => esc_html__( 'Arrow icon color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,							
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-section.clbr-portfolio-ribbon-effect .clbr-portfolio-item .clbr-portfolio-caption .clbr-portfolio-content-wrap i' => 'color: {{VALUE}}',
				],		
				'condition'   => [ 'overlay_caption_animation' => 'ribbon-effect' ],				
			]
		);


		$this->end_controls_section();	

		$this->start_controls_section(
			'section_load_more_btn_style',
			[
				'label' => esc_html__( 'Load More Button', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,	
				'condition'   => [ 'load_more_feature' => 'yes' ],	
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',				
				'selector' => '{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn',
				'separator' => 'after'
			]
		);

		$this->start_controls_tabs( 'btn_tabs_style' );

		$this->start_controls_tab(
			'btn_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn' => 'background-color: {{VALUE}}',
				],					
			]
		);

		$this->add_responsive_control(
			'btn_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'solid',
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn' => 'border-color: {{VALUE}}',
				],	
				'condition'	=> [ 'btn_border_style!' => 'none' ]							
			]
		);

		$this->add_responsive_control(
			'btn_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_tab_button_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn:hover' => 'background-color: {{VALUE}}',
				],					
			]
		);

		$this->add_responsive_control(
			'btn_hover_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'solid',
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn:hover' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn:hover' => 'border-color: {{VALUE}}',
				],	
				'condition'	=> [ 'btn_hover_border_style!'	=> 'none' ]							
			]
		);

		$this->add_responsive_control(
			'btn_hover_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-portfolio-wrap .clbr-btn-wrapper .clbr-btn:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();	

	}

	protected function render( $instance = [] ) {	

		$params = $this->get_settings_for_display();	

	?>

		<div class="clbr-portfolio-wrap">

			<?php if ( $params[ 'show_filter' ] ) { 

				$this->render_category_filter( $params );

				if( $params[ 'show_sub_category' ] === 'yes' ) {
					$this->render_sub_category_filter( $params );
				}

			} ?>

			<?php $this->render_portfolio_container( $params ); ?>


		</div>

	<?php
	}

	private function render_category_filter( $params ) {		
	
		$category_data_filter_markup = '';

		$this->add_render_attribute( 'filter-wrapper', 'class', 'cbp-l-filters-text' );

		if( $params[ 'show_filter_in_container' ] == 'yes' ) {
			$this->add_render_attribute( 'filter-wrapper', 'class', 'boxed-filter-bar' );
		}

		//show_filter_in_container
	
		$args = array(
			'orderby' => $params[ 'filter_orderby' ],
			'order' => $params[ 'filter_order' ],
			'hierarchical' => false,
			'parent' => 0,
			'taxonomy' => 'portfolio_category'
		);				
		
		$categories = get_categories( $args );
	
		if ( !empty( $categories ) ) {

			$filtered_categories = explode( ',', $params[ 'exclude_categories' ] );
	
			foreach ( $categories as $key => $value ) {	
								
				if( minfolio_check_portfolio_categories( $params[ 'categories_flag' ], $value->slug, $filtered_categories ) ) {
	
					$category_data_filter_markup .= '<div data-filter=.' . esc_attr( $value->slug ) . ' class="cbp-filter-item">'; 
					$category_data_filter_markup .= esc_html( $value->name ); 											        
					$category_data_filter_markup .= '</div>';
							
					if( $this->first_category_slug === '*' ) {
						$this->first_category_slug = $value->slug;
					} 	
							
				}
			}
		}		
			
		?>
		
		<div id="filters-container" <?php echo $this->get_render_attribute_string( 'filter-wrapper' ); ?> >
				
			<?php if( $params[ 'show_all_category' ] ) { ?>
					
				<div data-filter="*" class="cbp-filter-item-active cbp-filter-item">						
					
					<?php echo esc_html( $params[ 'all_category_text' ] ); 	?>
													
				</div>
					
			<?php }	?>
						
			<?php echo $category_data_filter_markup; ?>
	
		</div>

	<?php
	}


	private function render_sub_category_filter( $params ) {

		$args = array(
			'orderby' => $params[ 'filter_orderby' ],
			'order' => $params[ 'filter_order' ],
			'hierarchical' => false,
			'parent' => 0,
			'taxonomy' => 'portfolio_category'
		);
	
		$categories = get_categories( $args );
									
		if ( !empty( $categories ) ) {

			$filtered_categories = explode( ',', $params[ 'exclude_categories' ] );
						
			foreach ( $categories as $key => $parent ) {						
																		
				if( minfolio_check_portfolio_categories( $params[ 'categories_flag' ], $parent->slug, $filtered_categories ) ) {										
													
					$sub_categories = get_terms( 'portfolio_category', array( 'parent' => $parent->term_id, 'hide_empty' => false ) );									
													
					if( !empty( $sub_categories ) ) { ?>
													   
					   <div id="filters-container-subcategory_<?php echo esc_attr( $parent->term_id ); ?>" class="cbp-l-subfilters" data-filter-parent=".<?php echo esc_attr( $parent->slug ); ?>" > 
													
						<?php foreach ( $sub_categories as $key => $value ) { ?>						
									
							<div data-filter=".<?php echo esc_attr( $value->slug ); ?>" class="cbp-filter-item">
								<?php echo esc_html( $value->name ); ?>
							</div>
															
						<?php } ?>
															
						</div>
	
					<?php      
	
					}
				}		
			}
		}		

	}

	private function render_portfolio_container( $params ) {

		global $post;

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-section cbp' );
		$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-' . $params[ 'content_position' ] );	
		$this->add_render_attribute( 'wrapper', 'class', $params[ 'portfolio_layout' ] );		

		if( $params[ 'content_position' ] == 'content-under-img' ) {
			$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-' . $params[ 'under_image_caption_animation' ] );		
		}
		else {
			$this->add_render_attribute( 'wrapper', 'class', 'clbr-portfolio-' . $params[ 'overlay_caption_animation' ] );		
		}

		if( $params[ 'load_more_feature' ] === 'yes' ) {
			$this->add_render_attribute( 'wrapper', 'class', 'clbr-load-more-' . $params[ 'load_more_using' ] );		
		}
		

		$query_array = $this->get_query_array( $params );
					
		$portfolio_query = new \WP_Query( $query_array );		

		if( $portfolio_query -> have_posts() ) { ?>

			<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >
				
				<?php
				
					foreach ( $portfolio_query -> posts as $post ) {	
						
						setup_postdata( $post );

						$params[ 'portfolio_id' ] = get_the_ID();						

						$portfolio_category = $this->get_category_array( $params );							
							
						$params[ 'term_string' ] = $portfolio_category[0];
						$params[ 'term_subtitle' ] = $portfolio_category[1];

						$portfolio_project_type	= minfolio_get_post_meta( 'portfolio_project_type' );	
						
						$portfolioFrontEnd = \Minfolio_Portfolio_FrontEnd::getInstance();
						
						$portfolio_project_type_method = 'render_portfolio_' . $portfolio_project_type . '_items';

						$portfolioFrontEnd->$portfolio_project_type_method( $params );

					} 
					
				?>

			</div><!--End #grid-container-->

			<?php if( $params[ 'load_more_feature' ] === 'yes' && !empty( $params[ 'no_of_items' ] ) && $params[ 'no_of_items' ] != -1 ) { 
					$this->render_load_more_button( $params );
			} ?>


		<?php } else { ?>	

			<div>
				<h1 class="err-msg">
					<?php esc_html_e( 'No portfolio items added, Please add from admin.', 'minfolio' ); ?>
				</h1>
			</div>

		<?php } 

		wp_reset_postdata();	
			
	}


	private function get_query_array( $params ) {

		$inherit_orderby = minfolio_get_core_option( 'portfolio-order-by' ); 
		$inherit_order = minfolio_get_core_option( 'portfolio-order-arrangement' );	
		
		$no_of_items = -1;
		$exclude_portfolio_items = null;
		$exclude_category_items = null;

		$orderby = $inherit_orderby;
		$order = $inherit_order;		
				
		if( !empty( $params[ 'no_of_items' ] ) ) {
			$no_of_items = $params[ 'no_of_items' ];
		}				
		
		if( $params[ 'orderby' ] != 'inherit' ) {
			$orderby = $params[ 'orderby' ];
		}
		
		if( $params[ 'order' ] != 'inherit' ) {
			$order = $params[ 'order' ];
		}
			
		if( $params[ 'exclude_portfolio' ] ) {	
			$exclude_portfolio_items  = explode( ',', $params[ 'exclude_portfolio' ] );
		}
		
		if( $params[ 'exclude_categories' ] ) {
			$exclude_category_items = explode( ',', $params[ 'exclude_categories' ] );
		}
		
		$tax_query = array();
			
		if( !empty( $exclude_category_items ) ) {		
				
			$tax_query[] = array(
								array(
									'taxonomy' => 'portfolio_category',
									'field'    => 'slug',
									'terms'    => $exclude_category_items,
									'operator' => ( $params[ 'categories_flag' ] == 'exclude' ) ? 'NOT IN' : 'IN'	
								)
							);	
								
		}
		
		if( $params[ 'portfolio_items_flag' ] == 'exclude' ) {		
					
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__not_in'   => $exclude_portfolio_items,			
				'tax_query'		 =>	$tax_query
			);
		}
		else {
				
			$query_array = array(
				'post_type'		 => 'portfolio',
				'posts_per_page' => $no_of_items,
				'order'			 => $order,			
				'orderby'		 => $orderby,
				'post_status'	 => 'publish',
				'post__in'       => $exclude_portfolio_items,			
				'tax_query'		 =>	$tax_query
			);			
		}	

		return $query_array;

	}

	private function get_data_attributes( $params ) {

		$data_attr = array();	
		$options = array();			
						
		if( $params[ 'show_filter' ] === 'yes' ) {
			$options[ 'filters' ] = '#filters-container, [id^=filters-container-subcategory]';
			$options[ 'defaultFilter' ] = ( $params[ 'show_all_category' ] === 'yes' ) ? '*' : '.' . $this->first_category_slug;
		}

		$options[ 'layoutMode' ] = ( $params[ 'portfolio_layout' ] ) ? $params[ 'portfolio_layout' ] : 'grid';
		$options[ 'sortToPreventGaps' ] = true;
		$options[ 'animationType' ] = ( $params[ 'filter_animation' ] ) ? $params[ 'filter_animation' ] : '';
		$options[ 'gapHorizontal' ] = ( $params[ 'horizontal_space' ][ 'size' ] ) ? intval( $params[ 'horizontal_space' ][ 'size' ] ) : 0;
		$options[ 'gapVertical' ] = ( $params[ 'vertical_space' ][ 'size' ] ) ? intval( $params[ 'vertical_space' ][ 'size' ] ) : 0;
		$options[ 'gridAdjustment' ] = 'responsive';
		$options[ 'caption' ] = '';
		$options[ 'displayType' ] = 'default';
		$options[ 'displayTypeSpeed' ] = 100;
		$options[ 'mediaQueries' ] = [ 
										[ 'width' => 1025, 'cols' => isset( $params[ 'portfolio_columns' ] ) ?  intval( $params[ 'portfolio_columns' ] ) : 4 ],  
										[ 'width' => 790, 'cols' => isset( $params[ 'portfolio_columns_tablet' ] ) ?  intval( $params[ 'portfolio_columns_tablet' ] ) : 3 ],  
										[ 'width' => 680, 'cols' => isset( $params[ 'portfolio_columns_mobile_extra' ] ) ?  intval( $params[ 'portfolio_columns_mobile_extra' ] ) : 2 ],  
										[ 'width' => 600, 'cols' => isset( $params[ 'portfolio_columns_mobile' ] ) ?  intval( $params[ 'portfolio_columns_mobile' ] ) : 1 ],  
									];

		if( $params[ 'load_more_feature' ] === 'yes' && !empty( $params[ 'no_of_items' ] ) && $params[ 'no_of_items' ] != -1 ) { 
		
			$options[ 'plugins' ] = [ 
									'loadMore' => [ 
										'element' => '#more-projects',
										'action' =>  ( $params[ 'load_more_using' ] ) ? $params[ 'load_more_using' ] : '',
										'loadItems' => ( $params[ 'load_no_of_items' ] ) ? intval( $params[ 'load_no_of_items' ] ) : 1,
									] 
								];
		}
		
		$data_attr[ 'data-cbp-options' ] = stripslashes( wp_json_encode( $options ) );		
		
		return $data_attr;

	}

	private function render_load_more_button( $params ) { 
	
		$this->add_render_attribute( 'btn-wrapper', 'class', 'clbr-btn-wrapper load-more' );
		$this->add_render_attribute( 'button', 'class', 'clbr-btn cbp-l-loadMore-link' );	
	
		$this->add_render_attribute( 'button', 'class', 'clbr-btn-' . $params[ 'btn_size' ] );		
		
		?>

		<div id="more-projects" <?php echo $this->get_render_attribute_string( 'btn-wrapper' ); ?>>
			<a href="<?php echo esc_url( $this->get_load_more_ajax_url( $params ) ); ?>" <?php echo $this->get_render_attribute_string( 'button' ); ?>>				
				<span class="cbp-l-loadMore-defaultText"><?php echo esc_html( $params[ 'button_text' ] ); ?></span>
				<span class="cbp-l-loadMore-loadingText"><?php echo esc_html( $params[ 'button_loading_text' ] ); ?></span>
				<span class="cbp-l-loadMore-noMoreLoading"><?php echo esc_html( $params[ 'button_load_text' ] ); ?></span>
			</a>
		</div>	
	
	<?php }

	private function get_load_more_ajax_url( $params ) {

		$ajax_url = admin_url( 'admin-ajax.php' ) . '?action=minfolio_load_more_portfolio_items&security='. wp_create_nonce( 'minfolio-secure-ajax' );
		$ajax_url .= '&of=' . $params[ 'no_of_items' ];
		$ajax_url .= '&ob=' . $params[ 'orderby' ];
		$ajax_url .= '&od=' . $params[ 'order' ];			
		$ajax_url .= '&cp=' . $params[ 'content_position' ];		
			
		if( !empty( $params[ 'exclude_categories' ] ) ) {	
			$ajax_url .= '&fc=' . $params[ 'categories_flag' ];
			$ajax_url .= '&ec=' . $params[ 'exclude_categories' ];
		}
		else {
			$ajax_url .= '&fc=';
			$ajax_url .= '&ec=';
		}
			
		if( !empty( $params[ 'exclude_portfolio' ] ) ) {	
			$ajax_url .= '&fp=' . $params[ 'portfolio_items_flag' ];
			$ajax_url .= '&ep=' . $params[ 'exclude_portfolio' ];				
		}
		else {
			$ajax_url .= '&fp=';
			$ajax_url .= '&ep=';						
		}					

		$ajax_url .= '&ca=' . $params[ 'content_alignment' ]; 
		$ajax_url .= '&oa=' . $params[ 'overlay_caption_animation' ];		
		$ajax_url .= '&ua=' . $params[ 'under_image_caption_animation' ];		
		$ajax_url .= '&pl=' . $params[ 'portfolio_layout' ];					

		$ajax_url .= '&st=' . $params[ 'show_title' ];					
		$ajax_url .= '&ss=' . $params[ 'show_subtitle' ];					
	
			
		return $ajax_url;

	}

	private function get_category_array( $params ) {

		$terms	= wp_get_post_terms( $params[ 'portfolio_id' ], 'portfolio_category' );			

		$term_string = '';
		$term_subtitle = '';

		$portfolio_category = array();
						 
		if ( !empty( $terms ) ) {
								
			foreach ( $terms as $key => $value ) {
				$term_string   .= ' ' . $value->slug;	
				$term_subtitle .= $value->name . ' / ';				
			}
		}	

		$portfolio_category[0] = $term_string;
		$portfolio_category[1] = $term_subtitle;

		return $portfolio_category;

	}

	private function get_image_caption( $image_id ) {

		$attributes = [];	
            
		$attachment = get_post( $image_id );   
	  
		$image_caption = $attachment->post_excerpt;

		return $image_caption;

	}	


}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Portfolio_Section() );
