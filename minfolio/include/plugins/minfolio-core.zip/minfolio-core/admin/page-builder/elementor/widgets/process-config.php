<?php
/**
 * Registers the process shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Process extends Widget_Base {
	
	public function get_name() {
		return 'clbr-process-widget';
	}

	public function get_title() {
		return esc_html__( 'Process', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-integration';
	}	
	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
			]
		);
		

		$process = new Repeater();

		$process->add_control(
			'process_type',
			[
				'label' => esc_html__( 'Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'text',
				'options' => [
					'text'  => esc_html__( 'Text', 'minfolio' ),
					'icon'  => esc_html__( 'Icon', 'minfolio' ),				
				],				
			]
		);	
		
		$process->add_control(
			'text_process',
			[				
				'type' => Controls_Manager::TEXT,								
				'default' => esc_html__( '01', 'minfolio' ),
				'label_block' => true,
				'condition'	=> [
					'process_type'	=> 'text'
				]					
			],
		);

		$process->add_control(
			'icon_process',
			[			
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'fa-solid',
				],
				'condition'	=> [
					'process_type'	=> 'icon'
				]		
			]
		);

		$process->add_control(
			'title',
			[					
				'label' => esc_html__( 'Title & Description', 'minfolio' ),
				'type' => Controls_Manager::TEXT,				
				'placeholder' => esc_html__( 'Enter your title', 'minfolio' ),
				'default' => esc_html__( 'Strategic Planning', 'minfolio' ),
				'label_block' => true,			
			],
		);

		$process->add_control(
			'description',
			[			
				'type' => Controls_Manager::TEXTAREA,				
				'placeholder' => esc_html__( 'Enter the description', 'minfolio' ),
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do iusmodm incididunt ut labore et dolore magna aliqua.', 'minfolio' ),
				'label_block' => true,			
			],					
		);
		
		$this->add_control(
            'process_data',
            [
                'label' => esc_html__( 'Process', 'minfolio' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [ 'process_type' => 'text', 'text_process' => '01', 'title' => esc_html__( 'Strategic Planning', 'minfolio'), 'description' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do iusmodm incididunt ut labore et dolore magna aliqua.', 'minfolio') ],
                    [ 'process_type' => 'text', 'text_process' => '02', 'title' => esc_html__( 'Design', 'minfolio'), 'description' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do iusmodm incididunt ut labore et dolore magna aliqua.', 'minfolio') ],
                    [ 'process_type' => 'text', 'text_process' => '03', 'title' => esc_html__( 'Development', 'minfolio'), 'description' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do iusmodm incididunt ut labore et dolore magna aliqua.', 'minfolio') ],
					[ 'process_type' => 'text', 'text_process' => '04', 'title' => esc_html__( 'Execution', 'minfolio'), 'description' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do iusmodm incididunt ut labore et dolore magna aliqua.', 'minfolio') ],
                ],

                'fields' => $process->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
		);

		$this->add_control(
            'separator',
            [
                'label' => esc_html__( 'Separator', 'minfolio' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'minfolio' ),
                'label_off' => esc_html__( 'No', 'minfolio' ),
                'return_value' => 'yes',
				'default' => 'yes',		
				'separator' => 'before',	
				'selectors' => [
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number:after, .clbr-process .clbr-process-steps .clbr-process-icon:after' => 'display:block',
				],				
            ]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_text_icon_style',
			[
				'label' => esc_html__( 'Text/Icon', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);		
		
		
		$this->add_control (
			'icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 28,
				],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon span' => 'font-size: {{SIZE}}{{UNIT}};',
				],				
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,							
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon i' => 'color: {{VALUE}}',			
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon span svg' => 'fill: {{VALUE}};',			
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon span svg path' => 'fill: {{VALUE}};',
				],						
			]
		);

		$this->add_control(
			'icon_stroke_color',
			[
				'label' => esc_html__( 'Icon Stroke Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,							
				'selectors' => [										
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon span svg path' => 'stroke: {{VALUE}};',
				],		
				'separator' => 'after',
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,								
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span' => 'color: {{VALUE}}',
				],				
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',				
				'selector' => '{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span',				
			]
		);	

		
		$this->add_responsive_control(
			'box_border_width',
			[
				'label' =>esc_html__( 'Border Width', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span, .clbr-process .clbr-process-steps .clbr-process-icon span' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],		
				'separator' => 'before',		
			]
		);

		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,								
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span, .clbr-process .clbr-process-steps .clbr-process-icon span' => 'border-color: {{VALUE}}',
				],				
			]
		);

		$this->add_responsive_control(
			'border_roundness',
			[
				'label' =>esc_html__( 'Roundness', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span, .clbr-process .clbr-process-steps .clbr-process-icon span' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],						
			]
		);

		$this->add_control (
			'background_size',
			[
				'label' => esc_html__( 'Background Size', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],				
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span, .clbr-process .clbr-process-steps .clbr-process-icon span' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}}',
				],				
			]
		);


		$this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'Background Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,								
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number span, .clbr-process .clbr-process-steps .clbr-process-icon span' => 'background-color: {{VALUE}}',
				],				
			]
		);

		$this->add_control(
			'separator_color',
			[
				'label' => esc_html__( 'Separator Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,								
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-number:after, {{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-icon:after' => 'background-color: {{VALUE}}',
				],		
				'separator' => 'before',		
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'title_heading',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::HEADING,				
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-title' => 'color: {{VALUE}}',
				],				
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',				
				'selector' => '{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-title',
			]
		);
		
		$this->add_control(
			'description_heading',
			[
				'label' => esc_html__( 'Description', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);	
		
		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-desc' => 'color: {{VALUE}}',
				],							
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',				
				'selector' => '{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-desc',
			]
		);

		$this->add_responsive_control(
			'description_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-process .clbr-process-steps .clbr-process-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);
				
		$this->end_controls_section();				
		

	}


	protected function render( $instance = [] ) {
		
		$params = $this->get_settings_for_display();

	?>
		<div class="clbr-process">          

			<?php foreach ( $params[ 'process_data' ] as $process_items => $item ) { ?>

				<div class="clbr-process-steps">

					<?php if( $item[ 'process_type' ] == 'icon' ) { ?>

						<div class="clbr-process-icon">
							<span><?php Icons_Manager::render_icon( $item[ 'icon_process' ], [ 'aria-hidden' => 'true' ] ); ?></span>
						</div>						

					<?php } else { ?>

						<div class="clbr-process-number">
							<span><?php echo esc_html( $item[ 'text_process' ] ); ?></span>
						</div>						

					<?php } ?>

					<h3 class="clbr-process-title"><?php echo esc_html( $item[ 'title' ] ); ?></h3>
					<p class="clbr-process-desc"><?php echo esc_html( $item[ 'description' ] ); ?></p>

				</div>

			<?php } ?>

            
            
        </div>
		
	<?php	
	}

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Process() );
