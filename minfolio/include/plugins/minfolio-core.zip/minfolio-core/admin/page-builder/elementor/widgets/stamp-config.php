<?php
/**
 * Registers the stamp shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Stamp extends Widget_Base {
	
	public function get_name() {
		return 'clbr-stamp-widget';
	}

	public function get_title() {
		return esc_html__( 'Stamp', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-button';
	}	

	public function get_script_depends() {	
		return [ 'minfolio-stamp' ];
	}	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {		
	
		$this->start_controls_section(
			'stamp_section_content',
			array(
				'label' => esc_html__( 'Content', 'minfolio' ),
			)
		);

		$this->add_control(
			'stamp_image',
			[
				'label' => esc_html__( 'Stamp Image', 'minfolio' ),
				'type' => Controls_Manager::MEDIA,
				'dynamic' => [
					'active' => true,
				],
				'default' => [					
                    'url' => Utils::get_placeholder_image_src(),
                    'id'    => -1              
				],
			]
		);	

		$this->add_control(
			'stamp_text',
			[
				'label' => esc_html__( 'Stamp Text', 'minfolio' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'default' => esc_html__( 'Minfolio is the best theme', 'minfolio' ),				
				'label_block' => true,
			]
		);

		$this->add_control(
            'enable_link',
            [
                'label' => esc_html__( 'Enable Link', 'minfolio' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'minfolio' ),
                'label_off' => esc_html__( 'No', 'minfolio' ),
                'return_value' => 'yes',
                'default' => 'yes',               
            ]
        );
		
		
		$this->add_control(
			'link_url',
			[
				'label' =>esc_html__( 'URL', 'minfolio' ),
				'type' => Controls_Manager::URL,				
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => '#',
				],
				'condition' => [
                    'enable_link' => 'yes',
                ]
			]
		);	

		$this->add_control(
			'stamp_align',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'align-left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'align-center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'align-right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],			
				'default' => 'align-center',				
			]
		);

		$this->add_responsive_control(
			'stamp_size',
			[
				'label'		=> esc_html__( 'Stamp Size', 'minfolio' ),
				'type'		=> Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 300,
                    ],
                ],
				'selectors'		=> [
					'{{WRAPPER}} .clbr-stamp, {{WRAPPER}} .clbr-stamp .clbr-stamp-text' => 'width: {{SIZE}}px; height: {{SIZE}}px;',
				],					
			]
		);		

		$this->end_controls_section(); 
		
		$this->start_controls_section(
			'section_stamp_image_style',
			[
				'label' => esc_html__( 'Stamp Image', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	

		$this->add_responsive_control(
			'stamp_pos_x',
			[
				'label'		=> esc_html__( 'Position X', 'minfolio' ),
				'type'		=> Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
				'selectors'		=> [
					'{{WRAPPER}} .clbr-stamp .clbr-stamp-image-wrap' => 'top: {{SIZE}}px;',
				],					
			]
		);	
		
		$this->add_responsive_control(
			'stamp_pos_y',
			[
				'label'		=> esc_html__( 'Position Y', 'minfolio' ),
				'type'		=> Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
				'selectors'		=> [
					'{{WRAPPER}} .clbr-stamp .clbr-stamp-image-wrap' => 'left: {{SIZE}}px;',
				],					
			]
		);		


		$this->end_controls_section(); 

		$this->start_controls_section(
			'section_stamp_text_style',
			[
				'label' => esc_html__( 'Stamp Text', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	

		$this->add_control(
			'stamp_text_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-stamp.clbr-animate-stamp .clbr-stamp-text' => 'color: {{VALUE}}',						

				],					
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'stamp_text_typography',				
				'selector' => '{{WRAPPER}} .clbr-stamp.clbr-animate-stamp .clbr-stamp-text',
			]
		);

		$this->end_controls_section();
		
	}


	protected function render( $instance = [] ) {
		
		$params = $this->get_settings_for_display();

	?>

		<div class="clbr-stamp clbr-animate-stamp <?php echo esc_attr( $params[ 'stamp_align' ] ); ?>" <?php echo minfolio_build_data_attr( $this->get_data_attributes( $params ) ); ?> >

			<?php if( $params[ 'enable_link' ] == 'yes' ) { 

				if ( ! empty( $params[ 'link_url' ][ 'url' ] ) ) {
					$this->add_link_attributes( 'stamp-link', $params[ 'link_url' ] );			
				}

				if ( ! empty( $params[ 'link_class' ] ) ) {
					$this->add_render_attribute( 'stamp-link', 'class', $params[ 'link_class' ] );
				}

				if ( ! empty( $params[ 'link_id' ] ) ) {
					$this->add_render_attribute( 'stamp-link', 'id', $params[ 'link_id' ] );
				}		

			?>

			<a <?php echo $this->get_render_attribute_string( 'stamp-link' ); ?>>
			<?php } ?>

				<?php echo $this->render_stamp_image( $params ); ?>

				<div class="clbr-stamp-text" data-count="<?php echo count( $this->str_split_unicode( $params[ 'stamp_text' ] ) ) + 1; ?>">
					<?php echo wp_kses_post( $this->get_split_text( $params[ 'stamp_text' ] ) ); ?>
				</div>

			<?php if( $params[ 'enable_link' ] == 'yes' ) { ?>	
			</a>
			<?php } ?>

		</div>		
		
	<?php }

	protected function render_stamp_image( $params ) {        

        $this->add_render_attribute( 'stamp-image', 'src', $params[ 'stamp_image' ][ 'url' ] );
        $this->add_render_attribute( 'stamp-image', 'alt', Control_Media::get_image_alt( $params[ 'stamp_image' ] ) );
        $this->add_render_attribute( 'stamp-image', 'title', Control_Media::get_image_title( $params[ 'stamp_image' ] ) );
    ?>

		<div class="clbr-stamp-image-wrap">
           	<img <?php echo $this->get_render_attribute_string( 'stamp-image' ); ?> >			
		</div>

   <?php 
   }

    

	private function get_split_text( $text ) {
	
		if ( ! empty( $text ) ) {

			$split_text = $this->str_split_unicode( $text );
			
			foreach ( $split_text as $key => $value ) {
				$split_text[ $key ] = '<span class="clbr-stamp-character">' . $value . '</span>';
			}
			
			return implode( ' ', $split_text );
		}
		
		return $text;
	}

	private function str_split_unicode( $str ) {

		return preg_split( '~~u', $str, - 1, PREG_SPLIT_NO_EMPTY );

	}


	
	private function get_data_attributes( $params ) {

		$data_attr = array();

		$data_attr[ 'data-appearing-delay' ] = ! empty( $params[ 'appearing_delay' ] ) ? intval( $params[ 'appearing_delay' ] ) : 1000;
								
		return $data_attr;

	}	


}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Stamp() );
