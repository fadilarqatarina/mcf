<?php
/**
 * Registers the icon box shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Icon_Box extends Widget_Base {
	
	public function get_name() {
		return 'clbr-icon-box-widget';
	}

	public function get_title() {
		return esc_html__( 'Icon Box', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-icon-box';
	}
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_icon_box_content',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
			]
		);

		$this->add_control(
            'icon_type', 
			[
                'label'       => esc_html__( 'Icon Type', 'minfolio' ),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options'     => [
                    'none' => [
                        'title' => esc_html__( 'None', 'minfolio' ),
                        'icon'  => 'fa fa-ban',
                    ],
                    'icon' => [
                        'title' => esc_html__( 'Icon', 'minfolio' ),
                        'icon'  => 'fa fa-paint-brush',
                    ],
                    'image' => [
                        'title' => esc_html__( 'Image', 'minfolio' ),
                        'icon'  => 'fa fa-image',
                    ],
                ],
                'default' => 'icon',
            ]
        );		

		$this->add_control(
            'icon',
            [
                'label' => esc_html__( 'Icon', 'minfolio' ),
                'type' => Controls_Manager::ICONS,
				//'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'fa-solid',
				],
                'label_block' => true,
                'condition' => [
                    'icon_type' => 'icon',                    
                ]
            ]
        );

        $this->add_control(
            'image_icon',
            [
                'label' => esc_html__( 'Choose Image', 'minfolio' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'icon_type' => 'image',
                ]
            ]
        );

		$this->add_control(
			'title',
			[					
				'label' => esc_html__( 'Title & Description', 'minfolio' ),
				'type' => Controls_Manager::TEXT,				
				'placeholder' => esc_html__( 'Enter your title', 'minfolio' ),
				'default' => esc_html__( 'Strategic Planning', 'minfolio' ),
				'label_block' => true,	
				'separator' => 'before'		
			],
		);

		$this->add_control(
			'description',
			[								
				'label' => '',
				'type' => Controls_Manager::TEXTAREA,				
				'placeholder' => esc_html__( 'Enter the description', 'minfolio' ),
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do iusmodm incididunt ut labore et dolore magna aliqua.', 'minfolio' ),
				'label_block' => true,			
			],					
		);

		$this->add_control(
			'title_size',
			[
				'label' => esc_html__( 'Title HTML Tag', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h3',
			]
		);

		$this->add_responsive_control(
			'alignment',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',		
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box' => 'text-align: {{VALUE}};',					
				],		
			]
		);	

		$this->add_control(
			'alignment_left',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [					
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'flex-flow: row;',						
				],	
				'condition' => [
                    'alignment' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'alignment_center',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'display: block;',						
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link a' => ' margin-right: 10px;',						
				],	
				'condition' => [
                    'alignment' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'alignment_right',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'flex-flow: row-reverse;',	
				],	
				'condition' => [
                    'alignment' => 'right',                    
                ]
			]
		);	

		$this->add_control(
			'tablet_alignment_left',
			[
				'label' =>esc_html__( 'Tablet Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [					
					'(tablet) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'flex-flow: row;',			
				],	
				'condition' => [
                    'alignment_tablet' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'tablet_alignment_center',
			[
				'label' =>esc_html__( 'Tablet Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [
					'(tablet) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'display: block;',							
					'(tablet) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link a' => ' margin-right: 10px;',						
				],	
				'condition' => [
                    'alignment_tablet' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'tablet_alignment_right',
			[
				'label' =>esc_html__( 'Tablet Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'(tablet) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'flex-flow: row-reverse;',	
				],	
				'condition' => [
                    'alignment_tablet' => 'right',                    
                ]
			]
		);	
	
		$this->add_control(
			'mobile_alignment_left',
			[
				'label' =>esc_html__( 'Mobile Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'left',	
				'selectors' => [				
					'(mobile) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'flex-flow: row;',			
				],	
				'condition' => [
                    'alignment_mobile' => 'left',                    
                ]
			]
		);	

		$this->add_control(
			'mobile_alignment_center',
			[
				'label' =>esc_html__( 'Mobile Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,			
				'default' => 'center',	
				'selectors' => [
					'(mobile) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'display: block;',							
					'(mobile) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link a' => ' margin-right: 10px;',						
				],	
				'condition' => [
                    'alignment_mobile' => 'center',                    
                ]
			]
		);	


		$this->add_control(
			'mobile_alignment_right',
			[
				'label' =>esc_html__( 'Mobile Alignment', 'minfolio' ),
				'type' => Controls_Manager::HIDDEN,		
				'default' => 'right',			
				'selectors' => [
					'(mobile) {{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link' => 'flex-flow: row-reverse;',	
				],	
				'condition' => [
                    'alignment_mobile' => 'right',                    
                ]
			]
		);	

		
		$this->end_controls_section();	
		
		
		$this->start_controls_section(
            'icon_box_section_link',
            [
                'label' => esc_html__( 'Read More', 'minfolio' ),
            ]
        );

        $this->add_control(
            'enable_link',
            [
                'label' => esc_html__( 'Enable Link', 'minfolio' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'minfolio' ),
                'label_off' => esc_html__( 'No', 'minfolio' ),
                'return_value' => 'yes',
                'default' => 'yes',               
            ]
        );

		$this->add_control(
            'link_text',
            [
                'label' =>esc_html__( 'Label', 'minfolio' ),
                'type' => Controls_Manager::TEXT,
                'default' =>esc_html__( 'Read more', 'minfolio' ),
                'placeholder' =>esc_html__( 'Read more', 'minfolio' ),
                'dynamic'     => array( 'active' => true ),
                'condition' => [
                    'enable_link' => 'yes',
                ]
            ]
        );


        $this->add_control(
            'link_url',
            [
                'label' =>esc_html__( 'URL', 'minfolio' ),
                'type' => Controls_Manager::URL,               
                'default' => [
                    'url' => '#',
                ],
                'dynamic' => [
                    'active' => true,
                ],
                'condition' => [
                    'enable_link' => 'yes',
                ]
            ]
        );

		$this->add_control(
            'enable_link_icon',
            [
                'label' => esc_html__( 'Enable Link Icon', 'minfolio' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'minfolio' ),
                'label_off' => esc_html__( 'No', 'minfolio' ),
                'return_value' => 'yes',
                'default' => 'yes',               
            ]
        );


		$this->end_controls_section();	
		
		
		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__( 'Icon', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);				
		
		$this->add_control (
			'icon_size',
			[
				'label' => esc_html__( 'Size', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'default' => [
					'size' => 30,
				],
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 100,
					],					
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap' => 'font-size: {{SIZE}}{{UNIT}};',
				],				
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap i' => 'color: {{VALUE}}',
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap svg path' => 'fill: {{VALUE}};',
				],						
			]
		);	

		$this->add_control(
			'icon_color_stroke',
			[
				'label' => esc_html__( 'SVG Stroke Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [						
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap svg path' => 'stroke: {{VALUE}};',
				],						
			]
		);	

		$this->add_responsive_control(
			'icon_bottom_space',
			[
				'label' => esc_html__( 'Spacing', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
            'icon_horizontal_align',
            array(
                'label'      => esc_html__( 'Move icon horizontally', 'minfolio' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array(
                    'px', 'em', 'rem',
                ),
                'range'      => array(
                    'px' => array(
                        'min' => -20,
                        'max' => 20,
                    ),
                    'em' => array(
                        'min' => -5,
                        'max' => 5,
                    ),
                    'rem' => array(
                        'min' => -5,
                        'max' => 5,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .clbr-icon-box .clbr-icon-wrap i, {{WRAPPER}} .clbr-icon-box .clbr-icon-wrap svg' => ' -webkit-transform: translateX({{SIZE}}{{UNIT}}); -ms-transform: translateX({{SIZE}}{{UNIT}}); transform: translateX({{SIZE}}{{UNIT}})',
                ),
            )
        );
						
		$this->end_controls_section();		
		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	
		
		$this->add_control(
			'heading_title',
			[
				'label' => esc_html__( 'Title', 'minfolio' ),
				'type' => Controls_Manager::HEADING,				
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-content-wrap h3' => 'color: {{VALUE}}',
				],				
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',		
				'selector' => '{{WRAPPER}} .clbr-icon-box .clbr-icon-box-content-wrap h3',
			]
		);

		$this->add_responsive_control(
			'title_bottom_space',
			[
				'label' => esc_html__( 'Spacing', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-content-wrap h3' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_control(
			'heading_desc',
			[
				'label' => esc_html__( 'Description', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator'	=> 'before'			
			]
		);
		
		$this->add_control(
			'desc_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,						
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-content-wrap p' => 'color: {{VALUE}}',
				],				
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typography',		
				'selector' => '{{WRAPPER}} .clbr-icon-box .clbr-icon-box-content-wrap p',
			]
		);

		$this->add_responsive_control(
			'desc_bottom_space',
			[
				'label' => esc_html__( 'Spacing', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-content-wrap p' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'heading_link',
			[
				'label' => esc_html__( 'Read More', 'minfolio' ),
				'type' => Controls_Manager::HEADING,
				'separator'	=> 'before'			
			]
		);
		
		$this->add_control(
			'link_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link a' => 'color: {{VALUE}}',
				],				
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_typography',		
				'selector' => '{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link a',
			]
		);

		$this->add_control(
			'link_icon_color',
			[
				'label' => esc_html__( 'Link Icon Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link svg' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],				
			]
		);

		$this->add_responsive_control(
			'link_icon_size',
			[
				'label' => esc_html__( 'Link Icon Size', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box .clbr-icon-box-link-wrap .clbr-icon-box-link svg' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		$this->end_controls_section();	

		$this->start_controls_section(
			'section_box_style',
			[
				'label' => esc_html__( 'Box', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
			]
		);	

		$this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'box_background',				
				'selector' => '{{WRAPPER}} .clbr-icon-box',
            )
        );	

		$this->add_responsive_control(
			'box_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],				
			]
		);

		$this->start_controls_tabs( 'box_tabs_style' );

		$this->start_controls_tab(
			'box_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_responsive_control(
			'box_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'box_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box' => 'border-color: {{VALUE}};',
				],				
			]
		);

		$this->add_responsive_control(
			'box_border_width',
			[
				'label' => esc_html__( 'Border Width', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-icon-box',
			]
		);
		

		$this->end_controls_tab();

		$this->start_controls_tab(
			'box_tab_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_responsive_control(
			'box_hover_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box:hover' => 'border-style: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'box_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,				
				'selectors' => [
						'{{WRAPPER}} .clbr-icon-box:hover' => 'border-color: {{VALUE}};',
				],				
			]
		);

		$this->add_responsive_control(
			'box_hover_border_width',
			[
				'label' => esc_html__( 'Border Width', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box:hover' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'box_hover_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-icon-box:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'box_hover_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-icon-box:hover',
			]
		);


		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();

	}

	protected function render( $instance = [] ) {	

		$params = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-icon-box' );

		$this->add_render_attribute( 'title-text', 'class', 'clbr-icon-box-heading' );

	?>
	
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?> >

			<?php $this->render_box_icon( $params ); ?>
           
            <div class="clbr-icon-box-content-wrap">
				<?php echo sprintf( '<%1$s %2$s>%3$s</%1$s>', Utils::validate_html_tag( $params[ 'title_size' ] ), $this->get_render_attribute_string( 'title-text' ), $params[ 'title' ] ); ?>                   
                <p class="clbr-icon-box-desc"><?php echo wp_kses_post( $params[ 'description' ] ); ?></p>
            </div>

			<?php if( $params[ 'enable_link' ] == 'yes' ) {
				$this->render_box_link( $params ); 
			} ?>

        </div>

	<?php
	}

	private function render_box_icon( $params ) {

		if( $params[ 'icon_type' ] == 'icon' ) { ?>

			<div class="clbr-icon-wrap">
				<?php Icons_Manager::render_icon( $params[ 'icon' ], [ 'aria-hidden' => 'true' ] ); ?>
			</div>	
		<?php }
		elseif( $params[ 'icon_type' ] == 'image' ) {

			if ( ! empty( $params[ 'image_icon' ][ 'url' ] ) ) {

				$this->add_render_attribute( 'image-icon', 'src', $params[ 'image_icon' ][ 'url' ] );
				$this->add_render_attribute( 'image-icon', 'alt', Control_Media::get_image_alt( $params[ 'image_icon' ] ) );
				$this->add_render_attribute( 'image-icon', 'title', Control_Media::get_image_title( $params[ 'image_icon' ] ) );
	
			?>
				<div class="clbr-icon-wrap">
					<img <?php echo $this->get_render_attribute_string( 'image-icon' ); ?> >		
				</div>
				
			<?php }
		
		}		

	}	

	private function render_box_link( $params ) {

		$this->add_link_attributes( 'box-link', $params[ 'link_url' ] );	

	?>
		<div class="clbr-icon-box-link-wrap">
			<div class="clbr-icon-box-link">	

				<a <?php echo $this->get_render_attribute_string( 'box-link' ); ?> >
					<span><?php echo esc_html( $params[ 'link_text' ] ); ?></span>
				</a>

				<?php if( $params[ 'enable_link_icon' ] == 'yes' ) { ?>
					<svg width="16" height="10" viewBox="0 0 16 10" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M1 5H15" stroke="#252525" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M11 9L15 5" stroke="#252525" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M11 1L15 5" stroke="#252525" stroke-width="1.83333" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>

				<?php } ?>

			</div>
		</div>

	<?php }
	
}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Icon_Box() );
