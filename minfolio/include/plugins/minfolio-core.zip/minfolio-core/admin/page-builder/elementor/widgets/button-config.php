<?php
/**
 * Registers the button shortcode and adds it to the Elementor
 */

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Elementor_Widget_Minfolio_Button extends Widget_Base {
	
	public function get_name() {
		return 'clbr-button-widget';
	}

	public function get_title() {
		return esc_html__( 'Button', 'minfolio' );
	}

	public function get_icon() {		
		return 'eicon-button';
	}	
	
	public function get_categories() {		
		return [ 'minfolio' ];
	}	

	protected function register_controls() {		

		$this->start_controls_section(
			'btn_section_content',
			array(
				'label' => esc_html__( 'Content', 'minfolio' ),
			)
		);

		$this->add_control(
			'btn_text',
			[
				'label' =>esc_html__( 'Label', 'minfolio' ),
				'type' => Controls_Manager::TEXT,
				'default' =>esc_html__( 'Learn more', 'minfolio' ),
				'placeholder' =>esc_html__( 'Learn more', 'minfolio' ),
				'dynamic' => [
                    'active' => true,
                ],
			]
		);


		$this->add_control(
			'btn_url',
			[
				'label' =>esc_html__( 'URL', 'minfolio' ),
				'type' => Controls_Manager::URL,
				'placeholder' => '',
				'dynamic' => [
                    'active' => true,
                ],
				'default' => [
					'url' => '#',
				],
			]
		);

		$this->add_responsive_control(
			'btn_align',
			[
				'label' =>esc_html__( 'Alignment', 'minfolio' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' =>esc_html__( 'Left', 'minfolio' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' =>esc_html__( 'Center', 'minfolio' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' =>esc_html__( 'Right', 'minfolio' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn-wrapper' => 'text-align: {{VALUE}};',
				],
				'default' => 'center',				
			]
		);

		$this->add_control(
            'btn_size',
            [
                'label' =>esc_html__( 'Size', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    'sm' => esc_html__( 'Small', 'minfolio' ),
                    'md' => esc_html__( 'Medium', 'minfolio' ),
					'lg' => esc_html__( 'Large', 'minfolio' ),
					'xl' => esc_html__( 'Extra Large', 'minfolio' ),
					'block' => esc_html__( 'Block', 'minfolio' ),
                ],             
            ]
        );
	
        $this->add_control(
            'btn_icon_heading',
            [
                'label' => esc_html__( 'Icon', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);
		
		$this->add_control(
            'btn_icon_switch',
            [
                'label' => esc_html__('Add icon? ', 'minfolio'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' =>esc_html__( 'Yes', 'minfolio' ),
                'label_off' =>esc_html__( 'No', 'minfolio' ),
            ]
		);
		
		$this->add_control(
			'btn_icon',
			[
				'label' =>esc_html__( 'Icon', 'minfolio' ),
				'type' => Controls_Manager::ICONS,			
				'label_block' => true,
				'default' => [
                    'value' => '',
				],		
				'condition'	=> [
					'btn_icon_switch'	=> 'yes'
				]		
			]
		);

        $this->add_control(
            'btn_icon_align',
            [
                'label' =>esc_html__( 'Icon Position', 'minfolio' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' =>esc_html__( 'Before', 'minfolio' ),
                    'right' =>esc_html__( 'After', 'minfolio' ),
                ],     
				'condition'	=> [
					'btn_icon_switch'	=> 'yes'
				]	          
            ]
        );

		$this->add_control(
            'btn_class_heading',
            [
                'label' => esc_html__( 'CSS Id and Class', 'minfolio' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
		);		
		
	    $this->add_control(
		    'btn_class',
		    [
			    'label' => esc_html__( 'Class', 'minfolio' ),
			    'type' => Controls_Manager::TEXT,
			    'placeholder' => esc_html__( 'Class Name', 'minfolio' ),
		    ]
	    );

	    $this->add_control(
		    'btn_id',
		    [
			    'label' => esc_html__( 'Id', 'minfolio' ),
			    'type' => Controls_Manager::TEXT,
			    'placeholder' => esc_html__( 'ID', 'minfolio' ),
		    ]
	    );


		$this->end_controls_section();


        $this->start_controls_section(
			'btn_section_style',
			[
				'label' =>esc_html__( 'Button', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_typography',
				'label' =>esc_html__( 'Typography', 'minfolio' ),
				'selector' => '{{WRAPPER}} .clbr-btn',
			]
		);

		$this->start_controls_tabs( 'btn_tabs_style' );

		$this->start_controls_tab(
			'btn_tab_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_text_color',
			[
				'label' =>esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn' => 'color: {{VALUE}};',
					'{{WRAPPER}} .clbr-btn svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            array(
				'name'     => 'btn_bg_color',
				'default' => '',
				'selector' => '{{WRAPPER}} .clbr-btn',
            )
        );		
		
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_tab_button_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_hover_color',
			[
				'label' =>esc_html__( 'Text Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .clbr-btn:hover svg path' => 'stroke: {{VALUE}}; fill: {{VALUE}};',
				],
			]
		);

	    $this->add_group_control(
		    Group_Control_Background::get_type(),
		    array(
			    'name'     => 'btn_bg_hover_color',
			    'default' => '',
			    'selector' => '{{WRAPPER}} .clbr-btn:hover',
		    )
	    );
		
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control(
			'btn_text_padding',
			[
				'label' =>esc_html__( 'Padding', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
     
		$this->end_controls_section();       


		$this->start_controls_section(
			'btn_border_style_tabs',
			[
				'label' =>esc_html__( 'Border', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'btn_border_style',
			[
				'label' => esc_html__( 'Border Type', 'minfolio' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'minfolio' ),
					'solid' => esc_html__( 'Solid', 'minfolio' ),
					'double' => esc_html__( 'Double', 'minfolio' ),
					'dotted' => esc_html__( 'Dotted', 'minfolio' ),
					'dashed' => esc_html__( 'Dashed', 'minfolio' ),
					'groove' => esc_html__( 'Groove', 'minfolio' ),
				],
				'default'	=> 'none',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn' => 'border-style: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'btn_border_dimensions',
			[
				'label' 	=> esc_html__( 'Width', 'minfolio' ),
				'type' 		=> Controls_Manager::DIMENSIONS,
				'condition'	=> [
					'btn_border_style!' => 'none'
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'xs_tabs_button_border_style' );
		$this->start_controls_tab(
			'btn_tab_border_normal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_control(
			'btn_border_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'btn_border_radius',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'default' => [
					'top' => '',
					'right' => '',
					'bottom' => '' ,
					'left' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_tab_button_border_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);
		$this->add_control(
			'btn_hover_border_color',
			[
				'label' => esc_html__( 'Color', 'minfolio' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .clbr-btn:hover' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'btn_border_radius_h',
			[
				'label' =>esc_html__( 'Border Radius', 'minfolio' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%'],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn:hover' =>  'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();


        $this->start_controls_section(
			'btn_box_shadow_style',
			[
				'label' =>esc_html__( 'Shadow', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs( 'btn_shadow_tabs_style' );

		$this->start_controls_tab(
			'btn_shadow_tabnormal',
			[
				'label' =>esc_html__( 'Normal', 'minfolio' ),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'btn_box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-btn',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'btn_shadow_tab_button_hover',
			[
				'label' =>esc_html__( 'Hover', 'minfolio' ),
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
			  'name' => 'btn_hover_box_shadow_group',
			  'selector' => '{{WRAPPER}} .clbr-btn:hover',
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

        $this->start_controls_section(
			'btn_icon_style',
			[
				'label' =>esc_html__( 'Icon', 'minfolio' ),
				'tab' => Controls_Manager::TAB_STYLE,		
				'condition'	=> [
					'btn_icon_switch'	=> 'yes'
				]			
			]
		);

		$this->add_responsive_control(
			'btn_normal_icon_font_size',
			array(
				'label'      => esc_html__( 'Font Size', 'minfolio' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array(
					'px', 'em', 'rem',
				),
				'range'      => array(
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .clbr-btn .clbr-btn-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .clbr-btn .clbr-btn-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'btn_normal_icon_padding_left',
			[
				'label' => esc_html__( 'Add space after icon', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn i, {{WRAPPER}} .clbr-btn svg' => 'margin-right: {{SIZE}}{{UNIT}};',					
				],
				'condition' => [
					'btn_icon_align' => 'left'
				]
			]
		);
		
		$this->add_responsive_control(
			'btn_normal_icon_padding_right',
			[
				'label' => esc_html__( 'Add space before icon', 'minfolio' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' =>1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .clbr-btn i, {{WRAPPER}} .clbr-btn svg' => 'margin-left: {{SIZE}}{{UNIT}};',					
				],
				'condition' => [
					'btn_icon_align' => 'right'
				]
			]
		);

        $this->add_responsive_control(
            'btn_normal_icon_vertical_align',
            array(
                'label'      => esc_html__( 'Move icon  Vertically', 'minfolio' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => array(
                    'px', 'em', 'rem',
                ),
                'range'      => array(
                    'px' => array(
                        'min' => -20,
                        'max' => 20,
                    ),
                    'em' => array(
                        'min' => -5,
                        'max' => 5,
                    ),
                    'rem' => array(
                        'min' => -5,
                        'max' => 5,
                    ),
                ),
                'selectors'  => array(
                    '{{WRAPPER}} .clbr-btn i, {{WRAPPER}} .clbr-btn svg' => ' -webkit-transform: translateY({{SIZE}}{{UNIT}}); -ms-transform: translateY({{SIZE}}{{UNIT}}); transform: translateY({{SIZE}}{{UNIT}})',
                ),
            )
        );

		$this->end_controls_section();

		
	}


	protected function render( $instance = [] ) {
		
		$params = $this->get_settings_for_display();

		$this->add_render_attribute( 'wrapper', 'class', 'clbr-btn-wrapper' );
		$this->add_render_attribute( 'button', 'class', 'clbr-btn' );
		
		if ( ! empty( $params[ 'btn_url' ][ 'url' ] ) ) {
			$this->add_link_attributes( 'button', $params[ 'btn_url' ] );			
		}

		if ( ! empty( $params[ 'btn_class' ] ) ) {
			$this->add_render_attribute( 'button', 'class', $params[ 'btn_class' ] );
		}

		if ( ! empty( $params[ 'btn_id' ] ) ) {
			$this->add_render_attribute( 'button', 'id', $params[ 'btn_id' ] );
		}

		if ( ! empty( $params[ 'btn_size' ] ) ) {
			$this->add_render_attribute( 'button', 'class', 'clbr-btn-' . $params[ 'btn_size' ] );
		}
		
		?>
		
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
			<a <?php echo $this->get_render_attribute_string( 'button' ); ?>>
				<?php $this->render_text( $params ); ?>
			</a>
		</div>
		
	<?php }

	private function render_text( $params ) { ?>
	

		<?php if ( ! empty( $params[ 'btn_icon_switch' ] ) && $params[ 'btn_icon_switch' ] == 'yes' ) { 
			
			$this->add_render_attribute( 'icon', 'class', 'clbr-btn-icon' );

			if ( ! empty( $params[ 'btn_icon_align' ] ) ) {
				$this->add_render_attribute( 'icon', 'class', 'clbr-btn-icon-' . $params[ 'btn_icon_align' ] );
			}						
			
		?>

			<?php if ( $params[ 'btn_icon_align' ] == 'right' ) { ?>
				<span><?php echo esc_html( $params[ 'btn_text' ] ); ?></span>
			<?php } ?>

			<?php if( ! empty( $params[ 'btn_icon' ][ 'value' ] ) ) { ?>
				<span <?php echo $this->get_render_attribute_string( 'icon' ); ?> >				
					<?php Icons_Manager::render_icon( $params[ 'btn_icon' ], [ 'aria-hidden' => 'true' ] ); ?>				
				</span>
			<?php } ?>

			<?php if ( $params[ 'btn_icon_align' ] == 'left' ) { ?>
				<span><?php echo esc_html( $params[ 'btn_text' ] ); ?></span>
			<?php } ?>

		<?php } else { ?> 

			<span><?php echo esc_html( $params[ 'btn_text' ] ); ?></span>		

		<?php } ?>


	<?php }

}

Plugin::instance()->widgets_manager->register( new Elementor_Widget_Minfolio_Button() );
