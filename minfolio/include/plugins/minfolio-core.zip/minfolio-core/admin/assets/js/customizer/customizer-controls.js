
jQuery( document ).ready(function($) {

	"use strict";

	var api = wp.customize;

	syncPreviewButtons();

	/**
	 * Sync device preview button from WordPress
	 */
	function syncPreviewButtons() {
		// Bind device changes from WordPress default.
		api.previewedDevice.bind( function ( newDevice ) {
			responsivePreview( newDevice );
		});
	}  

	/**
	* Setup device preview.		 
	*/
	function responsivePreview( device ) {

		$( '.clbr-responsive-options button' ).removeClass( 'active' );
		$( '.clbr-responsive-options .preview-' + device ).addClass( 'active' );
		$( '.clbr-control-device' ).removeClass( 'active' );
		$( '.clbr-control-' + device ).addClass( 'active' );
		
	}

	// Display desktop control by default.
	$( '.clbr-control-desktop' ).addClass( 'active' );

	
	$( '.clbr-responsive-options button' ).on( 'click', function (e) {

		var device = this.getAttribute( 'data-device' );

		responsivePreview( device );

		// Trigger WordPress device event.
		api.previewedDevice.set( device );

	});


	/**
	* Gradient Color Custom Control
	*/


	$( '.clbr-control-gradient-color' ).each( function() {

		var inputEl = $( this ).find( 'input' ).get(0);

		new lc_color_picker( inputEl, {
			transparency    : true,
            open_on_focus   : true,
            wrap_width      : '100%',
            preview_style   : {
                input_padding   : 45,
                side            : 'left',
                width           : 40,
            },
			on_change: function( newValue ) { 

				var key = $( inputEl ).attr( 'id' );
								
				wp.customize( key, function ( obj ) {
					obj.set( newValue );
				} );
			
			},
			fallback_colors : ['#ff0', 'linear-gradient(90deg, rgba(255, 255, 255, .4), #000)'],
		});

	});


	/**
	* TinyMCE Custom Control
	* 	
	*/

	$( '.customize-control-tinymce-editor' ).each( function() {

		// Get the toolbar strings that were passed from the PHP Class
		var tinyMCEToolbar1String = _wpCustomizeSettings.controls[ $( this ).attr( 'id' )].clbr_tinymce_toolbar1;
		var tinyMCEToolbar2String = _wpCustomizeSettings.controls[ $( this ).attr( 'id' )].clbr_tinymce_toolbar2;
		var tinyMCEMediaButtons = _wpCustomizeSettings.controls[ $( this ).attr( 'id' )].clbr_tinymce_mediabuttons;

		wp.editor.initialize( $( this ).attr( 'id' ), {
			tinymce: {
				wpautop: true,
				toolbar1: tinyMCEToolbar1String,
				toolbar2: tinyMCEToolbar2String
			},
			quicktags: true,
			mediaButtons: tinyMCEMediaButtons
		});

	});

	$( document ).on( 'tinymce-editor-init', function( event, editor ) {
		editor.on( 'change', function(e) {
			tinyMCE.triggerSave();
			$( '#' + editor.id ).trigger( 'change ');
		});
	});


	/**
	* Sortable Custom Control	 	 
	*/

	$( '.clbr-control-sortable .sortable' ).sortable({

		placeholder: "item-ui-state-highlight",
		update: function( event, ui ) {
			getAllCheckboxes( $( this ).parent() );
		}

	});

	$( '.clbr-control-sortable .sortable-item-checkbox').on( 'change', function () {
		getAllCheckboxes( $( this ).parent().parent().parent() );
	});

	// Get the values from the checkboxes and add to our hidden field
	function getAllCheckboxes($element) {

		var inputValues = $element.find( '.sortable-item-checkbox' ).map( function() {

			if( $( this ).is( ':checked' ) ) {
				return $( this ).val();
			}
		}).toArray();

		$element.find('.customize-control-sortable-item-checkbox').val( inputValues ).trigger( 'change' );

	}

	/**
	* Color Custom Control	 	 
	*/

	$( '.clbr-control-color' ).each( function() {

		var colorPickerId = $( this ).attr( 'id' );	
		var placement = $( this ).data( 'placement' );	
		var defaultVal = $( '#' + colorPickerId ).val();

		var colorPickerDefaultCustomAnchor = new ColorPicker.Default( '#' + colorPickerId + '-anchor', {	
			color: defaultVal,	
			placement: placement,
			history: {
				hidden: true
			}
		});

		colorPickerDefaultCustomAnchor.on('change', function( color ) {		

			$( '#' + colorPickerId ).val( color.rgba );

			wp.customize( colorPickerId, function ( obj ) {
				obj.set( color.rgba );
			});

		});

	});

	/**
	* Multi Color Custom Control	 	 
	*/

	$( '.clbr-control-multi-colors' ).each( function() {

		var colorPickerId = $( this ).attr( 'id' );	
		var placement = $( this ).data( 'placement' );	
		var defaultVal = $( '#' + colorPickerId ).val();

		defaultVal = JSON.parse( defaultVal );	

		var colorPickerRegular = new ColorPicker.Default( '#' + colorPickerId + '-regular', {	
			color: defaultVal[ 'regular' ],	
			placement: placement,
			history: {
				hidden: true
			}
		});

		$( '#' + colorPickerId + '-regular' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color', defaultVal[ 'regular' ] );	

		var colorPickerHover = new ColorPicker.Default( '#' + colorPickerId + '-hover', {	
			color: defaultVal[ 'hover' ],	
			placement: placement,
			history: {
				hidden: true
			}
		});

		$( '#' + colorPickerId + '-hover' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color', defaultVal[ 'hover' ] );

		var colorPickerActive = new ColorPicker.Default( '#' + colorPickerId + '-active', {	
			color: defaultVal[ 'active' ],	
			placement: placement,
			history: {
				hidden: true
			}
		});

		$( '#' + colorPickerId + '-active' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color', defaultVal[ 'active' ] );

		colorPickerRegular.on('change', function( color ) {	
			
			$( '#' + colorPickerId + '-regular' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color', color.rgba );	
			var hoverColor = $( '#' + colorPickerId + '-hover' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color' );
			var activeColor = $( '#' + colorPickerId + '-active' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color' );

			var colorValue = { "regular" : color.rgba, "hover" : hoverColor, "active" : activeColor};
			var colorValueStr = JSON.stringify( colorValue );

			$( '#' + colorPickerId ).val( colorValueStr );

			wp.customize( colorPickerId, function ( obj ) {
				obj.set( colorValue );
			});

		});

		colorPickerHover.on('change', function( color ) {		

			$( '#' + colorPickerId + '-hover' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color', color.rgba );	
			var regularColor = $( '#' + colorPickerId + '-regular' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color' );
			var activeColor = $( '#' + colorPickerId + '-active' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color' );

			var colorValue = { "regular" : regularColor, "hover" : color.rgba, "active" : activeColor};
			var colorValueStr = JSON.stringify( colorValue );

			$( '#' + colorPickerId ).val( colorValueStr );

			wp.customize( colorPickerId, function ( obj ) {
				obj.set( colorValue  );
			});

		});

		colorPickerActive.on('change', function( color ) {		

			$( '#' + colorPickerId + '-active' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color', color.rgba );	
			var regularColor = $( '#' + colorPickerId + '-regular' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color' );
			var hoverColor = $( '#' + colorPickerId + '-hover' ).find( '.colorpicker-circle-anchor__color' ).attr( 'data-color' );

			var colorValue = { "regular" : regularColor, "hover" : hoverColor, "active" : color.rgba};
			var colorValueStr = JSON.stringify( colorValue );

			$( '#' + colorPickerId ).val( colorValueStr );

			wp.customize( colorPickerId, function ( obj ) {
				obj.set( colorValue  );
			});

		});

	});


	/**
	* Global Colors Custom Control	 	 
	*/

	$( '.clbr-control-global-color' ).each( function() {
	
		var global_colors_control = _wpCustomizeSettings.controls[ $( this ).attr( 'id' ) ];

		var global_colors = global_colors_control.global_colors;

		var global_color_palette = [];

		for ( let key in global_colors ) {	
			global_color_palette.push( { color: global_colors[ key ] } );
		};	

		var colorPickerId = $( this ).attr( 'id' );	
		var placement = $( this ).data( 'placement' );	
		var defaultVal = $( '#' + colorPickerId ).val();

		defaultVal = JSON.parse( defaultVal );	
	

		var colorPickerLocalCustomAnchor = new ColorPicker.Default( '#' + colorPickerId + '-anchor', {	
			color: ( defaultVal[ 'local' ] != 'transparent' ) ? defaultVal[ 'local' ] : '',	
			placement: placement,
			history: {
				hidden: true
			}
		});

		if( defaultVal[ 'local' ] == 'transparent' ) {
			$( '#' + colorPickerId + '-anchor' ).find( '.colorpicker-circle-anchor__color' ).css( 'background', 'transparent' );
		}

		var colorPickerGlobalCustomAnchor = new ColorPicker.GlobalColorPicker( '#' + colorPickerId + '-global-anchor', {	
			color: defaultVal[ 'global' ],	
			palette: global_color_palette,
		});

		if( defaultVal[ 'global' ] == 'transparent' ) {			
			$( '#' + colorPickerId + '-global-anchor' ).find( '.colorpicker-circle-anchor__color' ).css( 'background', 'transparent' );
		}

		colorPickerLocalCustomAnchor.on('change', function( color ) {	
			
			var colorValue = { "local" : color.rgba, "global" : 'transparent', "value" : color.rgba };
			var colorValueStr = JSON.stringify( colorValue );

			$( '#' + colorPickerId ).val( colorValueStr );

			wp.customize( colorPickerId, function ( obj ) {
				obj.set( colorValue );
			});

			$( '#' + colorPickerId + '-global-anchor' ).find( '.colorpicker-circle-anchor__color' ).css( 'background', 'transparent' );

		});

		colorPickerGlobalCustomAnchor.on('change', function( color ) {		

			var colorValue = { "local" : 'transparent', "global" : color.rgba, "value" : color.rgba };
			var colorValueStr = JSON.stringify( colorValue );

			$( '#' + colorPickerId ).val( colorValueStr );

			wp.customize( colorPickerId, function ( obj ) {
				obj.set( colorValue );
			});

			$( '#' + colorPickerId + '-anchor' ).find( '.colorpicker-circle-anchor__color' ).css( 'background', 'transparent' );

		});

	});

	/**
	* Padding Custom Control	 	 
	*/

	$( '.clbr-control-padding-wrapper .customize-control-padding-value' ).on('keyup change', function () {

        var parent = $( this ).parents( '.clbr-control-padding-wrapper' ),
            dbstore_cache = $( '.clbr-padding-value', parent ),
            dbstore = dbstore_cache.val(),
            device_type = $( this ).data( 'area-type' );

		var control_id = dbstore_cache.attr( 'id' );

        dbstore = dbstore === '' ? {} : JSON.parse(dbstore);

        dbstore[device_type] = this.value;

        dbstore_cache.val( JSON.stringify( dbstore ) );

		wp.customize( control_id, function ( obj ) {
			obj.set( JSON.stringify( dbstore ) );
		});

    })

	/**
	* Responsive Padding Custom Control	 	 
	*/
	$( '.clbr-responsive-padding-wrapper .customize-control-responsive-padding-value' ).on( 'keyup change', function () {

        var parent = $( this ).parents( '.clbr-responsive-padding-wrapper' ),
            dbstore_cache = $( '.clbr-control-responsive-padding', parent ),
            dbstore = dbstore_cache.val(),
            device_type = $( this ).data( 'area-device-type' );

		var control_id = dbstore_cache.attr( 'id' );

        dbstore = dbstore === '' ? {} : JSON.parse( dbstore );

        dbstore[ device_type ] = this.value;

        dbstore_cache.val( JSON.stringify( dbstore ) );

		wp.customize( control_id, function ( obj ) {
			obj.set( JSON.stringify( dbstore ) );
		});

    });

	/**
	* Responsive Slider Custom Control	 	 
	*/

	$( '.clbr-input-slider-control' ).each( function () {

		var sliderValue = $( this ).find( '.customize-control-slider-value' ).val();
		var sliderNumber = sliderValue.match(/\d+/);
		var newSlider = $( this ).find( '.slider' );
		var sliderMinValue = parseFloat( newSlider.attr( 'slider-min-value' ) );
		var sliderMaxValue = parseFloat( newSlider.attr( 'slider-max-value' ) );
		var sliderStepValue = parseFloat( newSlider.attr( 'slider-step-value' ) );

		newSlider.slider({
			value: sliderNumber,
			min: sliderMinValue,
			max: sliderMaxValue,
			step: sliderStepValue,
			change: function (e, ui) {
				// Only executed after the sliding stopped.
				this.parentNode.querySelector( '.customize-control-slider-value' ).dispatchEvent( new Event( 'change' ) );
				this.parentNode.querySelector( '.customize-control-slider-value' ).dispatchEvent( new Event( 'keyup' ) );
			}
		});

	});

	// Change the value of the input field as the slider is moved
	$( '.slider' ).on( 'slide', function ( event, ui ) {

		var sliderValue = $( this ).parent().find( '.customize-control-slider-value' ).val();
		var sliderSuffix = sliderValue.replace(/\d+/g, '');

		this.parentNode.querySelector( '.customize-control-slider-value' ).value = ui.value + sliderSuffix;
		this.parentNode.querySelector( '.customize-control-slider-value' ).dispatchEvent( new Event( 'change' ) );
		this.parentNode.querySelector( '.customize-control-slider-value' ).dispatchEvent( new Event( 'keyup' ) );
	});

	// Reset slider and input field back to the default value
	$( '.slider-reset' ).on( 'click', function () {

		var resetValue = $( this ).attr( 'slider-reset-value' );
		var sliderNumber = resetValue.match(/\d+/);
		$( this ).parent().find( '.customize-control-slider-value' ).val( resetValue );
		$( this ).parent().find( '.slider' ).slider( 'value', sliderNumber );
	});


	// Update slider if the input field loses focus as it's most likely changed
	$( '.customize-control-slider-value' ).blur(function () {

		var resetValue = $( this ).val();
		var sliderNumber = resetValue.match(/\d+/);
		var sliderSuffix = resetValue.replace(/\d+/g, '');
		var slider = $( this ).parent().find( '.slider' );
		var sliderMinValue = parseInt( slider.attr( 'slider-min-value' ) );
		var sliderMaxValue = parseInt( slider.attr( 'slider-max-value' ) );

		// Make sure our manual input value doesn't exceed the minimum & maxmium values
		if ( sliderNumber < sliderMinValue ) {
			sliderNumber = sliderMinValue;
			$( this ).val( sliderNumber + sliderSuffix );
		}

		if ( sliderNumber > sliderMaxValue ) {
			sliderNumber = sliderMaxValue;
			$( this ).val( sliderNumber + sliderSuffix );
		}

		$( this ).parent().find( '.slider' ).slider( 'value', sliderNumber );

	});


	$( '.clbr-responsive-input-slider-wrapper .customize-control-slider-value').on('keyup', function () {

        var parent = $( this ).parents( '.clbr-responsive-input-slider-wrapper' ),
            dbstore_cache = $( '.clbr-responsive-input-slider', parent ),
            dbstore = dbstore_cache.val(),
            device_type = $( this ).data( 'device-type' );

		var control_id = dbstore_cache.attr( 'id' );

        dbstore = dbstore === '' ? {} : JSON.parse( dbstore );

        dbstore[ device_type ] = $( this ).val();

        dbstore_cache.val( JSON.stringify( dbstore ) );

		wp.customize( control_id, function ( obj ) {
			obj.set( JSON.stringify( dbstore ) );
		});

    });	
	

	/* Responsive typography control */
	
	$( '.clbr-control-typography-wrapper' ).each( function() {

		var typographyControl = $( this ).find( '.clbr-control-typography' );
		var typographyReset = $( this ).find( '.typography-reset' );

		var fontPickerId = typographyControl.attr( 'id' );	
		var placement =  typographyControl.data( 'placement' );	

		var fontPickerDefaultCustomAnchor = new FontPicker.Default( '#' + fontPickerId + '-anchor', {				
			placement: placement,			
		});

		fontPickerDefaultCustomAnchor.on('changeFont', function( font ) {	

			wp.customize( fontPickerId, function ( obj ) {
				obj.set( font );
			});

			typographyReset.addClass( 'active' );

		});

		fontPickerDefaultCustomAnchor.on('changeLayout', function( e, device ) {	   			
			
			api.previewedDevice.set( device );		
			e.preventDefault();			

		});		

		typographyReset.on( 'click', function ( params ) {

			var resetVal = typographyControl.attr( 'data-default' );

			typographyControl.val( resetVal );

			fontPickerDefaultCustomAnchor.setFont();

			wp.customize( fontPickerId, function ( obj ) {
				obj.set( resetVal );
			});

			typographyReset.removeClass( 'active' );

			return false;
			
		});

	});
	

});