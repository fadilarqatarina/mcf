(function($) {

	var customizeBreakpoints = {
		tablet: 1024,
		mobile: 767
	};

	var mediaQueries = {
		tablet: 'max-width: ' + ( customizeBreakpoints.tablet - 1 ).toString() + 'px',
		mobile: 'max-width: ' + ( customizeBreakpoints.mobile - 1 ).toString() + 'px'
	};

	/**
	 * Setup style tag.
	 *	
	 */
	function setupStyleTag(id) {

		var styleTag = document.querySelector( "[data-id=" + id + "]" );
		
		if( styleTag !== null ) {			
    		styleTag.parentNode.removeChild( styleTag );
		}

		var tag = document.createElement( 'style' );
		tag.dataset.id = id;
		tag.className = 'clbr-customize-live-style';		

		document.head.append(tag);

		return tag;
	}

	function buildPaddingCSS( controlValue, selector ) {

		var obj = JSON.parse( controlValue ),
			desktop_top = obj.desktop_top,
			desktop_right = obj.desktop_right,
			desktop_bottom = obj.desktop_bottom,
			desktop_left = obj.desktop_left,
			tablet_top = obj.tablet_top,
			tablet_right = obj.tablet_right,
			tablet_bottom = obj.tablet_bottom,
			tablet_left = obj.tablet_left,
			mobile_top = obj.mobile_top,
			mobile_right = obj.mobile_right,
			mobile_bottom = obj.mobile_bottom,
			mobile_left = obj.mobile_left;		

		var padding_css = '';
		var desktop_padding = '';
		var tablet_padding = '';
		var mobile_padding = '';

		desktop_padding += ( desktop_top == undefined )    ? '' : 'padding-top: ' + desktop_top + 'px;';
		desktop_padding += ( desktop_right == undefined )  ? '' : 'padding-right: ' + desktop_right + 'px;';
		desktop_padding += ( desktop_bottom == undefined ) ? '' : 'padding-bottom: ' + desktop_bottom + 'px;';
		desktop_padding += ( desktop_left == undefined )   ? '' : 'padding-left: ' + desktop_left + 'px;';

		tablet_padding += ( tablet_top == undefined )    ? '' : 'padding-top: ' + tablet_top + 'px;';
		tablet_padding += ( tablet_right == undefined )  ? '' : 'padding-right: ' + tablet_right + 'px;';
		tablet_padding += ( tablet_bottom == undefined ) ? '' : 'padding-bottom: ' + tablet_bottom + 'px;';
		tablet_padding += ( tablet_left=== undefined )   ? '' : 'padding-left: ' + tablet_left + 'px;';

		mobile_padding += ( mobile_top == undefined )    ? '' : 'padding-top: ' + mobile_top + 'px;';
		mobile_padding += ( mobile_right == undefined )  ? '' : 'padding-right: ' + mobile_right + 'px;';
		mobile_padding += ( mobile_bottom == undefined ) ? '' : 'padding-bottom: ' + mobile_bottom + 'px;';
		mobile_padding += ( mobile_left == undefined )   ? '' : 'padding-left: ' + mobile_left + 'px;';
		
		padding_css += selector + '{' + desktop_padding + '}';

		if( tablet_padding != '' ) {
			padding_css += '@media (' + mediaQueries.tablet + ') {' + selector + '{' + tablet_padding + '}}';
		}

		if( mobile_padding != '' ) {
			padding_css += '@media (' + mediaQueries.mobile + ') {' + selector + '{' + mobile_padding + '}}';
		}	
				
		return padding_css;
		
	}

	function buildTypographyCSS( controlValue, selector ) {

		var typography_css = '';

		var desktop_typography = '';
		var tablet_typography = '';
		var mobile_typography = '';

		var obj = JSON.parse( controlValue ),
			font_family = obj[ 'font-family' ],
			font_weight = obj[ 'font-weight' ],
			text_transform = obj[ 'text-transform' ],
			font_style = obj[ 'font-style' ],
			desktop_font_size = obj[ 'desktop-font-size' ],
			tablet_font_size = obj[ 'tablet-font-size' ],
			mobile_font_size = obj[ 'mobile-font-size' ],
			desktop_line_height = obj[ 'desktop-line-height' ],
			tablet_line_height = obj[ 'tablet-line-height' ],
			mobile_line_height = obj[ 'mobile-line-height' ],
			desktop_letter_spacing = obj[ 'desktop-letter-spacing' ],
			tablet_letter_spacing = obj[ 'tablet-letter-spacing' ],
			mobile_letter_spacing = obj[ 'mobile-letter-spacing' ];

		desktop_typography += ( font_family == undefined )    ? '' : 'font-family: var(--e-global-typography-' + font_family + '-font-family );';
		desktop_typography += ( font_weight == undefined )  ? '' : 'font-weight: ' + font_weight + ';';
		desktop_typography += ( text_transform == undefined ) ? '' : 'text-transform: ' + text_transform + ';';
		desktop_typography += ( font_style == undefined )   ? '' : 'font-style: ' + font_style + ';';
		desktop_typography += ( desktop_font_size == undefined )   ? '' : 'font-size: ' + desktop_font_size + 'px;';
		desktop_typography += ( desktop_line_height == undefined )   ? '' : 'line-height: ' + desktop_line_height + 'px;';
		desktop_typography += ( desktop_letter_spacing == undefined )   ? '' : 'letter-spacing: ' + desktop_letter_spacing + 'px;';
	
		tablet_typography += ( tablet_font_size == undefined )    ? '' : 'font-size: ' + tablet_font_size + 'px;';
		tablet_typography += ( tablet_line_height == undefined )  ? '' : 'line-height: ' + tablet_line_height + 'px;';
		tablet_typography += ( tablet_letter_spacing == undefined ) ? '' : 'letter-spacing: ' + tablet_letter_spacing + 'px;';
			
		mobile_typography += ( mobile_font_size == undefined )    ? '' : 'font-size: ' + mobile_font_size + 'px;';
		mobile_typography += ( mobile_line_height == undefined )  ? '' : 'line-height: ' + mobile_line_height + 'px;';
		mobile_typography += ( mobile_letter_spacing == undefined ) ? '' : 'letter-spacing: ' + mobile_letter_spacing + 'px;';
		
		typography_css += selector + '{' + desktop_typography + '}';

		if( tablet_typography != '' ) {
			typography_css += '@media (' + mediaQueries.tablet + ') {' + selector + '{' + tablet_typography + '}}';
		}
	
		if( mobile_typography != '' ) {
			typography_css += '@media (' + mediaQueries.mobile + ') {' + selector + '{' + mobile_typography + '}}';
		}	
					
		return typography_css;
			
	}
	
	//branding
	wp.customize( 'menu-text-logo-dark-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '#site-branding .dark-text-logo' ).css( 'color', controlValue[ 'value' ] );
						
		});

	});

	wp.customize( 'menu-text-logo-light-color', function( control ) {

		control.bind( function( controlValue ) {
				
			$( '#site-branding .light-text-logo' ).css( 'color', controlValue[ 'value' ] );			
			
		});

	});

	wp.customize( 'menu-text-logo-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'menu-text-logo-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '#site-branding .light-text-logo, #site-branding .dark-text-logo' );
			
		});

	});

	

	//Header
		
	wp.customize( 'menu-bg-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '#masthead.site-header:not(.transparent), #masthead.site-header.transparent.is-stuck' ).css( 'background-color', controlValue );
			
		});

	});

	//Menu Solid link color
	wp.customize( 'menu-link-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '#masthead.site-header:not(.transparent) #site-navigation .menu > li > a' ).css( 'color', controlValue[ 'regular' ] );      
            $( '#masthead.site-header:not(.transparent) #site-navigation .menu > li:hover > a' ).css( 'color', controlValue[ 'hover' ] );         
            $( '#masthead.site-header:not(.transparent) #site-navigation .menu > li ul li > a' ).css( 'color', controlValue[ 'regular' ] );         
            $( '#masthead.site-header:not(.transparent) #site-navigation .menu > li ul li:hover > a' ).css( 'color', controlValue[ 'hover' ] );    
            $( '#masthead.site-header:not(.transparent) #site-navigation .menu > li.current-menu-item > a' ).css( 'color', controlValue[ 'active' ] );     
            $( '#masthead.site-header:not(.transparent) #site-navigation .menu > li.current-menu-ancestor > a' ).css( 'color', controlValue[ 'active' ] );  
			$( '#masthead.site-header:not(.transparent).centered-menu .menu-contact a' ).css( 'color', controlValue[ 'regular' ] );			
			$( '#masthead.site-header:not(.transparent).centered-menu .menu-contact svg' ).css( 'stroke', controlValue[ 'regular' ] );			
			$( '#masthead.site-header:not(.transparent).centered-menu .menu-contact a:hover' ).css( 'color', controlValue[ 'hover' ] );	
						
		});

	});

	//Menu Tranparent link color
	wp.customize( 'menu-transparent-link-color', function( control ) {

		control.bind( function( controlValue ) {	
			
			$( '#masthead.site-header.transparent:not(.is-stuck) #site-navigation .menu > li > a' ).css( 'color', controlValue[ 'regular' ] );
            $( '#masthead.site-header.transparent:not(.is-stuck) #site-navigation .menu > li:hover > a' ).css( 'color', controlValue[ 'hover' ] );           
            $( '#masthead.site-header.transparent:not(.is-stuck) #site-navigation .menu > li.current-menu-item > a' ).css( 'color', controlValue[ 'active' ] );
            $( '#masthead.site-header.transparent:not(.is-stuck) #site-navigation .menu > li.current-menu-ancestor > a' ).css( 'color', controlValue[ 'active' ] );			
			$( '#masthead.site-header.transparent:not(.is-stuck).centered-menu .menu-contact a' ).css( 'color', controlValue[ 'regular' ] );			
			$( '#masthead.site-header.transparent:not(.is-stuck).centered-menu .menu-contact svg' ).css( 'stroke', controlValue[ 'regular' ] );			
			$( '#masthead.site-header.transparent:not(.is-stuck).centered-menu .menu-contact a:hover' ).css( 'color', controlValue[ 'hover' ] );			
			
		});

	});

	wp.customize( 'menu-typo', function( control ) {

		control.bind( function( controlValue ) {
			
			var styleTag = setupStyleTag( 'menu-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '#masthead.site-header.standard #site-navigation .menu > li > a, #masthead.site-header.standard.centered-menu .menu-contact a' );	
			
		});

	});



	//Footer

	//footer background color
	wp.customize( 'footer-bg-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer' ).css( 'background-color', controlValue );
			
		});

	});

	//footer border color
	wp.customize( 'footer-border-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer .site-info-wrap' ).css( 'border-top-color', controlValue );
			
		});

	});

	//footer widget heading color
	wp.customize( 'footer-heading-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer .widget-area .widget h6' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'footer-heading-typo', function( control ) {

		control.bind( function( controlValue ) {	
			
			var styleTag = setupStyleTag( 'footer-heading-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.site-footer .widget-area .widget h6, .site-footer .widget-area .widget h1, .site-footer .widget-area .widget h2, .site-footer .widget-area .widget h3, .site-footer .widget-area .widget h4, .site-footer .widget-area .widget h5, .site-footer .widget-area .widget h6' );
			
		});

	});

	//footer widget text color
	wp.customize( 'footer-text-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer .widget-area .widget li, .site-footer .widget-area .widget a, .site-footer .widget-area .widget p, .site-footer .widget li, .site-footer .widget a ' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'footer-text-typo', function( control ) {

		control.bind( function( controlValue ) {	
			
			var styleTag = setupStyleTag( 'footer-text-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.site-footer .widget-area .widget li, .site-footer .widget-area .widget a, .site-footer .widget-area .widget p' );
						
		});

	});

	//footer contact info heading color
	wp.customize( 'footer-contact-heading-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer .widget-area .widget-contact-info h2' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'footer-contact-heading-typo', function( control ) {

		control.bind( function( controlValue ) {
			
			var styleTag = setupStyleTag( 'footer-contact-heading-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.site-footer .widget-area .widget-contact-info h2' );
			
		});

	});

	//footer contact info text color
	wp.customize( 'footer-contact-text-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer .widget-area .widget li, .site-footer .widget-area .widget li span a' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'footer-contact-text-typo', function( control ) {

		control.bind( function( controlValue ) {	
			
			var styleTag = setupStyleTag( 'footer-contact-text-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.site-footer .widget-area .widget li, .site-footer .widget-area .widget li span a' );
			
		});

	});


	//footer data text color
	wp.customize( 'footer-data-text-color', function( control ) {

		control.bind( function( controlValue ) {		

			$( '.site-footer .site-info-wrap .site-author, .site-footer .site-info-wrap .site-copyright' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'footer-data-text-typo', function( control ) {

		control.bind( function( controlValue ) {	
			
			var styleTag = setupStyleTag( 'footer-data-text-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.site-footer .site-info-wrap .site-author, .site-footer .site-info-wrap .site-copyright' );
			
		});

	});

	
	//Blog

	//blog background color
	wp.customize( 'blog-banner-bg-color', function( control ) {

		control.bind( function( controlValue ) {

			$( 'body.blog .blog-banner, body.single .blog-banner' ).css( 'background-color', controlValue );
		});

	});
	
	//blog overlay color
	wp.customize( 'blog-banner-bg-color-overlay', function( control ) {

		control.bind( function( controlValue ) {		

			$( 'body.blog .blog-banner .color-overlay, body.single .blog-banner .color-overlay' ).css( 'background', controlValue );
			
		});

	});

	//blog banner padding color
	wp.customize( 'blog-banner-padding', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-banner-padding' );

			styleTag.innerHTML = buildPaddingCSS( controlValue, 'body.blog .blog-banner, body.single .blog-banner' );
						
		});

	});



	//blog archive background color
	wp.customize( 'blog-archive-banner-bg-color', function( control ) {

		control.bind( function( controlValue ) {

			$( 'body.archive .blog-banner' ).css( 'background-color', controlValue );
			$( 'body.search .blog-banner' ).css( 'background-color', controlValue );
			
		});

	});


	//blog archive overlay color
	wp.customize( 'blog-archive-banner-overlay-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( 'body.archive .blog-banner .color-overlay' ).css( 'background', controlValue );
			$( 'body.search .blog-banner .color-overlay' ).css( 'background', controlValue );	
						
		});

	});

	//blog archive banner padding color
	wp.customize( 'blog-archive-banner-padding', function( control ) {

		control.bind( function( controlValue ) {		
			
			var styleTag = setupStyleTag( 'blog-archive-banner-padding' );
	
			styleTag.innerHTML = buildPaddingCSS( controlValue, 'body.archive .blog-banner, body.search .blog-banner' );	
						
		});

	});

	//blog banner upper heading color
	wp.customize( 'blog-banner-upper-heading-color', function( control ) {

		control.bind( function( controlValue ) {

			$( '.blog-banner .blog-banner-content-wrap .blog-banner-content span' ).css( 'color', controlValue[ 'value' ] );
						
		});

	});

	wp.customize( 'blog-banner-upper-heading-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-banner-upper-heading-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.blog-banner .blog-banner-content-wrap .blog-banner-content span' );				
						
		});

	});

	//blog banner heading color
	wp.customize( 'blog-banner-heading-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.blog-banner .blog-banner-content-wrap .blog-banner-content .banner-desc' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-banner-heading-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-banner-heading-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.blog-banner .blog-banner-content-wrap .blog-banner-content .banner-desc' );
						
		});

	});

	//blog archive banner heading color
	wp.customize( 'blog-archive-banner-heading-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title' ).css( 'color', controlValue[ 'value' ] );				
			$( '.search .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title' ).css( 'color', controlValue[ 'value' ] );		
			$( '.search .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title span' ).css( 'color', controlValue[ 'value' ] );		
			$( '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title .vcard' ).css( 'color', controlValue[ 'value' ] );				
						
		});

	});

	wp.customize( 'blog-archive-banner-heading-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-archive-banner-heading-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title' );		
			
			/*$( '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title' ).css( 'color', controlValue[ 'value' ] );				
			$( '.search .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title' ).css( 'color', controlValue[ 'value' ] );		
			$( '.search .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title span' ).css( 'color', controlValue[ 'value' ] );		
			$( '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content h1.banner-title .vcard' ).css( 'color', controlValue[ 'value' ] );				*/
						
		});

	});


	//blog archive banner desc color
	wp.customize( 'blog-archive-banner-desc-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content .description' ).css( 'color', controlValue[ 'value' ] );			
													
		});

	});

	wp.customize( 'blog-archive-banner-desc-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-archive-banner-desc-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.archive .blog-banner .blog-banner-content-wrap .blog-banner-content .description' );				
																
		});

	});

	//blog post list title color
	wp.customize( 'blog-post-title-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.post-list .post .entry-header .entry-title a' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-post-title-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-post-title-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.post-list .post .entry-header .entry-title a' );				
						
		});

	});

	//blog post list meta color
	wp.customize( 'blog-post-meta-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.post-list .post .entry-header .entry-meta span.posted-on time, .post-list .post .entry-header .entry-meta .cat-links a' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-post-meta-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-post-meta-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.post-list .post .entry-header .entry-meta span.posted-on time, .post-list .post .entry-header .entry-meta .cat-links a' );					
						
		});

	});

	//blog post list content color
	wp.customize( 'blog-post-content-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.post-list .post .entry-content p' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-post-content-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-post-content-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.post-list .post .entry-content p' );				
						
		});

	});


	//blog post single banner upper heading color
	wp.customize( 'blog-post-banner-upper-heading-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( 'body.single .blog-banner .blog-banner-content-wrap .blog-banner-content span' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-post-banner-upper-heading-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-post-banner-upper-heading-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, 'body.single .blog-banner .blog-banner-content-wrap .blog-banner-content span' );
			
		});

	});

	//blog post single banner title color
	wp.customize( 'blog-post-banner-title-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( 'body.single .blog-banner .blog-banner-content-wrap .blog-banner-content .banner-desc' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-post-banner-title-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-post-banner-title-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, 'body.single .blog-banner .blog-banner-content-wrap .blog-banner-content .banner-desc' );			
					
		});

	});

	//blog archive background color
	wp.customize( 'blog-post-banner-bg-color', function( control ) {

		control.bind( function( controlValue ) {

			$( 'body.single .blog-banner' ).css( 'background-color', controlValue );			
			
		});

	});


	//blog archive overlay color
	wp.customize( 'blog-post-banner-bg-color-overlay', function( control ) {

		control.bind( function( controlValue ) {
			
			$( 'body.single .blog-banner .color-overlay' ).css( 'background', controlValue );		
						
		});

	});

	//blog archive banner padding color
	wp.customize( 'blog-post-banner-padding', function( control ) {

		control.bind( function( controlValue ) {		
			
			var styleTag = setupStyleTag( 'blog-post-banner-padding' );

			styleTag.innerHTML = buildPaddingCSS( controlValue, 'body.single .blog-banner' );				
						
		});

	});


	//blog post single title color
	wp.customize( 'blog-single-post-title-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.post-single .post .entry-header .entry-title' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-single-post-title-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-single-post-title-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.post-single .post .entry-header .entry-title' );	
			
		});

	});

	//blog post single meta color
	wp.customize( 'blog-single-post-meta-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.post-single .post .entry-header .entry-meta span.posted-on time, .post-single .post .entry-header .entry-meta .cat-links a' ).css( 'color', controlValue[ 'value' ]);
			
		});

	});

	wp.customize( 'blog-single-post-meta-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-single-post-meta-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.post-single .post .entry-header .entry-meta span.posted-on time, .post-single .post .entry-header .entry-meta .cat-links a' );		
						
		});

	});

	//blog post single content color
	wp.customize( 'blog-single-post-content-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.post-single .post .entry-content p' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'blog-single-post-content-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'blog-single-post-content-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.post-single .post .entry-content p' );		
			
		});

	});
	

	//Portfolio

	//portfolio archive banner background color
	wp.customize( 'portfolio-archive-banner-bg-color', function( control ) {

		control.bind( function( controlValue ) {

			$( '.portfolio-archive-banner' ).css( 'background-color', controlValue );
		});

	});

	//portfolio archive banner overlay color
	wp.customize( 'portfolio-archive-banner-overlay-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.portfolio-archive-banner .color-overlay' ).css( 'background', controlValue );
			
		});

	});

	//portfolio archive banner padding color
	wp.customize( 'portfolio-archive-banner-padding', function( control ) {

		control.bind( function( controlValue ) {
			
			var styleTag = setupStyleTag( 'portfolio-archive-banner-padding' );

			styleTag.innerHTML = buildPaddingCSS( controlValue, '.portfolio-archive-banner' );	
					
		});

	});

	//portfolio archive banner title color
	wp.customize( 'portfolio-banner-title-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.portfolio-archive-banner .portfolio-archive-banner-content h1' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-banner-title-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-banner-title-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.portfolio-archive-banner .portfolio-archive-banner-content h1' );	
			
		});

	});

	//portfolio archive banner desc color
	wp.customize( 'portfolio-banner-desc-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.portfolio-archive-banner .portfolio-archive-banner-content .description p' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-banner-desc-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-banner-desc-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.portfolio-archive-banner .portfolio-archive-banner-content .description p' );
			
		});

	});

	//portfolio single hero title color
	wp.customize( 'portfolio-hero-title-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.portfolio-hero-section-wrap .hero-image-content-wrap span' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-hero-title-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-hero-title-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.portfolio-hero-section-wrap .hero-image-content-wrap span' );	
			
		});

	});

	//portfolio single hero desc color
	wp.customize( 'portfolio-hero-desc-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.portfolio-hero-section-wrap .hero-image-content-wrap h1' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-hero-desc-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-hero-desc-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.portfolio-hero-section-wrap .hero-image-content-wrap h1' );	
			
		});

	});

	//portfolio single post title color
	wp.customize( 'portfolio-single-title-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.single-portfolio .portfolio .entry-header .entry-title' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-single-title-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-single-title-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.single-portfolio .portfolio .entry-header .entry-title' );	
			
		});

	});

	//portfolio single post subtitle color
	wp.customize( 'portfolio-single-subtitle-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.single-portfolio .portfolio .entry-header .description' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-single-subtitle-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-single-subtitle-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.single-portfolio .portfolio .entry-header .description' );	
			
		});

	});

	//portfolio single post desc color
	wp.customize( 'portfolio-single-desc-color', function( control ) {

		control.bind( function( controlValue ) {
			
			$( '.single-portfolio .portfolio .entry-meta .meta-desc p' ).css( 'color', controlValue[ 'value' ] );
			
		});

	});

	wp.customize( 'portfolio-single-desc-typo', function( control ) {

		control.bind( function( controlValue ) {

			var styleTag = setupStyleTag( 'portfolio-single-desc-typo' );	
			
			styleTag.innerHTML = buildTypographyCSS( controlValue, '.single-portfolio .portfolio .entry-meta .meta-desc p' );	
			
		});

	});



})(jQuery);
