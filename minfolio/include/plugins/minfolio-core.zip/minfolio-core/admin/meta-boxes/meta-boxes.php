<?php
/**
 * Registering meta boxes
 */
add_filter( 'rwmb_meta_boxes', 'minfolio_register_meta_boxes' );

/**
 * Register meta boxes 
 
 * @param array $meta_boxes List of meta boxes
 *
 * @return array
 */

if ( ! function_exists( 'minfolio_register_meta_boxes' ) ) {	

	function minfolio_register_meta_boxes( $meta_boxes ) {
	
		$prefix = MINFOLIO_META_PREFIX;

		require_once MINFOLIO_CORE_PATH . 'admin/meta-boxes/blog.php';
		require_once MINFOLIO_CORE_PATH . 'admin/meta-boxes/portfolio.php';
		require_once MINFOLIO_CORE_PATH . 'admin/meta-boxes/page.php';
		

		return $meta_boxes;
	}

}


if ( ! function_exists( 'minfolio_enqueue_metabox_custom_css' ) ) {	

	function minfolio_enqueue_metabox_custom_css() {
		wp_enqueue_style( 'minfolio-metabox-custom', MINFOLIO_CORE_URL . 'admin/assets/css/metabox-custom.min.css', array(), MINFOLIO_CORE_VERSION );
	}

}

add_action( 'rwmb_enqueue_scripts', 'minfolio_enqueue_metabox_custom_css' );
