<?php	
		// Portfolio Thumbnail Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_thumbnail_box',
			'title'			=> esc_html__( 'Portfolio Thumbnail', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,		
			'fields'		=> array(						
				array(
					'name'  => esc_html__( 'Thumbnail title', 'minfolio' ),
					'id'	=> "{$prefix}thumbnail_title",			
					'type'	=> 'text',
					'size'	=> '50'	
				),
				array(
					'name'	=> esc_html__( 'Thumbnail subtitle', 'minfolio' ),
					'id'	=> "{$prefix}thumbnail_sub_title",				
					'type'	=> 'text',
					'size'	=> '50'
				),
				array(
					'name'	=> esc_html__( 'Thumbnail type', 'minfolio' ),
					'id'	=> "{$prefix}thumbnail_type",
					'type'	=> 'select',
					'options'	=> array(
									'image' => esc_html__( 'Featured Image', 'minfolio' ),					
									//'video' => esc_html__( 'Featured Video', 'minfolio' ),													
								),
					'desc'	=> esc_html__( 'Select the thumbnail type you want to achieve.', 'minfolio' ),		
					'std'	=> 'image',
				),
				array(
					'name'	=> esc_html__( 'Video upload', 'minfolio' ),
					'id'	=> "{$prefix}thumbnail_video_upload",
					'type'	=> 'video',
					'max_file_uploads' => 1 ,
					'desc'	=> esc_html__( 'Video will only shown in portfolio carousel.', 'minfolio' ),		
					'hidden' => array( $prefix.'thumbnail_type', '!=', 'video' )
				),						
			)
		);	
		// End of Portfolio Thumbnail meta box
				
		// Portfolio Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_settings_box',
			'title'			=> esc_html__( 'Portfolio Settings', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,
			'fields'		=> array(			
				array(
					'name'	=> esc_html__( 'Project type', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_project_type",
					'type'	=> 'radio',
					'options'	=> array(
						'lightbox'	=> esc_html__( 'Lightbox Project', 'minfolio' ),					
						'page'		=> esc_html__( 'Page Project', 'minfolio' ),					
						'external'	=> esc_html__( 'External Project', 'minfolio' ),
					),
					'desc'	=> esc_html__( 'Select the project type you want to achieve.', 'minfolio' ),		
					'std'	=> 'lightbox',
				),
				array(
					'name'	=> esc_html__( 'Lightbox type', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_lightbox_type",
					'type'	=> 'select',
					'options'	=> array(					
						'image'		=> esc_html__( 'Single image', 'minfolio' ),
						'gallery'	=> esc_html__( 'Image gallery', 'minfolio' ),
						'video'		=> esc_html__( 'Video', 'minfolio' ),
						'audio'		=> esc_html__( 'Audio', 'minfolio' ),					
					),
					'attributes' => array(
										'style'  => 'width:332px',									
									),					    
					'std'			=> 'image',
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'lightbox' )
				),
				array(
					'name'  => esc_html__( 'Add image', 'minfolio' ),
					'id'    => "{$prefix}lightbox_image_url",
					'type'  => 'image_advanced',
					'max_file_uploads' => 1,				
					'hidden' => array( $prefix.'portfolio_lightbox_type', '!=', 'image' )
				),
				array(
					'name'  => esc_html__( 'Video URL', 'minfolio' ),
					'id'	=> "{$prefix}lightbox_video_url",
					'desc'	=> esc_html__( 'Enter your video url here', 'minfolio' ),
					'type'	=> 'text',	
					'size'	=> '50',				
					'hidden' => array( $prefix.'portfolio_lightbox_type', '!=', 'video' )
				),
				array(
					'name'	=> esc_html__( 'Audio URL', 'minfolio' ),
					'id'	=> "{$prefix}lightbox_audio_url",
					'desc'	=> esc_html__( 'Enter your audio url here.', 'minfolio' ),
					'type'	=> 'text',
					'size'	=> '50',
					'hidden' => array( $prefix.'portfolio_lightbox_type', '!=', 'audio' )
				),
				array(
					'name'	=> esc_html__( 'Add images', 'minfolio' ),
					'id'	=> "{$prefix}lightbox_gallery_images",
					'type'	=> 'image_advanced',
					'max_file_uploads' => 50,
					'hidden' => array( $prefix.'portfolio_lightbox_type', '!=', 'gallery' )
				),			
				/*array(
					'name'	=> esc_html__( 'Show Image Caption', 'minfolio' ),
					'id'	=> "{$prefix}lightbox_image_caption_src",
					'desc'	=> esc_html__( 'Select the image caption to be shown, image caption is taken from image meta details in media library.', 'minfolio' ),
					'type'	=> 'select',
					'std'	=> '',
					'options' => array(
										'' => esc_html__( 'None', 'minfolio' ),
										'title' => esc_html__( 'Title', 'minfolio' ),
										'caption' => esc_html__( 'Caption', 'minfolio' ),
										'alt' => esc_html__( 'Alt', 'minfolio' ),
										'description' => esc_html__( 'Description', 'minfolio' ),
									),
					'hidden' => array( $prefix.'portfolio_lightbox_type', 'not in', array( 'image', 'gallery' ) )
				),*/
				array(
					'name'	=> esc_html__( 'Show Image Caption', 'minfolio' ),
					'id'	=> "{$prefix}lightbox_image_show_caption",
					'desc'	=> esc_html__( 'Show image caption, image caption is taken from image meta details in media library.', 'minfolio' ),
					'type'  => 'switch',
					'style' => 'rounded',
					'on_label'  => 'Yes',
					'off_label' => 'No',
					'hidden' => array( $prefix.'portfolio_lightbox_type', 'not in', array( 'image', 'gallery' ) )
				),												
				array(
					'name'  => esc_html__( 'External URL', 'minfolio' ),
					'id'	=> "{$prefix}external_url",
					'desc'	=> esc_html__( 'Enter your external project url here', 'minfolio' ),
					'type'	=> 'text',	
					'size'	=> '80',
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'external' )
				),
				array(
					'name'  => esc_html__( 'Target', 'minfolio' ),
					'id'	=> "{$prefix}external_target",
					'desc'	=> esc_html__( 'Specify where to open the link.', 'minfolio' ),
					'type'	=> 'radio',
					'options'	=> array(					
						'_self'		=> esc_html__( 'Self', 'minfolio' ),
						'_blank'	=> esc_html__( 'Blank', 'minfolio' ),					
					),
					'std'			=> '_self',				
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'external' )
				),				
				array(
					'name'	=> esc_html__( 'Page layout', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_page_layout",
					'type'	=> 'radio',
					'options'	=> array(
						'boxed'	  => esc_html__( 'Boxed', 'minfolio' ),					
						'full-width' => esc_html__( 'Full width', 'minfolio' ),										
					),
					'desc'	=> esc_html__( 'Layout in portfolio page.', 'minfolio' ),				
					'std'	=> 'boxed',
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'page' )
				),			
				array(
					'name'	=> esc_html__( 'Details section placement', 'minfolio' ),
					'id'	=> "{$prefix}details_placement",
					'type'	=> 'select',
					'options'	=> array(						
						'details-bottom'	=> esc_html__( 'Details on bottom', 'minfolio' ),	
						'details-top'		=> esc_html__( 'Details on top', 'minfolio' ),											
						'details-right'		=> esc_html__( 'Details on right', 'minfolio' ),									
					),
					'attributes' => array(
										'style'  => 'width:332px',									
									),					
					'std'	=> 'details-bottom',
					'desc'	=> esc_html__( 'Placement of portfolio description and meta in portfolio page.', 'minfolio' ),		
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'page' )		
				),			
				array(
					'name'	=> esc_html__( 'Elements placement', 'minfolio' ),
					'id'	=> "{$prefix}page_builder_section_placement",
					'type'	=> 'select',
					'options'	=> array(
							'below-hero-section'	=> esc_html__( 'Below Hero section', 'minfolio' ),	
							'below-details-section'	=> esc_html__( 'Below details section', 'minfolio' ),
							'below-media-section'	=> esc_html__( 'Below media section', 'minfolio' ),								
					),
					'attributes' => array(
										'style'  => 'width:332px',									
									),					
					'std'	=> 'below-details-section',
					'desc'	=> esc_html__( 'Placement of page builder elements in portfolio page.', 'minfolio' ),		
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'page' )		
				),		
				array(
					'name'	=> esc_html__( 'Portfolio Home', 'minfolio' ),
					'id'	=> "{$prefix}page_portfolio_home_custom",
					'type'        => 'post',
					'post_type'   => 'page',
					'field_type'  => 'select_advanced',				
					'placeholder' => 'Inherit from Global',
					'query_args'  => array(
						'post_status'    => 'publish',
						'posts_per_page' => - 1,
					),
					'desc'	=> esc_html__( 'Specify the page you want to use as index for this portfolio.', 'minfolio' ),		
					'hidden' => array( $prefix.'portfolio_project_type', '!=', 'page' )
				),								
			)
		);	

		// End of Portfolio Meta Box

		// Portfolio Hero section Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_hero_section_box',
			'title'			=> esc_html__( 'Portfolio Hero Section', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,
			'hidden' => array( $prefix.'portfolio_project_type', '!=', 'page' ),			
			'fields'		=> array(
				array(
					'name'	=> esc_html__( 'Hero section', 'minfolio' ),
					'id'	=> "{$prefix}hero_section_switch",
					'type'	=> 'radio',
					'options' => array(					
										'0'	=> esc_html__( 'Disabled', 'minfolio' ),
										'1'	=> esc_html__( 'Enabled', 'minfolio' ),					
									),
					'desc'	=> esc_html__( 'Hero section in portfolio page.', 'minfolio' ),		
					'std'   => '0',					
				),						
				array(
					'name'	=> esc_html__( 'Hero section type', 'minfolio' ),
					'id'	=> "{$prefix}hero_section_type",
					'type'	=> 'select',
					'options'	=> array(					
						'image'		=> esc_html__( 'Single image', 'minfolio' ),
						'slider'	=> esc_html__( 'Single Image slider', 'minfolio' ),
						//'multi-slider'	=> esc_html__( 'Multiple Image slider', 'minfolio' ),
						'gallery'	 => esc_html__( 'Gallery', 'minfolio' ),		
						'lightbox-gallery'	=> esc_html__( 'Lightbox Gallery', 'minfolio' ),	
						'image-comparison' => esc_html__( 'Before After Image Comparison', 'minfolio' ),								
						'custom' => esc_html__( 'Custom From Page Builder', 'minfolio' ),								
						//'rev-slider' => esc_html__( 'Slider Revolution', 'minfolio' ),						
					),
					'attributes' => array(
										'style'  => 'width:332px',									
									),						
					'std'			=> 'image',	
					'hidden'		=> array( $prefix.'hero_section_switch', '!=', '1' ),			
				),
				array(
					'name'	=> esc_html__( 'Hero section height', 'minfolio' ),
					'id'	=> "{$prefix}hero_section_height",
					'type'	=> 'radio',
					'options'	=> array(					
						'full-height' => esc_html__( 'Full height', 'minfolio' ),
						'custom'	  => esc_html__( 'Custom height', 'minfolio' ),				
					),
					'std'	=> 'full-height',			
					'hidden' => array( $prefix.'hero_section_type', 'in', array( 'multi-slider', 'gallery', 'lightbox-gallery', 'image-comparison', 'custom'  ) )		
				),
				array(
					'name'  => esc_html__( 'Custom height', 'minfolio' ),
					'id'	=> "{$prefix}hero_custom_height",				
					'type'	=> 'text',	
					'std'	=> '600px',	
					'size'	=> '50',		
					'desc'	=> 'example: 500px',	
					'hidden' => array( $prefix.'hero_section_height', '!=', 'custom' )
				),							
				array(
					'name'  => esc_html__( 'Add image', 'minfolio' ),
					'id'    => "{$prefix}hero_image_url",
					'type'  => 'image_advanced',
					'max_file_uploads' => 1,
					'hidden' => array( $prefix.'hero_section_type', '!=', 'image' )
				),	
				array(
					'name'  => esc_html__( 'Overlay Color', 'minfolio' ),
					'id'    => "{$prefix}hero_image_overlay_color",
					'type'  => 'color',	
					'alpha_channel'  => true,	
					'hidden' => array( $prefix.'hero_section_type', '!=', 'image' )					
				),	
				array(
					'name'  => esc_html__( 'Title', 'minfolio' ),
					'id'	=> "{$prefix}hero_image_title",					
					'type'	=> 'text',	
					'size'	=> '50',							
					'hidden' => array( $prefix.'hero_section_type', '!=', 'image' )
				),	
				array(
					'name'  => esc_html__( 'Description', 'minfolio' ),
					'id'	=> "{$prefix}hero_image_desc",					
					'type'	=> 'textarea',			
					'size'	=> '50',		
					'hidden' => array( $prefix.'hero_section_type', '!=', 'image' )
				),					
				array(
					'name'  => esc_html__( 'Add image', 'minfolio' ),
					'id'    => "{$prefix}hero_image_comparison",
					'type'  => 'image_advanced',
					'max_file_uploads' => 2,
					'hidden' => array( $prefix.'hero_section_type', '!=', 'image-comparison' )
				),
				array(														
					'id'	=> "{$prefix}hero_responsive_height_label",			
					'type' => 'custom_html',															
					'std' => '<div class="rwmb-label">
								<label for="minfolio_responsive_height">Responsive Slider Height</label>					
							  </div>',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),	
				array(
					'name'  => esc_html__( 'Desktop', 'minfolio' ),
					'id'	=> "{$prefix}hero_slider_desktop_height",			
					'type'	=> 'text',					
					'std' => '450px',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),							
				array(
					'name'  => esc_html__( 'Tablet', 'minfolio' ),
					'id'	=> "{$prefix}hero_slider_tablet_height",			
					'type'	=> 'text',					
					'std' => '350px',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),			
				array(
					'name'  => esc_html__( 'Mobile', 'minfolio' ),
					'id'	=> "{$prefix}hero_slider_mobile_height",			
					'type'	=> 'text',					
					'std' => '250px',
					'columns' => 3,		
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),																
				array(
					'name'	=> esc_html__( 'Add images', 'minfolio' ),
					'id'	=> "{$prefix}hero_slider_images",
					'type'	=> 'image_advanced',
					'max_file_uploads' => 50,
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'slider', 'multi-slider' ) )
				),		
				array(
					'name'	=> esc_html__( 'Slider per view', 'minfolio' ),
					'id'	=> "{$prefix}hero_slide_per_view",
					'type'	=> 'radio',
					'options'	=> array(														
									'2'		=> esc_html__( '2 Slide', 'minfolio' ),
									'3'		=> esc_html__( '3 Slide', 'minfolio' ),
									'4'		=> esc_html__( '4 Slide', 'minfolio' ),						
									'5'		=> esc_html__( '5 Slide', 'minfolio' ),						
									'6'		=> esc_html__( '6 Slide', 'minfolio' ),						
									'7'		=> esc_html__( '7 Slide', 'minfolio' ),						
									'8'		=> esc_html__( '8 Slide', 'minfolio' ),						
								),
					'std'		=> '2',																				
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),					
				array(														
					'id'	=> "{$prefix}hero_responsive_slide_label",			
					'type' => 'custom_html',															
					'std' => '<div class="rwmb-label">
								<label for="minfolio_responsive_slide">Responsive Slides</label>					
							  </div>',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),					
				array(
					'name'  => esc_html__( 'Tablet Slide', 'minfolio' ),
					'id'	=> "{$prefix}hero_tablet_slide",			
					'type'	=> 'select',
					'options'	=> array(													
									'2'		=> esc_html__( '2 Slide', 'minfolio' ),
									'3'		=> esc_html__( '3 Slide', 'minfolio' ),
									'4'		=> esc_html__( '4 Slide', 'minfolio' ),						
									'5'		=> esc_html__( '5 Slide', 'minfolio' ),						
									'6'		=> esc_html__( '6 Slide', 'minfolio' ),						
									'7'		=> esc_html__( '7 Slide', 'minfolio' ),						
									'8'		=> esc_html__( '8 Slide', 'minfolio' ),						
								),							
					'std' => '2',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),			
				array(
					'name'  => esc_html__( 'Mobile Slide', 'minfolio' ),
					'id'	=> "{$prefix}hero_mobile_slide",			
					'type'	=> 'select',
					'options'	=> array(										
									'1'		=> esc_html__( '1 Slide', 'minfolio' ),
									'2'		=> esc_html__( '2 Slide', 'minfolio' ),
									'3'		=> esc_html__( '3 Slide', 'minfolio' ),
									'4'		=> esc_html__( '4 Slide', 'minfolio' ),						
									'5'		=> esc_html__( '5 Slide', 'minfolio' ),						
									'6'		=> esc_html__( '6 Slide', 'minfolio' ),						
									'7'		=> esc_html__( '7 Slide', 'minfolio' ),						
									'8'		=> esc_html__( '8 Slide', 'minfolio' ),						
								),						
					'std' => '2',
					'columns' => 6,		
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),													
				array(
					'name'  => esc_html__( 'Space between', 'minfolio' ),
					'id'	=> "{$prefix}hero_slide_space",
					'desc'	=> esc_html__( 'Enter space between slide in (px).', 'minfolio' ),
					'type'	=> 'text',	
					'size'	=> '0',				
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),			
				array(
					'name'	=> esc_html__( 'Centered slides', 'minfolio' ),
					'id'	=> "{$prefix}hero_centered_slides",
					'desc'	=> esc_html__( 'If checked, then active slide will be centered, not always on the left side.', 'minfolio' ),		
					'type'	=> 'checkbox',					
					'std'   => '0',
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),											
				array(
					'name'	=> esc_html__( 'Loop', 'minfolio' ),
					'id'	=> "{$prefix}hero_loop",
					'desc'	=> esc_html__( 'Set to true to enable continuous loop mode.', 'minfolio' ),		
					'type'	=> 'checkbox',					
					'std'   => '0',
					'hidden' => array( $prefix.'hero_section_type', '!=', 'multi-slider' )
				),	
				array(
					'name'	=> esc_html__( 'Transition effect', 'minfolio' ),
					'id'	=> "{$prefix}hero_transition_effect",
					'desc'	=> esc_html__( 'Set transition effect for portfolio slide.', 'minfolio' ),		
					'type'	=> 'radio',
					'options'	=> array(					
									'slide'	=> esc_html__( 'Slide', 'minfolio' ),
									'fade'	=> esc_html__( 'Fade', 'minfolio' ),									
								),
					'std'	=> 'slide',																				
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'slider' ) )
				),			
				array(
					'name'	=> esc_html__( 'Show Navigation', 'minfolio' ),
					'id'	=> "{$prefix}hero_slider_navigation",
					'desc'	=> esc_html__( 'Choose to show slider navigation.', 'minfolio' ),		
					'type'	=> 'checkbox',					
					'std'   => '0',
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'slider', 'multi-slider' ) )
				),		
				array(
					'name'	=> esc_html__( 'Show Pagination', 'minfolio' ),
					'id'	=> "{$prefix}hero_slider_pagination",
					'desc'	=> esc_html__( 'Choose to show slider pagination.', 'minfolio' ),		
					'type'	=> 'checkbox',					
					'std'   => '1',
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'slider', 'multi-slider' ) )
				),		
				array(
					'name'  => esc_html__( 'Autoplay Delay', 'minfolio' ),
					'id'	=> "{$prefix}hero_autoplay_delay",
					'desc'	=> esc_html__( 'Specify slideshow speed (in milliseconds). Default is 3500.', 'minfolio' ),
					'type'	=> 'text',	
					'value'	=> '3500',				
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'slider', 'multi-slider' ) )
				),		
				array(
					'name'	=> esc_html__( 'Add images', 'minfolio' ),
					'id'	=> "{$prefix}hero_gallery_images",
					'type'	=> 'image_advanced',
					'max_file_uploads' => 50,
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'gallery', 'lightbox-gallery' ) )
				),
				array(
					'name'	=> esc_html__( 'Media layout', 'minfolio' ),
					'id'	=> "{$prefix}hero_media_layout",
					'type'	=> 'radio',
					'options'	=> array(					
									'grid'		=> esc_html__( 'Grid', 'minfolio' ),
									'mosaic'	=> esc_html__( 'Mosaic', 'minfolio' ),																
								),
					'std'	 => 'grid',		
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'gallery', 'lightbox-gallery' ) )
				),	
				array(
					'name'	=> esc_html__( 'Image gallery columns', 'minfolio' ),
					'id'	=> "{$prefix}hero_image_gallery_cols",
					'type'	=> 'radio',
					'options'	=> array(					
									'2'		=> esc_html__( '2 cols', 'minfolio' ),
									'3'		=> esc_html__( '3 cols', 'minfolio' ),
									'4'		=> esc_html__( '4 cols', 'minfolio' ),						
									'5'		=> esc_html__( '5 cols', 'minfolio' ),						
									'6'		=> esc_html__( '6 cols', 'minfolio' ),						
									'7'		=> esc_html__( '7 cols', 'minfolio' ),						
									'8'		=> esc_html__( '8 cols', 'minfolio' ),						
								),
					'std'		=> '3',																				
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'gallery', 'lightbox-gallery' ) )
				),				
				array(														
					'id'	=> "{$prefix}hero_gap_label",			
					'type' => 'custom_html',															
					'std' => '<div class="rwmb-label">
								<label for="clbr_meta_gap">Gap between columns</label>					
							  </div>',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'gallery', 'lightbox-gallery' ) )
				),					
				array(
					'name'  => esc_html__( 'Horizontal (px)', 'minfolio' ),
					'id'	=> "{$prefix}hero_gap_horizontal",			
					'type'	=> 'text',
					'size'	=> '15',
					'std' => '30',		
					'columns' => 3,	
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'gallery', 'lightbox-gallery' ) )
				),			
				array(
					'name'  => esc_html__( 'Vertical (px)', 'minfolio' ),
					'id'	=> "{$prefix}hero_gap_vertical",			
					'type'	=> 'text',
					'size'	=> '15',
					'std' => '30',
					'columns' => 6,		
					'hidden' => array( $prefix.'hero_section_type', 'not in', array( 'gallery', 'lightbox-gallery' ) )		
				),										
				array(
					'name'  => esc_html__( 'Video URL', 'minfolio' ),
					'id'	=> "{$prefix}hero_video_url",
					'desc'	=> esc_html__( 'Enter your youtube video url here', 'minfolio' ),
					'type'	=> 'text',	
					'size'	=> '50',				
					'hidden' => array( $prefix.'hero_section_type', '!=', 'video' )
				),
				array(
					'name'	=> esc_html__( 'Slider Revolution', 'minfolio' ),
					'id'	=> "{$prefix}hero_rev_slider",
					'type'	=> 'select',
					'options'	=> minfolio_get_revslider_list(),
					'desc' => esc_html__( 'Select slider revolution for hero section.', 'minfolio' ),
					'hidden' => array( $prefix.'hero_section_type', '!=', 'rev-slider' )	
				),				
			)	
		);	
		// End of Portfolio Hero section meta box
			
	 			
		// Portfolio Details Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_details_box',
			'title'			=> esc_html__( 'Portfolio Details', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,
			'hidden'		=> array( $prefix.'portfolio_project_type', '!=', 'page' ),
			'fields'		=> array(						
				array(
					'name'  => esc_html__( 'Title', 'minfolio' ),
					'id'	=> "{$prefix}title",			
					'type'	=> 'text',
					'size'	=> '50'	
				),
				array(
					'name'	=> esc_html__( 'Subtitle', 'minfolio' ),
					'id'	=> "{$prefix}sub_title",				
					'type'	=> 'text',
					'size'	=> '50'
				),	
				array(
					'name'	=> esc_html__( 'Description', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_desc",				
					'type'	=> 'wysiwyg',
					'std'	=> 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages.',	
					'options' => array( 'textarea_rows' => 15, )		
				),
				array(
					'name'	=> esc_html__( 'Sticky Details', 'minfolio' ),
					'id'	=> "{$prefix}sticky_details",
					'desc'	=> esc_html__( 'Choose to stick the portfolio details and meta on scroll.', 'minfolio' ),		
					'type'	=> 'checkbox',					
					'std'   => '1',
					'hidden' => array( $prefix.'details_placement', '!=', 'details-right' )
				),	
				
			)
		);	
		// End of Portfolio Title meta box
				
					
		// Portfolio Media Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_multiple_media_box',
			'title'			=> esc_html__( 'Portfolio Medias', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,
			'hidden'		=> array( $prefix.'portfolio_project_type', '!=', 'page' ),
			'fields'		=> array(	

									array(
										'name'	=> esc_html__( 'Media section', 'minfolio' ),
										'id'	=> "{$prefix}media_section_switch",
										'type'	=> 'radio',
										'options' => array(					
															'0'	=> esc_html__( 'Disabled', 'minfolio' ),
															'1'	=> esc_html__( 'Enabled', 'minfolio' ),					
														),
										'desc'	=> esc_html__( 'Media section in portfolio page.', 'minfolio' ),		
										'std'   => '1',					
									),				
									array(
										'name'  => esc_html__( 'Space between media', 'minfolio' ),
										'id'	=> "{$prefix}multi_media_space_between",
										'desc'	=> esc_html__( 'Enter space between the selected media in (px)', 'minfolio' ),
										'type'	=> 'text',	
										'value' => '50',
										'hidden' => array( $prefix.'media_section_switch', '!=', '1' ),				
									),
									array(
										'id'    => "{$prefix}portfolio_multiple_media_groupbox",
										'type'  => 'group',								
										'clone' => true,				
										'sort_clone' => true,			
										'add_button' => 'Add more media',	
										'hidden' => array( $prefix.'media_section_switch', '!=', '1' ),		
										'fields'	 => array(
															array(
																'name'	=> esc_html__( 'Media', 'minfolio' ),
																'id'	=> "{$prefix}multi_media_display",
																'type'	=> 'select',
																'options'	=> array(					
																	'stack'		=> esc_html__( 'Fullwidth stack images', 'minfolio' ),
																	'video'		=> esc_html__( 'Video', 'minfolio' ),
																	'slider'	=> esc_html__( 'Image slider', 'minfolio' ),
																	'gallery'	=> esc_html__( 'Image gallery', 'minfolio' ),
																	'lightbox-gallery' => esc_html__( 'Image gallery (With Lightbox)', 'minfolio' ),								
																	'image-comparison' => esc_html__( 'Before After Image Comparison', 'minfolio' ),								
																),
																'attributes' => array(
																					'style'  => 'width:332px',									
																				),								
																'std'			=> 'stack',				
															),
															array(
																'name'	=> esc_html__( 'Media layout', 'minfolio' ),
																'id'	=> "{$prefix}media_layout",
																'type'	=> 'radio',
																'options'	=> array(					
																	'grid'		=> esc_html__( 'Grid', 'minfolio' ),
																	'mosaic'	=> esc_html__( 'Mosaic', 'minfolio' ),																
																),
																'std'	 => 'grid',		
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'gallery', 'lightbox-gallery' ) )
															),
															array(
																'name'	=> esc_html__( 'Image gallery columns', 'minfolio' ),
																'id'	=> "{$prefix}image_gallery_cols",
																'type'	=> 'radio',
																'options'	=> array(					
																					'2'		=> esc_html__( '2 cols', 'minfolio' ),
																					'3'		=> esc_html__( '3 cols', 'minfolio' ),
																					'4'		=> esc_html__( '4 cols', 'minfolio' ),						
																					'5'		=> esc_html__( '5 cols', 'minfolio' ),						
																					'6'		=> esc_html__( '6 cols', 'minfolio' ),						
																					'7'		=> esc_html__( '7 cols', 'minfolio' ),						
																					'8'		=> esc_html__( '8 cols', 'minfolio' ),								
																				),
																'std'		=> '3',																				
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'gallery', 'lightbox-gallery' ) )
															),																		
															array(														
																'id'	=> "{$prefix}gap_label",			
																'type' => 'custom_html',															
																'std' => '<div class="rwmb-label">
																			<label for="clbr_meta_gap">Gap between columns</label>					
																		  </div>',		
																'columns' => 3,	
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'gallery', 'lightbox-gallery', 'stack' ) )
															),					
															array(
																'name'  => esc_html__( 'Horizontal (px)', 'minfolio' ),
																'id'	=> "{$prefix}gap_horizontal",			
																'type'	=> 'text',
																'size'	=> '15',
																'std' => '30',		
																'columns' => 3,	
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'gallery', 'lightbox-gallery', 'stack' ) )
															),			
															array(
																'name'  => esc_html__( 'Vertical (px)', 'minfolio' ),
																'id'	=> "{$prefix}gap_vertical",			
																'type'	=> 'text',
																'size'	=> '15',
																'std' => '30',
																'columns' => 6,		
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'gallery', 'lightbox-gallery', 'stack' ) )		
															),		
															array(
																'name'	=> esc_html__( 'Video Source', 'minfolio' ),
																'id'	=> "{$prefix}multi_media_video_source",
																'type'	=> 'select',										
																'options' => array(									
																				'video-url' => esc_html__( 'Video URL', 'minfolio' ),					
																				'video-upload'	=> esc_html__( 'Upload Video', 'minfolio' ),									
																			),
																'std' => 'video-url',
																'desc'	=> esc_html__( 'Select the source for video.', 'minfolio' ),						
																'hidden' => array( $prefix.'multi_media_display', '!=', 'video' )
															),								
															array(
																'name'  => esc_html__( 'Video Url', 'minfolio' ),
																'id'	=> "{$prefix}page_video_url",
																//'desc'	=> esc_html__( 'Enter your video url here', 'minfolio' ),
																'type'	=> 'textarea',	
																'size'	=> '50',
																'clone'	=> true,
																'add_button' => 'Add more video',				
																'max_clone' => 5,			   
																'hidden' => array( $prefix.'multi_media_video_source', '!=', 'video-url' )
															),		
															array(
																'name'	=> esc_html__( 'Videos upload', 'minfolio' ),
																'id'	=> "{$prefix}multi_media_video_upload",
																'type'	=> 'video',
																'max_file_uploads' => 10 ,
																'hidden' => array( $prefix.'multi_media_video_source', '!=', 'video-upload' )
															),						
															array(
																'name'	=> esc_html__( 'Images upload', 'minfolio' ),
																'id'	=> "{$prefix}media_images",
																'type'	=> 'image_advanced',
																'max_file_uploads' => 50 ,
																'hidden' => array( $prefix.'multi_media_display', '=', 'video' )
															),		
															array(
																'name'	=> esc_html__( 'Show Navigation', 'minfolio' ),
																'id'	=> "{$prefix}multi_media_slider_navigation",
																'desc'	=> esc_html__( 'Choose to show slider navigation.', 'minfolio' ),		
																'type'	=> 'checkbox',					
																'std'   => '0',
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'slider' ) )
															),		
															array(
																'name'	=> esc_html__( 'Show Pagination', 'minfolio' ),
																'id'	=> "{$prefix}multi_media_slider_pagination",
																'desc'	=> esc_html__( 'Choose to show slider pagination.', 'minfolio' ),		
																'type'	=> 'checkbox',					
																'std'   => '1',
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'slider' ) )
															),																
															array(
																'name'	=> esc_html__( 'Show Image Caption', 'minfolio' ),
																'id'	=> "{$prefix}multi_media_image_show_caption",
																'desc'	=> esc_html__( 'Show image caption, image caption is taken from image meta details in media library.', 'minfolio' ),
																'type'  => 'switch',
																'style' => 'rounded',
																'on_label'  => 'Yes',
																'off_label' => 'No',
																'hidden' => array( $prefix.'multi_media_display', 'not in', array( 'stack', 'gallery', 'lightbox-gallery', 'video' ) )
															),																										
														),
										),			
							)						
		);
															
						
		// Portfolio Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_meta_box',
			'title'			=> esc_html__( 'Portfolio Metas', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,
			'hidden'		=> array( $prefix.'portfolio_project_type', '!=', 'page' ),
			'fields'		=> array(				
				array(
					'name'	=> esc_html__( 'Meta section', 'minfolio' ),
					'id'	=> "{$prefix}meta_details_reqd",
					'type'	=> 'radio',
					'options'	=> array(					
									'1'	=> esc_html__( 'Enabled', 'minfolio' ),			
									'0'	=> esc_html__( 'Disabled', 'minfolio' ),												
								),
					'std'   => '1'		
				),			
				array(			
					'id'	=> "{$prefix}divider_4",				
					'type'	=> 'divider',
					'hidden' => array( $prefix.'meta_details_reqd', '!=', '1' ),		
				),			
				array(
					'id'    => "{$prefix}portfolio_groupbox",
					'type'  => 'group',			
					'clone' => true,
					'hidden' => array( $prefix.'meta_details_reqd', '!=', '1' ),
					'sort_clone' => false,
					'add_button' => 'Add more meta field',				
					'fields'	 => array(
									array(
										'id'	=> "{$prefix}new_title",
										'name'  => esc_html__( 'Title', 'minfolio' ),
										'desc'  => esc_html__( 'Enter the title. For example, client, year, etc.', 'minfolio' ),
										'type'  => 'text',
										'std'   => ""								
										),
									array(
										'id'    => "{$prefix}new_value",
										'name'  => esc_html__( 'Value', 'minfolio' ),
										'desc'  => esc_html__( 'Enter the value. For example, client-name, 2016, etc. HTML a and br tag can also be used here.', 'minfolio' ),
										'type'  => 'textarea',
										'rows'	=> 5,	
										'std'   => "",									
										),
									),
				),	
				array(
					'name'	=> esc_html__( 'Show Categories', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_meta_show_categories",
					'type'	=> 'checkbox',				
					'desc'  => esc_html__( 'check to show portfolio item categories.', 'minfolio' ),
					'hidden' => array( 'meta_details_reqd', '!=', '1' ),
				),										
				array(
					'name'	=> esc_html__( 'Show Tags', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_meta_show_tags",
					'type'	=> 'checkbox',				
					'desc'  => esc_html__( 'check to show portfolio item tags.', 'minfolio' ),
					'hidden' => array( 'meta_details_reqd', '!=', '1' ),
				),				
				array(			
					'id'	=> "{$prefix}divider_8",				
					'type'	=> 'divider',			
					'hidden' => array( 'meta_details_reqd', '!=', '1' ),
				),							
				array(
					'name'	=> esc_html__( 'Button section', 'minfolio' ),
					'id'	=> "{$prefix}button_section_switch",
					'type'	=> 'radio',
					'options'	=> array(					
									'1'	=> esc_html__( 'Enabled', 'minfolio' ),			
									'0'	=> esc_html__( 'Disabled', 'minfolio' ),												
								),				
					'std'   => '0',
					'hidden' => array( $prefix.'meta_details_reqd', '!=', '1' ),
				),						
				array(			
					'id'	=> "{$prefix}divider_8",				
					'type'	=> 'divider',			
					'hidden' => array( $prefix.'button_section_switch', '!=', '1' ),
				),			
				array(
					'name'  => esc_html__( 'Text', 'minfolio' ),
					'id'	=> "{$prefix}button_text",
					'desc'  => esc_html__( 'Example: LAUNCH', 'minfolio' ),
					'hidden' => array( $prefix.'button_section_switch', '!=', '1' ),
					'type'  => 'text',
					'size'	=> '50'
				),
				array(
					'name'	=> esc_html__( 'Style', 'minfolio' ),
					'id'	=> "{$prefix}button_style",
					'type'	=> 'radio',
					'std'   => 'outlined',
					'options'	=> array(					
						'outlined'	=> esc_html__( 'Outlined', 'minfolio' ),					
						'solid'	    => esc_html__( 'Solid', 'minfolio' ),						
					),									
					'hidden' => array( $prefix.'button_section_switch', '!=', '1' ),
				),										
				array(
					'name'  => esc_html__( 'URL', 'minfolio' ),
					'id'	=> "{$prefix}button_url",				
					'desc'  => esc_html__( 'Example: http://www.google.com', 'minfolio' ),
					'hidden' => array( $prefix.'button_section_switch', '!=', '1' ),
					'type'  => 'text',
					'size'	=> '50'
				),		
				array(
					'name'	=> esc_html__( 'Target', 'minfolio' ),
					'id'	=> "{$prefix}button_target",
					'type'	=> 'radio',
					'options'	=> array(					
						'_self'		=> esc_html__( 'Same page', 'minfolio' ),
						'_blank'	=> esc_html__( 'New page', 'minfolio' ),					
					),				
					'std'   => '_blank',		
					'hidden' => array( $prefix.'button_section_switch', '!=', '1' ),
				),				


			)
		);						
		
			// Portfolio Related Works Meta Box
		$meta_boxes[] = array(
			'id'			=> 'related_portfolio_box',
			'title'			=> esc_html__( 'Related Portfolio', 'minfolio' ),
			'post_types'	=> array( 'portfolio' ),
			'context'		=> 'normal',
			'priority'		=> 'high',
			'autosave'		=> true,		
			'hidden' 		=> array( $prefix.'portfolio_project_type', '!=', 'page' ),				
			'fields'		=> array(		
					array(
						'name'	=> esc_html__( 'Related portfolio', 'minfolio' ),
						'id'	=> "{$prefix}page_related_portfolio_section",
						'type'	=> 'radio',
						'options'	=> array(					
											'0'	=> esc_html__( 'Disabled', 'minfolio' ),
											'1'	=> esc_html__( 'Enabled', 'minfolio' ),					
										),
						'std'	=> '1',
						'desc'	=> esc_html__( 'Show Related Portfolio section for current portfolio.', 'minfolio' ),		
						'hidden' => array( $prefix.'portfolio_project_type', '!=', 'page' ),			
					),											
					array(
						'name'  => esc_html__( 'Related Portfolio Title', 'minfolio' ),
						'id'	=> "{$prefix}related_portfolio_title",			
						'type'	=> 'text',
						'desc'	=> 'Enter a title for related portfolio.',
						'size'	=> '50',
						'hidden' => array( $prefix.'page_related_portfolio_section', '!=', '1' ),							
					),							
					array(			
						'id'	=> "{$prefix}divider_8",				
						'type'	=> 'divider',
						'hidden' => array( $prefix.'page_related_portfolio_section', '!=', '1' ),									
					),
					array(				
						'name'  => esc_html__( 'Layout', 'minfolio' ),
						'id'	=> "{$prefix}related_portfolio_layout",
						'type'	=> 'select',
						'options'	=> array(
											'grid'	 => esc_html__( 'Grid', 'minfolio' ),					
											'slider' => esc_html__( 'Slider', 'minfolio' ),					
										),
						'desc'  => esc_html__( 'Select related portfolio layout.', 'minfolio' ),
						'std'	=> 'grid',
						'hidden' => array( $prefix.'page_related_portfolio_section', '!=', '1' ),							
					),
					array(			
						'id'	=> "{$prefix}divider_9",				
						'type'	=> 'divider',
						'hidden' => array( $prefix.'page_related_portfolio_section', '!=', '1' ),									
					),			
					array(
						'name'	=> esc_html__( 'Grid columns', 'minfolio' ),
						'id'	=> "{$prefix}related_portfolio_grid_cols",
						'type'	=> 'radio',
						'options' => array(														
										'3'		=> esc_html__( '3 cols', 'minfolio' ),
										'4'		=> esc_html__( '4 cols', 'minfolio' ),						
										'5'		=> esc_html__( '5 cols', 'minfolio' ),						
										'6'		=> esc_html__( '6 cols', 'minfolio' ),						
									),
						'std'		=> '3',																				
						'hidden' => array( $prefix.'related_portfolio_layout', '!=', 'grid' )
					),		
					array(			
						'id'	=> "{$prefix}divider_10",				
						'type'	=> 'divider',
						'hidden' => array( $prefix.'related_portfolio_layout', '!=', 'grid' )
					),			
					array(
						'name'  => esc_html__( 'Filter By', 'minfolio' ),
						'id'	=> "{$prefix}related_portfolio_filter",			
						'type'	=> 'select',
						'desc'	=> 'Choose the filter by for related portfolio.',
						'options'	=> array(
											"category"	=> esc_html__( "Category", "minfolio" ),
											"portfolio"	=> esc_html__( "Portfolio", "minfolio" ),													
										),
						'std'	=> 'inherit',
						'hidden' => array( $prefix.'page_related_portfolio_section', '!=', '1' ),								
					),
					array(			
						'id'	=> "{$prefix}divider_11",				
						'type'	=> 'divider',		
						'hidden' => array( $prefix.'related_portfolio_filter', '!=', 'category' )	
					),			
					array(
						'name'  => 'Filter By Category',
						'id'	=> "{$prefix}related_portfolio_filterby_category",			
						'type'  => 'taxonomy_advanced',				
						'taxonomy' => 'portfolio_category',
						'field_type' => 'checkbox_list',
						'hidden' => array( $prefix.'related_portfolio_filter', '!=', 'category' ),		
					),	
					array(			
						'id'	=> "{$prefix}divider_12",				
						'type'	=> 'divider',		
						'hidden' => array( $prefix.'related_portfolio_filter', '!=', 'portfolio' ),		
					),			
					array(
						'name'  => 'Filter By Portfolio',
						'id'	=> "{$prefix}related_portfolio_filterby_portfolio",		
						'type'  => 'post',					
						'post_type' => 'portfolio',					
						'field_type'  => 'checkbox_list',
						'inline' => true,		
						'multiple' => true,		
						'query_args'  => array(
							'post_status'    => 'publish',
							'posts_per_page' => - 1,
						),
						'hidden' => array( $prefix.'related_portfolio_filter', '!=', 'portfolio' ),				
					),			
								
				)
		);	
		// End of Portfolio Title meta box


		// Portfolio Terms Category Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_terms_category_box',			
			'title'         => '',
			'taxonomies'	=> 'portfolio_category',			
			'fields'		=> array(
				array(
					'name'  => esc_html__( 'Banner', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_category_banner",			
					'type'	=> 'select',
					'desc'	=> 'Choose the banner from theme options or custom.',
					'options'	=> array(
										"inherit"	=> esc_html__( "Inherit", "minfolio" ),
										"custom"	=> esc_html__( "Custom", "minfolio" ),													
									),
					'std'	=> 'inherit',												
				),
				array(
					'name'  => esc_html__( 'Upload image', 'minfolio' ),
					'id'    => "{$prefix}portfolio_category_image",
					'type'  => 'image_advanced',	
					'max_file_uploads' => 1,	
					'hidden' => array( $prefix.'portfolio_category_banner', '!=', 'custom' ),						
				),	
				array(
					'name'  => esc_html__( 'Overlay Color', 'minfolio' ),
					'id'    => "{$prefix}portfolio_category_overlay_color",
					'type'  => 'color',	
					'alpha_channel'  => true,	
					'hidden' => array( $prefix.'portfolio_category_banner', '!=', 'custom' ),														
				),			
				array(
					'name'  => esc_html__( 'Background Color', 'minfolio' ),
					'id'    => "{$prefix}portfolio_category_bg_color",
					'type'  => 'color',	
					'hidden' => array( $prefix.'portfolio_category_banner', '!=', 'custom' ),														
				),						
			)
		);	
		// End of Portfolio Terms Category Meta Box

		// Portfolio Terms Tag Meta Box
		$meta_boxes[] = array(
			'id'			=> 'portfolio_terms_tag_box',			
			'title'         => '',
			'taxonomies'	=> 'portfolio_tag',			
			'fields'		=> array(
				array(
					'name'  => esc_html__( 'Banner', 'minfolio' ),
					'id'	=> "{$prefix}portfolio_tag_banner",			
					'type'	=> 'select',
					'desc'	=> 'Choose the banner from theme options or custom.',
					'options'	=> array(
										"inherit"	=> esc_html__( "Inherit", "minfolio" ),
										"custom"	=> esc_html__( "Custom", "minfolio" ),													
									),
					'std'	=> 'inherit',																		
				),
				array(
					'name'  => esc_html__( 'Upload image', 'minfolio' ),
					'id'    => "{$prefix}portfolio_tag_image",
					'type'  => 'image_advanced',	
					'max_file_uploads' => 1,		
					'hidden' => array( $prefix.'portfolio_tag_banner', '!=', 'custom' ),							
				),
				array(
					'name'  => esc_html__( 'Overlay Color', 'minfolio' ),
					'id'    => "{$prefix}portfolio_tag_overlay_color",
					'type'  => 'color',	
					'alpha_channel'  => true,	
					'hidden' => array( $prefix.'portfolio_tag_banner', '!=', 'custom' ),														
				),				
				array(
					'name'  => esc_html__( 'Background Color', 'minfolio' ),
					'id'    => "{$prefix}portfolio_tag_bg_color",
					'type'  => 'color',			
					'hidden' => array( $prefix.'portfolio_tag_banner', '!=', 'custom' ),								
				),						
			)
		);	
		// End of Portfolio Terms Tag Meta Box