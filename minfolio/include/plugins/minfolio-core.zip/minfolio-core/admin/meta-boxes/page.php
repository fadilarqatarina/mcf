<?php

	// Page Meta Box
	$meta_boxes[] = array(
		'id'			=> 'page_meta_box',
		'title'			=> esc_html__( 'Page Settings', 'minfolio' ),
		'post_types'	=> array( 'page', 'post', 'portfolio' ),		
		'tabs' => array(				
				'menu' => array(
					'label' => esc_html__( 'Menu', 'minfolio' ),
					'icon' => 'dashicons-menu',
				),	
				'footer' => array(
					'label' => esc_html__( 'Footer', 'minfolio' ),
					'icon' => 'dashicons-align-center',
				),			
		),
		'tab_style' => 'left',
		'fields'		=> array(	
								
			/* Menu Tab */			
			array(				
				'id'	=> "{$prefix}page_menu_override_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_page_menu_override_label">'.esc_html__( 'Menu', 'minfolio' ).'</label>					
						  </div>',		
				'columns' => 3,					
				'tab' => 'menu'		
			),					
			array(				
				'id'	=> "{$prefix}page_menu_override",
				'type'	=> 'select',
				'options'	=> array(
					'inherit'	=> esc_html__( 'Inherit', 'minfolio' ),					
					'custom'	=> esc_html__( 'Custom', 'minfolio' ),					
				),
				'desc'  => esc_html__( 'Override the menu', 'minfolio' ),
				'std'	=> 'inherit',	
				'columns' => 9,		
				'tab' => 'menu'
			),
			array(
				'type' => 'divider',
				'tab' => 'menu',
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
			),		
			array(				
				'id'	=> "{$prefix}page_menu_type_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_page_menu_type_label">'.esc_html__( 'Menu type', 'minfolio' ).'</label>					
						  </div>',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 3,					
				'tab' => 'menu'		
			),	
			array(				
				'id'	=> "{$prefix}page_menu_type",
				'type'	=> 'radio',
				'options'	=> array(					
								''	=> esc_html__( 'Standard', 'minfolio' ),
								'centered-menu'	=> esc_html__( 'Centered menu', 'minfolio' ),
							),
				'std'		=> '',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 9,
				'tab' => 'menu'
			),
			array(
				'type' => 'divider',
				'tab' => 'menu',
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
			),				
			array(				
				'id'	=> "{$prefix}page_menu_layout_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_page_menu_layout_label">'.esc_html__( 'Menu layout', 'minfolio' ).'</label>					
						  </div>',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 3,					
				'tab' => 'menu'		
			),						
			array(
				'id'	=> "{$prefix}page_menu_layout",
				'type'	=> 'radio',
				'options'	=> array(					
								'boxed'	=> esc_html__( 'Boxed layout', 'minfolio' ),
								'full-width' => esc_html__( 'Fullwidth layout', 'minfolio' ),			
							),
				'std'		=> 'boxed',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 9,		
				'tab' => 'menu'		
			),		
			array(
				'type' => 'divider',
				'tab' => 'menu',
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
			),						
			array(				
				'id'	=> "{$prefix}page_menu_display_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_page_menu_display_label">'.esc_html__( 'Menu display', 'minfolio' ).'</label>					
						  </div>',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 3,					
				'tab' => 'menu'		
			),						
			array(
				'id'	=> "{$prefix}page_menu_display",
				'type'	=> 'radio',
				'options'	=> array(					
								'solid'	=> esc_html__( 'Solid', 'minfolio' ),
								'transparent' => esc_html__( 'Transparent', 'minfolio' ),			
							),
				'std'		=> 'solid',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 9,		
				'tab' => 'menu'		
			),
			array(
				'type' => 'divider',
				'tab' => 'menu',
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
			),									
			array(				
				'id'	=> "{$prefix}page_menu_sticky_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_page_menu_sticky_label">'.esc_html__( 'Menu sticky', 'minfolio' ).'</label>					
						  </div>',		
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 3,					
				'tab' => 'menu'		
			),				
			array(			
				'id'	=> "{$prefix}page_menu_sticky",
				'type'	=> 'checkbox',				
				'desc'  => esc_html__( 'check to enable sticky menu on page.', 'minfolio' ),
				'hidden' => array( $prefix.'page_menu_override', 'not in', array( 'custom' ) ),
				'columns' => 9,
				'tab' => 'menu'		
			),	
		
				
			/* Footer Tab */							
			array(				
				'id'	=> "{$prefix}page_footer_override_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_page_footer_override_label">'.esc_html__( 'Footer', 'minfolio' ).'</label>					
						  </div>',		
				'columns' => 3,					
				'tab' => 'footer'		
			),				
			array(				
				'id'	=> "{$prefix}page_footer_override",
				'type'	=> 'select',
				'options'	=> array(
					'inherit'	=> esc_html__( 'Inherit', 'minfolio' ),					
					'custom'	=> esc_html__( 'Custom', 'minfolio' ),					
				),
				'desc'  => esc_html__( 'Override the footer', 'minfolio' ),
				'std'	=> 'inherit',	
				'columns' => 9,						
				'tab' => 'footer'
			),
			array(
				'type' => 'divider',
				'tab' => 'footer',
				'hidden' => array( $prefix.'page_footer_override', '!=', array( 'custom' ) ),
			),	
			array(				
				'id'	=> "{$prefix}footer_display_label",			
				'type' => 'custom_html',															
				'std' => '<div class="minfolio-rwmb-label">
							<label for="minfolio_footer_display_label">'.esc_html__( 'Footer display', 'minfolio' ).'</label>					
						  </div>',		
				'columns' => 3,	
				'hidden' => array( $prefix.'page_footer_override', '!=', array( 'custom' ) ),		
				'tab' => 'footer'		
			),			
			array(								
				'id'    => "{$prefix}footer_display",				
				'type'	=> 'radio',
				'options' => array(					
								'0' => esc_html__( 'Disabled', 'minfolio' ),			
								'1'	=> esc_html__( 'Enabled', 'minfolio' ),								
							),
				'std'	=> '0',			
				'columns' => 9,
				'hidden' => array( $prefix.'page_footer_override', '!=', array( 'custom' ) ),
				'tab' => 'footer'
			),					
		
		),

	);

