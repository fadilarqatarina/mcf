<?php 

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Customizer Loader
 */

if ( ! class_exists( 'Minfolio_Customizer' ) ) {

    class Minfolio_Customizer {

		/**
		* Instance		
		*/
		private static $instance;

        /**
		* Customizer Configurations.		 
		*/
		private static $configuration;


		/**
		* Init
		*/
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

        /**
		* Constructor
		*/
		public function __construct() {
			
			add_action( 'customize_preview_init', array( $this, 'preview_init' ) );

            add_action( 'customize_register', array( $this, 'include_configurations' ), 2 );

			add_action( 'customize_register', array( $this, 'customize_register_controls' ), 2 );

            add_action( 'customize_register', array( $this, 'prepare_customizer_configs' ) );		

        }

        /**
		* Include Customizer Configuration files.
		*		
		*/
		public function include_configurations() {

            require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/class-theme-customizer-config-base.php';

			/**
			 * Register Sections & Panels
			 */
            require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/class-theme-customizer-register-sections-panels.php';

			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-general-config.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-branding-config.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-menu-config.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-blog-config.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-portfolio-config.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-page404-config.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/configurations/options/class-customizer-footer-config.php';

        }

        /**
		* Prepare customizer configs
		*/
		public function prepare_customizer_configs() {

			global $wp_customize;

            $configurations = $this->get_customizer_configurations();	
			$defaults       = $this->get_customizer_configuration_defaults();

			foreach ( $configurations as $key => $configuration ) {

				$config = wp_parse_args( $configuration, $defaults );

                switch ( $config[ 'type' ] ) {

					case 'panel':
						$this->prepare_panel_configs( $wp_customize, $config );
						break;
					case 'section':
						$this->prepare_section_configs( $wp_customize, $config );
						break;				
					case 'control':
						$this->prepare_control_configs( $wp_customize, $config );
						break;

				}

            }

        }

		/**
		* Register custom controls, section and panel.			
		*/
		public function customize_register_controls( $wp_customize ) {

			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-customizer-control-sanitizes.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-customizer-control-base.php';
 			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-heading-title.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-simple-notice.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-toggle-switch.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-image-radio-button.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-text-radio-button.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-slider.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-responsive-slider.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-gradient-color.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-tinymce.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-sortable.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-color.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-global-colors.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-multi-colors.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-typography.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-padding.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-responsive-padding.php';
			require MINFOLIO_CORE_PATH . 'admin/customizer/custom-controls/class-control-dropdown-post.php';
			

			/**
			* Add Controls
			*/

			Minfolio_Customizer_Control_Base::add_control(
				'image',
				array(
					'callback'          => 'WP_Customize_Image_Control',
					'sanitize_callback' => 'esc_url_raw',
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-heading-title',
				array(
					'callback'          => 'Minfolio_Control_Heading_Title',
					'sanitize_callback' => 'sanitize_text_field',
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-simple-notice',
				array(
					'callback'          => 'Minfolio_Control_Simple_Notice',
					'sanitize_callback' => 'sanitize_text_field',
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-toggle-switch',
				array(
					'callback'          => 'Minfolio_Control_Toggle_Switch',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'toggle_switch_sanitization' )
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-image-radio-button',
				array(
					'callback'          => 'Minfolio_Control_Image_Radio_Button',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'text_image_radio_sanitization' )		
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-text-radio-button',
				array(
					'callback'          => 'Minfolio_Control_Text_Radio_Button',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'text_image_radio_sanitization' )				
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-slider',
				array(
					'callback'          => 'Minfolio_Control_Slider',
					//'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'range_sanitization' )		
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-responsive-slider',
				array(
					'callback'          => 'Minfolio_Control_Responsive_Slider',
					//'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'range_sanitization' )		
				)
			);
		
			Minfolio_Customizer_Control_Base::add_control(
				'clbr-tiny-mce',
				array(
					'callback'          => 'Minfolio_Control_Tiny_MCE',
					'sanitize_callback' => 'wp_kses_post',
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-sortable',
				array(
					'callback'          => 'Minfolio_Control_Sortable',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'text_sanitization' )		
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-color',
				array(
					'callback'          => 'Minfolio_Control_Color',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'hex_rgba_sanitization' )
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-global-colors',
				array(
					'callback'          => 'Minfolio_Control_Global_Colors',
					'sanitize_callback' =>  array( 'Minfolio_Customizer_Sanitizes', 'global_color_hex_rgba_sanitization' )
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-multi-colors',
				array(
					'callback'          => 'Minfolio_Control_Multi_Colors',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'multi_color_hex_rgba_sanitization' )
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-gradient-color',
				array(
					'callback'          => 'Minfolio_Control_Gradient_Color',				
				)
			);


			Minfolio_Customizer_Control_Base::add_control(
				'clbr-typography',
				array(
					'callback'          => 'Minfolio_Control_Typography',					
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-padding',
				array(
					'callback'          => 'Minfolio_Control_Padding',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'padding_sanitization' )
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-responsive-padding',
				array(
					'callback'          => 'Minfolio_Control_Responsive_Padding',
					'sanitize_callback' => array( 'Minfolio_Customizer_Sanitizes', 'responsive_padding_sanitization' )
				)
			);

			Minfolio_Customizer_Control_Base::add_control(
				'clbr-dropdown-post',
				array(
					'callback'          => 'Minfolio_Control_Dropdown_Post',
					'sanitize_callback' => 'absint',
				)
			);
			
			
		}

		/**
		* Prepare Panel Configs for Customizer.		 
		*/
		public function prepare_panel_configs( $wp_customize, $config ) {

			$wp_customize->add_panel( $config[ 'id' ], array(
				'title'            => $config[ 'title' ],
				'description'      => $config[ 'description' ],
				'priority'         => $config[ 'priority' ],
				'capability' 	   => $config[ 'capability' ],	
				'theme_supports'   => $config[ 'theme_supports' ],					
				'active_callback'  => $config[ 'active_callback' ],					
			));

		}

		/**
		* Prepare Section Configs for Customizer.		 
		*/
		public function prepare_section_configs( $wp_customize, $config ) {

			$wp_customize->add_section( $config[ 'id' ], array(
				'title'           => $config[ 'title' ],
				'description'     => $config[ 'description' ],
				'priority'        => $config[ 'priority' ],
				'panel' 		  => $config[ 'panel' ],	
				'capability' 	   => $config[ 'capability' ],	
				'theme_supports'   => $config[ 'theme_supports' ],					
				'active_callback'  => $config[ 'active_callback' ],		
			));

		}

		/**
		* Prepare Control Configs for Customizer.		 
		*/
		public function prepare_control_configs( $wp_customize, $config ) {

			$control_instance = Minfolio_Customizer_Control_Base::get_control_instance( $config[ 'control' ] );

			$wp_customize->add_setting( $config[ 'id' ], array(
				'default'       => $config[ 'default' ],
				'transport'     => $config[ 'transport' ],
				'type'      	=> 'theme_mod',
				'capability' 	=> $config[ 'capability' ],	
				'theme_supports' => $config[ 'theme_supports' ],	
				'validate_callback' => $config[ 'validate_callback' ],					
				'sanitize_js_callback' => $config[ 'sanitize_js_callback' ],	
				'sanitize_callback' => $config[ 'sanitize_callback' ] == null ? Minfolio_Customizer_Control_Base::get_sanitize_call( $config[ 'control' ] ) : $config[ 'sanitize_callback' ],				
			));


			if ( false !== $control_instance ) {

				$wp_customize->add_control( new $control_instance( $wp_customize, $config[ 'id' ], array(
						'label'        => $config[ 'label' ],
						'description'  => $config[ 'description' ],
						'choices'  	   => $config[ 'choices' ],
						'section'      => $config[ 'section' ],					
						'priority' 	   => $config[ 'priority' ],						
						'capability'   => $config[ 'capability' ],	
						'input_attrs'  => $config[ 'input_attrs' ],	
					)
				));	
			
			}
			else {
				
				$wp_customize->add_control( $config[ 'id' ], array(
					'label'        => $config[ 'label' ],
					'description'  => $config[ 'description' ],
					'choices'  	   => $config[ 'choices' ],
					'section'      => $config[ 'section' ],
					'priority' 	   => $config[ 'priority' ],	
					'type' 	   	   => $config[ 'control' ],	
					'capability'   => $config[ 'capability' ],	
					'input_attrs'  => $config[ 'input_attrs' ],	
				));	

			}

		}

		/**
		* Customizer Preview Init		
		*/
		public function preview_init() {

			wp_enqueue_script( 'minfolio-customize-preview', MINFOLIO_CORE_URL . 'admin/assets/js/customizer/customizer-preview.min.js', array( 'customize-preview', 'jquery' ), MINFOLIO_CORE_VERSION, true  );               
			
		}

        /**
		* Filter and return Customizer Configurations.		
		*/
		private function get_customizer_configurations() {

			global  $wp_customize;

			if ( ! is_null( self::$configuration ) ) {
				return self::$configuration;
			}

			self::$configuration = apply_filters( 'minfolio_customizer_configurations', array(), $wp_customize );
			return self::$configuration;

		}

		/**
		* Return default values for the Customize Configurations.
		*/
		private function get_customizer_configuration_defaults() {

			return apply_filters(
				'minfolio_customizer_configuration_defaults',
				array(
					'title'                => null,
					'description'          => null,
					'choices'        	   => null,
					'priority'             => null,
					'capability'           => null,
					'theme_supports'       => null,
					'active_callback'      => null,
					'panel'           	   => null,					
					'default'              => null,
					'transport'            => null,
					'validate_callback'    => null,
					'sanitize_callback'    => null,
					'sanitize_js_callback' => null,
					'label'       		   => null,
					'section'              => null,
					'input_attrs'          => null,					
				)
			);
		}

    }

}

Minfolio_Customizer::get_instance();