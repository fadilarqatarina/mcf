<?php
/**
 * Customizer Control: Typography
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Typography extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-typography';	

	/**
	* Enqueue our scripts and styles
	*/
	public function enqueue() {

		wp_enqueue_style( 'font-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/font-picker/css/font-picker.min.css', array(), MINFOLIO_CORE_VERSION );
		wp_enqueue_script( 'font-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/font-picker/js/font-picker.min.js', array(), MINFOLIO_CORE_VERSION, true );
		
	}


	/**
	* Render the control's content.	
	*/
	protected function render_content() {
	
		$value = empty( $this->value() ) ? '{}' : $this->value();
		
	?>	

		<div class="clbr-control-typography-wrapper">

            <label>		
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>							
			</label>			

            <div class="clbr-btn-wrapper" >              

                <div class="typography-control">
                    <div id="<?php echo esc_attr( $this->id ); ?>-anchor" class="typography-control-anchor">
						<span class="dashicons dashicons-edit"></span>
					</div>
					<input id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" type="text" class="clbr-control-typography" data-font="true" data-default="<?php echo esc_attr( $value ); ?>" data-placement="<?php echo esc_attr( $this->input_attrs[ 'placement' ] ); ?>" value="<?php echo esc_attr( $value ); ?>" <?php $this->link(); ?> />
                </div>		
				
				<button class="typography-reset"><i class="dashicons dashicons-image-rotate"></i></button>

            </div>

            <?php if ( isset( $this->description ) && '' !== $this->description ) { ?>
				<div class="description customize-control-description"><?php echo esc_html( $this->description ); ?></div>
			<?php } ?>	         
			
		</div>

	<?php

	}


}
