<?php
/**
 * Customizer Control: Responsive Slider
 * 
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Responsive_Slider extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-responsive-slider';

	public function enqueue() {	
		
		wp_enqueue_script( 'jquery-ui-slider' );
	}	

	/**
	* Render the control's content.	
	*/
	protected function render_content() {

		$devices = array( 'desktop', 'tablet', 'mobile' );

		$value_bucket = empty( $this->value() ) ? [] : json_decode( $this->value(), true );		

	?>

		<div class="clbr-responsive-input-slider-wrapper">

			
			<div class="clbr-responsive-padding-container">
				
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				</label>

				<ul class="clbr-responsive-options">
					<li class="desktop">
						<button type="button" class="preview-desktop active" data-device="desktop">
							<i class="dashicons dashicons-desktop"></i>
						</button>
					</li>
					<li class="tablet">
						<button type="button" class="preview-tablet" data-device="tablet">
							<i class="dashicons dashicons-tablet"></i>
						</button>
					</li>
					<li class="mobile">
						<button type="button" class="preview-mobile" data-device="mobile">
							<i class="dashicons dashicons-smartphone"></i>
						</button>
					</li>
				</ul>

			</div>

			<?php foreach ( $devices as $device ) {
				
				$saved_value = isset( $value_bucket[$device] ) ? $value_bucket[$device] : ''; ?>

				<div class="clbr-control-device clbr-control-<?php echo esc_attr( $device ); ?>">
					<div class="clbr-input-slider-control">
						<div class="slider" slider-min-value="<?php echo esc_attr( $this->choices['min'] ); ?>" slider-max-value="<?php echo esc_attr( $this->choices['max'] ); ?>" slider-step-value="<?php echo esc_attr( $this->choices['step'] ); ?>"></div>
						<span class="slider-reset dashicons dashicons-image-rotate" slider-reset-value="<?php echo esc_attr( $saved_value ); ?>"></span>
						<input type="text" name="<?php echo esc_attr( $this->id .'-' . $device ); ?>" value="<?php echo esc_attr( $saved_value ); ?>" class="customize-control-slider-value" data-device-type="<?php echo $device; ?>" />
					</div>
				</div>

			<?php }			

			if ( isset( $this->description ) && '' !== $this->description ) { ?>
				<div class="description customize-control-description"><?php echo esc_html( $this->description ); ?></div>
			<?php } ?>	

			<input id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" class="clbr-responsive-input-slider" <?php $this->link(); ?> />			

		</div>


	<?php }

}
