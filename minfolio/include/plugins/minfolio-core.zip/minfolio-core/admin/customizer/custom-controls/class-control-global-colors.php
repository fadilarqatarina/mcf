<?php
/**
 * Customizer Control: Global Colors
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Global_Colors extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-global-colors';

	public $global_colors = [];

	public function __construct( $manager, $id, $args = array() ) {		

		$this->global_colors = $this->get_global_colors();

        parent::__construct( $manager, $id, $args );
    }

	/**
	* Enqueue our scripts and styles
	*/
	public function enqueue() {

		wp_enqueue_style( 'color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/color-picker/css/light.min.css', array(), MINFOLIO_CORE_VERSION );
		wp_enqueue_style( 'global-color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/color-picker/css/light-square.min.css', array(), MINFOLIO_CORE_VERSION );
		wp_enqueue_script( 'color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/color-picker/js/default-picker.min.js', array(), MINFOLIO_CORE_VERSION, true );
		wp_enqueue_script( 'global-color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/color-picker/js/global-color-picker.min.js', array(), MINFOLIO_CORE_VERSION, true );
		
	}

	public function to_json() {
		parent::to_json();
		$this->json[ 'global_colors' ] = $this->global_colors;		
	  }

	/**
	* Render the control in the customizer
	*/
	public function render_content() { 

		$color_value = json_encode( $this->value() );
		
	?>

		<div class="clbr-control-global-color-wrapper">  
			
			<label>		
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>							
			</label>		

			<div class="clbr-global-color-container">
				<div id="<?php echo esc_attr( $this->id ); ?>-anchor"  class="colorpicker-custom-anchor colorpicker-circle-anchor">
					<div class="colorpicker-transparent-background"></div>
					<div class="colorpicker-circle-anchor__color" data-color></div>				
				</div>		
				<div id="<?php echo esc_attr( $this->id ); ?>-global-anchor"  class="colorpicker-custom-anchor colorpicker-circle-anchor">
					<div class="colorpicker-circle-anchor__color" data-color><span class="dashicons dashicons-admin-site-alt3"></span></div>				
				</div>				
			</div>
			
			<?php if ( isset( $this->description ) && '' !== $this->description ) { ?>
				<div class="description customize-control-description"><?php echo esc_html( $this->description ); ?></div>
			<?php } ?>	

			<input id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $color_value ); ?>" data-placement="<?php echo esc_attr( $this->input_attrs[ 'placement' ] ); ?>" type="text" class="clbr-control-global-color" />

        </div>

	<?php
	}

	private function get_global_colors() {
           
		$result = [];

		if ( did_action( 'elementor/loaded' ) ) {			

			$kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit_for_frontend();               
		   
			$items = $kit->get_settings_for_display( 'system_colors' );        
			    				    
			foreach ( $items as $index => $item ) {    				
			    $result[ $item[ '_id' ] ] = $item[ 'color' ];
			}

			$items = $kit->get_settings_for_display( 'custom_colors' ); 

			foreach ( $items as $index => $item ) {            
			    $result[ $item[ '_id' ] ] = $item[ 'color' ];
			}

		}

		return $result;

	}     

}
