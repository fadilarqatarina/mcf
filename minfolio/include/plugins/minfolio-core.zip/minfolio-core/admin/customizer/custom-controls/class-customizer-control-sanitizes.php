<?php
/**
 * Theme Customizer Sanitize.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes
 */
if ( ! class_exists( 'Minfolio_Customizer_Sanitizes' ) ) {

	/**
	 * Customizer Sanitizes Initial setup
	 */
	class Minfolio_Customizer_Sanitizes {

		private static $instance;
		
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
		
		public function __construct() { }

        /**
	    * Toggle Switch sanitization	
	    */
        public static function toggle_switch_sanitization( $input ) {

            if ( true === $input ) {
                return 1;
            } else {
                return 0;
            }
            
        }

        /**
	    * Text/Image Radio Button sanitization	
	    */
        public static function text_image_radio_sanitization( $input, $setting ) {
           
            //get the list of possible radio box or select options
            $choices = $setting->manager->get_control( $setting->id )->choices;
    
            if ( array_key_exists( $input, $choices ) ) {
                return $input;
            } else {
                return $setting->default;
            }
        }   

        /**
        * Text sanitization
        *        
        */
        public static function text_sanitization( $input ) {
           
            if ( strpos( $input, ',' ) !== false) {
                $input = explode( ',', $input );
            }

            if( is_array( $input ) ) {
                foreach ( $input as $key => $value ) {
                    $input[$key] = sanitize_text_field( $value );
                }
                $input = implode( ',', $input );
            }
            else {
                $input = sanitize_text_field( $input );
            }

            return $input;
            
        }

        
        /**
	    * Range sanitization	
	    */
        public static function range_sanitization( $input, $setting ) {
           
            $attrs = $setting->manager->get_control( $setting->id )->input_attrs;

			$min = ( isset( $attrs['min'] ) ? $attrs['min'] : $input );
			$max = ( isset( $attrs['max'] ) ? $attrs['max'] : $input );
			$step = ( isset( $attrs['step'] ) ? $attrs['step'] : 1 );

			$number = floor( $input / $attrs['step'] ) * $attrs['step'];

			return self::check_in_range( $number, $min, $max );

        }    
               
        /**
        * Color (Hex & RGBa) sanitization
        */
        public static function hex_rgba_sanitization( $input, $setting ) {
           
            if ( empty( $input ) ) {
                return $setting->default;
            }

            $input = self::check_color( $input );

            return $input;
            
        }

        /**
        * Global Color (Hex & RGBa) sanitization
        */
        public static function global_color_hex_rgba_sanitization( $input, $setting ) {   

            if ( empty( $input ) ) {
                return $setting->default;
            }

            $input[ 'local' ]  = ( $input[ 'local' ]  !== 'transparent' )  ? self::check_color( $input[ 'local' ] )  : $input[ 'local' ];
            $input[ 'global' ] = ( $input[ 'global' ] !== 'transparent' )  ? self::check_color( $input[ 'global' ] ) : $input[ 'global' ];
            $input[ 'value' ]  = self::check_color( $input[ 'value' ] );
          
            return $input;
            
        }

        /**
        * Multi Color (Hex & RGBa) sanitization
        */
        public static function multi_color_hex_rgba_sanitization( $input, $setting ) {   

            if ( empty( $input ) ) {
                return $setting->default;
            }

            $input[ 'regular' ]  = self::check_color( $input[ 'regular' ] );
            $input[ 'hover' ]    = self::check_color( $input[ 'hover' ] );
            $input[ 'active' ]   = self::check_color( $input[ 'active' ] );
          
            return $input;
            
        }

        /**
        * Dimension sanitization
        */
        public static function padding_sanitization( $input, $setting ) {   

            if ( empty( $input ) ) {
                return $setting->default;
            }

            $input = json_decode( trim( $input ), true );  
            
            if( isset( $input[ 'top' ] ) ) {
                $input[ 'top' ] =  absint( $input[ 'top' ] );
            }

            if( isset( $input[ 'right' ] ) ) {
                $input[ 'right' ] =  absint( $input[ 'right' ] );
            }

            if( isset( $input[ 'bottom' ] ) ) {
                $input[ 'bottom' ] =  absint( $input[ 'bottom' ] );
            }

            if( isset( $input[ 'left' ] ) ) {
                $input[ 'left' ] =  absint( $input[ 'left' ] );
            }         
          
            $input = json_encode( $input );
          
            return $input;
            
        }

        /**
        * Responsive Padding sanitization
        */
        public static function responsive_padding_sanitization( $input, $setting ) {                

            if ( empty( $input ) ) {
                return $setting->default;
            }

            if ( ! empty( $input ) ) {

                $input = json_decode( trim( $input ), true );                

                if( isset( $input[ 'desktop_top' ] ) ) {
                    $input[ 'desktop_top' ] =  absint( $input[ 'desktop_top' ] );
                }

                if( isset( $input[ 'desktop_right' ] ) ) {
                    $input[ 'desktop_right' ] =  absint( $input[ 'desktop_right' ] );
                }

                if( isset( $input[ 'desktop_bottom' ] ) ) {
                    $input[ 'desktop_bottom' ] =  absint( $input[ 'desktop_bottom' ] );
                }

                if( isset( $input[ 'desktop_left' ] ) ) {
                    $input[ 'desktop_left' ] =  absint( $input[ 'desktop_left' ] );
                }

                if( isset( $input[ 'tablet_top' ] ) ) {
                    $input[ 'tablet_top' ] =  absint( $input[ 'tablet_top' ] );
                }

                if( isset( $input[ 'tablet_right' ] ) ) {
                    $input[ 'tablet_right' ] =  absint( $input[ 'tablet_right' ] );
                }

                if( isset( $input[ 'tablet_bottom' ] ) ) {
                    $input[ 'tablet_bottom' ] =  absint( $input[ 'tablet_bottom' ] );
                }

                if( isset( $input[ 'tablet_left' ] ) ) {
                    $input[ 'tablet_left' ] =  absint( $input[ 'tablet_left' ] );
                }

                if( isset( $input[ 'mobile_top' ] ) ) {
                    $input[ 'mobile_top' ] =  absint( $input[ 'mobile_top' ] );
                }

                if( isset( $input[ 'mobile_right' ] ) ) {
                    $input[ 'mobile_right' ] =  absint( $input[ 'mobile_right' ] );
                }

                if( isset( $input[ 'mobile_bottom' ] ) ) {
                    $input[ 'mobile_bottom' ] =  absint( $input[ 'mobile_bottom' ] );
                }

                if( isset( $input[ 'mobile_left' ] ) ) {
                    $input[ 'mobile_left' ] =  absint( $input[ 'mobile_left' ] );
                }		  
			 

                $input = json_encode( $input );

            }
    
            return $input;   
                        
        }        
       
        public static function check_in_range( $input, $min, $max ) {

            if ( $input < $min ) {
                $input = $min;
            }

            if ( $input > $max ) {
                $input = $max;
            }

            return $input;

        }    
        
        public static function check_color( $color ) {

            if ( false === strpos( $color, 'rgba' ) ) {
                // If string doesn't start with 'rgba' then santize as hex color
                $color = sanitize_hex_color( $color );
            } else {
                // Sanitize as RGBa color
                $color = str_replace( ' ', '', $color );
                sscanf( $color, 'rgba(%d,%d,%d,%f)', $red, $green, $blue, $alpha );
                $color = 'rgba(' . self::check_in_range( $red, 0, 255 ) . ',' . self::check_in_range( $green, 0, 255 ) . ',' . self::check_in_range( $blue, 0, 255 ) . ',' . self::check_in_range( $alpha, 0, 1 ) . ')';
            }

            return $color;

        }    
        
        public static function check_numeric( $value ) {

            if( empty( $value ) ) {
                return '';
            }

            $value = substr( $value, 0, -2 );

            if( is_numeric( $value ) ) {
                $value = $value . 'px';
            }
            else {
                $value = '';
            }

            return $value;

        }
        
    }

}

self::get_instance();