<?php
/**
 * Customizer Control: Multi Colors
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Multi_Colors extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-multi-colors';
	
	/**
	* Enqueue our scripts and styles
	*/
	public function enqueue() {

		wp_enqueue_style( 'color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/color-picker/css/light.min.css', array(), MINFOLIO_CORE_VERSION );
		wp_enqueue_script( 'color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/color-picker/js/default-picker.min.js', array(), MINFOLIO_CORE_VERSION, true );
		
	}
	

	/**
	* Render the control in the customizer
	*/
	public function render_content() {

		$multicolor_value = json_encode( $this->value() );

	?>		

		<div class="clbr-control-multi-color-wrapper">
		
			<label>		
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>							
			</label>				
            
			<div class="clbr-multi-color-container">
				<div id="<?php echo esc_attr( $this->id ); ?>-regular"  class="colorpicker-custom-anchor colorpicker-circle-anchor">
					<div class="colorpicker-circle-anchor__color" data-color></div>				
					<span class="colopicker-label">Regular</span>
				</div>		
				<div id="<?php echo esc_attr( $this->id ); ?>-hover"  class="colorpicker-custom-anchor colorpicker-circle-anchor">
					<div class="colorpicker-circle-anchor__color" data-color></div>		
					<span class="colopicker-label">Hover</span>		
				</div>	
				<div id="<?php echo esc_attr( $this->id ); ?>-active"  class="colorpicker-custom-anchor colorpicker-circle-anchor">
					<div class="colorpicker-circle-anchor__color" data-color></div>		
					<span class="colopicker-label">Active</span>				
				</div>	
			</div>
			
			<?php if ( isset( $this->description ) && '' !== $this->description ) { ?>
				<div class="description customize-control-description"><?php echo esc_html( $this->description ); ?></div>
			<?php } ?>	

			<input id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $multicolor_value ); ?>" data-placement="<?php echo esc_attr( $this->input_attrs[ 'placement' ] ); ?>" type="text" class="clbr-control-multi-colors" />

        </div>

	<?php
	}

}
