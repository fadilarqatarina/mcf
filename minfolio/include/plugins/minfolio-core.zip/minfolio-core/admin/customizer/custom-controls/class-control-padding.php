<?php
/**
 * Customizer Control: Padding
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Padding extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-padding';	
	
	/**
	* Render the control in the customizer
	*/
	public function render_content() { 

		$areas = array( 'top', 'right', 'bottom', 'left' );

		$value_bucket = empty( $this->value() ) ? [] : json_decode( $this->value(), true );

	?>

		<div class="clbr-control-padding-wrapper">	
		
			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>					
			</label>	

			<?php foreach ( $areas as $area ) { ?>

				<?php
					$saved_value = isset( $value_bucket[$area] ) ? $value_bucket[$area] : '';
					// Custom sanitization.
					// Only sanitize using intval if we actually have a value
					// Otherwise, default to false. This allows us to save empty fields.
					$saved_value = $saved_value ? intval( $saved_value ) : '';
				?>

				<div class="clbr-control-padding-<?php echo esc_attr( $area ); ?>">
					<label>
						<input type="number" value="<?php echo $saved_value; ?>" class="customize-control-padding-value" data-area-type="<?php echo $area; ?>">
						<small><?php echo esc_html( ucfirst( $area ) ); ?></small>
					</label>
				</div>

			<?php } ?>

			<span class="px">px</span>

			<?php if ( isset( $this->description ) && '' !== $this->description ) {
				echo '<span class="description customize-control-description">' . esc_html( $this->description ) . '</span>';
			} ?>

			<input id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" type="text" class="clbr-padding-value" />

		</div>			
	
	
	<?php
	}

}
