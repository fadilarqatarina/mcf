<?php
/**
 * Customizer Control: Tiny MCE
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Tiny_MCE extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-tiny-mce';

	public function enqueue() {	
		wp_enqueue_editor();
	}
	
	public function to_json() {
		parent::to_json();
		$this->json[ 'clbr_tinymce_toolbar1' ] = isset( $this->input_attrs[ 'toolbar1' ] ) ? esc_attr( $this->input_attrs[ 'toolbar1' ] ) : 'bold italic bullist numlist alignleft aligncenter alignright link';
		$this->json[ 'clbr_tinymce_toolbar2' ] = isset( $this->input_attrs[ 'toolbar2' ] ) ? esc_attr( $this->input_attrs[ 'toolbar2' ] ) : '';
		$this->json[ 'clbr_tinymce_mediabuttons' ] = isset( $this->input_attrs[ 'mediaButtons' ] ) && ( $this->input_attrs[ 'mediaButtons' ] === true ) ? true : false;
	}
	/**
	 * Render the control in the customizer
	 */
	public function render_content() { ?>

		<div class="clbr-control-tinymce">

			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			</label>

			<textarea id="<?php echo esc_attr( $this->id ); ?>" class="customize-control-tinymce-editor" <?php $this->link(); ?>><?php echo esc_attr( $this->value() ); ?></textarea>

			<?php if( !empty( $this->description ) ) { ?>
				<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php } ?>

		</div>
	
	<?php }

}
