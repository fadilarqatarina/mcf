<?php
/**
 * Theme Customizer Configuration Base.
 * 
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base Class for Registering Customizer Controls.
 * 
 */
if ( ! class_exists( 'Minfolio_Customizer_Control_Base' ) ) {

	/**
	 * Customizer Sanitizes Initial setup
	 */
	class Minfolio_Customizer_Control_Base {

		/**
		* Registered Controls.	
		*/
		private static $controls;

		/**
		*  Constructor
		*/
		public function __construct() {

			add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		}

		/**
		* Enqueue Admin Scripts		
		*/
		public function enqueue_scripts() {		

			wp_enqueue_style( 'minfolio_customizer_css', MINFOLIO_CORE_URL . 'admin/assets/css/customizer-controls.min.css', array(), MINFOLIO_CORE_VERSION, 'all'  );
			wp_enqueue_script( 'minfolio_customizer_js', MINFOLIO_CORE_URL . 'admin/assets/js/customizer/customizer-controls.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true  );               
			
		}

		/**
		* Add Control to self::$controls and Register control to WordPress Customizer.		
		*/
		public static function add_control( $name, $atts ) {

			global $wp_customize;
			
			self::$controls[ $name ] = $atts;
		}

		/**
		* Returns control instance	
		*/
		public static function get_control_instance( $control_type ) {
			$control_class = self::get_control( $control_type );

			if ( isset( $control_class['callback'] ) ) {
				return class_exists( $control_class['callback'] ) ? $control_class['callback'] : false;
			}

			return false;
		}

		/**
		* Returns control and its attributes		
		*/
		public static function get_control( $control_type ) {
			if ( isset( self::$controls[ $control_type ] ) ) {
				return self::$controls[ $control_type ];
			}

			return array();
		}

		/**
		* Returns Santize callback for control	
		*/
		public static function get_sanitize_call( $control ) {

			if ( isset( self::$controls[ $control ]['sanitize_callback'] ) ) {
				return self::$controls[ $control ]['sanitize_callback'];
			}

			return false;
		}
	}
}


new Minfolio_Customizer_Control_Base();
