<?php
/**
 * Customizer Control: Dropdown Post
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Dropdown_Post extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-dropdown-post';	
	
	/**
	* Posts
	*/
	private $posts = array();

	
	/**
	* Constructor
	*/
	public function __construct( $manager, $id, $args = array(), $options = array() ) {

		parent::__construct( $manager, $id, $args );

		// Get our Posts
		$this->posts = get_posts( $this->input_attrs );

	}
	

	/**
	* Render the control in the customizer
	*/
	public function render_content() { ?>

		
		<div class="clbr-control-dropdown-posts-wrapper">  

			<label>		
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>							
			</label>
			
			<select name="<?php echo $this->id; ?>" id="<?php echo $this->id; ?>" <?php $this->link(); ?> >
				<?php
					if( !empty( $this->posts ) ) {

						foreach ( $this->posts as $post ) {
							printf( '<option value="%s" %s>%s</option>',
								$post->ID,
								selected( $this->value(), $post->ID, false ),
								$post->post_title
							);
						}
					}
				?>
			</select>

			<?php if ( isset( $this->description ) && '' !== $this->description ) { ?>
				<div class="description customize-control-description"><?php echo esc_html( $this->description ); ?></div>
			<?php } ?>	

		</div>	

	<?php
	}

}
