<?php
/**
 * Customizer Control: Banner Title
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Heading_Title extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-heading-title';
	

	/**
	* Render the control's content.	
	*/
	protected function render_content() {

		$label = $this->label;

	?>
		<div class="clbr-control-heading-title">
			<span class="customize-control-title">
				<?php echo esc_html( $label ); ?>
			</span>
		</div>

	<?php

	}

}
