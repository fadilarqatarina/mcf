<?php
/**
 * Customizer Control: Slider
 * 
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Slider extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-slider';

	public function enqueue() {	
		
		wp_enqueue_script( 'jquery-ui-slider' );
	}	

	/**
	* Render the control's content.	
	*/
	protected function render_content() {

	?>
		<div class="clbr-input-slider-wrapper">

			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			</label>
			
			<div class="clbr-input-slider-control">
				<div class="slider" slider-min-value="<?php echo esc_attr( $this->choices['min'] ); ?>" slider-max-value="<?php echo esc_attr( $this->choices['max'] ); ?>" slider-step-value="<?php echo esc_attr( $this->choices['step'] ); ?>"></div>
				<span class="slider-reset dashicons dashicons-image-rotate" slider-reset-value="<?php echo esc_attr( $this->value() ); ?>"></span>
				<input type="text" id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" class="customize-control-slider-value" <?php $this->link(); ?> />
			</div>				
			
			<?php if ( isset( $this->description ) && '' !== $this->description ) { ?>
				<div class="description customize-control-description"><?php echo esc_html( $this->description ); ?></div>
			<?php } ?>	

		</div>

	<?php

	}

}
