<?php
/**
 * Customizer Control: Text Radio Button
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Text_Radio_Button extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-text-radio-button';
	

	/**
	* Render the control's content.	
	*/
	protected function render_content() { ?>

		<div class="clbr-control-text-radio-button">

			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			</label>			

			<div class="clbr-radio-buttons">
				<?php foreach ( $this->choices as $key => $value ) { ?>
					<label class="radio-button-label">
						<input type="radio" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php $this->link(); ?> <?php checked( esc_attr( $key ), $this->value() ); ?>/>
						<span><?php echo esc_attr( $value ); ?></span>
					</label>
				<?php } ?>
			</div>

			<?php if( !empty( $this->description ) ) { ?>
				<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php } ?>

		</div>

	<?php

	}

}
