<?php
/**
 * Customizer Control: Simple Notice
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Simple_Notice extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-simple-notice';
	

	/**
	* Render the control's content.	
	*/
	protected function render_content() {

		$allowed_html = array(
			'a' => array(
				'href' => array(),
				'title' => array(),
				'class' => array(),
				'target' => array(),
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
			'i' => array(
				'class' => array()
			),
			'span' => array(
				'class' => array(),
			),
			'code' => array(),
		);

	?>
		
		<div class="clbr-control-simple-notice">

			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			</label>
			
			<?php if( !empty( $this->description ) ) { ?>
				<span class="customize-control-description"><?php echo wp_kses( $this->description, $allowed_html ); ?></span>
			<?php } ?>

		</div>

	<?php
	}

}
