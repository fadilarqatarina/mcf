<?php
/**
 * Customizer Control: Responsive Padding
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Responsive_Padding extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-responsive-padding';	
	

	/**
	* Render the control in the customizer
	*/
	public function render_content() { 
	
		$devices = array( 'desktop', 'tablet', 'mobile' );
		$areas   = array( 'top', 'right', 'bottom', 'left' );

		$value_bucket = empty( $this->value() ) ? [] : json_decode( $this->value(), true );

	?>			
		<div class="clbr-responsive-padding-wrapper">	

			<div class="clbr-responsive-padding-container">
			
				<label>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>					
				</label>	

				<ul class="clbr-responsive-options">
					<li class="desktop">
						<button type="button" class="preview-desktop active" data-device="desktop">
							<i class="dashicons dashicons-desktop"></i>
						</button>
					</li>
					<li class="tablet">
						<button type="button" class="preview-tablet" data-device="tablet">
							<i class="dashicons dashicons-tablet"></i>
						</button>
					</li>
					<li class="mobile">
						<button type="button" class="preview-mobile" data-device="mobile">
							<i class="dashicons dashicons-smartphone"></i>
						</button>
					</li>
				</ul>
				
			</div>
			
			<?php foreach ( $devices as $device ) { ?>

				<div class="clbr-control-device clbr-control-<?php echo esc_attr( $device ); ?>">

					<?php foreach ( $areas as $area ) { ?>

						<div class="clbr-control-padding-<?php echo esc_attr( $area ); ?>">

							<?php
								$saved_value = isset( $value_bucket[$device . '_' . $area] ) ? $value_bucket[$device . '_' . $area] : '';
								// Custom sanitization.
								// Only sanitize using intval if we actually have a value
								// Otherwise, default to false. This allows us to save empty fields.
								$saved_value = $saved_value ? intval( $saved_value ) : '';
							?>

							<label>
								<input type="number" value="<?php echo $saved_value; ?>"  class="customize-control-responsive-padding-value" data-area-device-type="<?php echo $device . '_' . $area; ?>">
								<small><?php echo esc_html( ucfirst( $area ) ); ?></small>
							</label>

						</div>

					<?php } ?>

					<span class="px">px</span>

				</div>

				<?php

			} ?>	
					
			<?php if ( isset( $this->description ) && '' !== $this->description ) {
				echo '<span class="description customize-control-description">' . esc_html( $this->description ) . '</span>';
			} ?>

            <input id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" type="text" class="clbr-control-responsive-padding" />
			
        </div>

	<?php
	}

}
