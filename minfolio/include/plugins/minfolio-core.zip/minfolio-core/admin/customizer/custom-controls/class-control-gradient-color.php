<?php
/**
 * Customizer Control: Gradient Color
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Gradient_Color extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-gradient-color';

	public function enqueue() {	
		wp_enqueue_script( 'lc-color-picker', MINFOLIO_CORE_URL . 'admin/assets/js/vendor/lc-color-picker/lc-color-picker.js', array(), MINFOLIO_CORE_VERSION, true );
	}

    /*
    *  Content for this custom control
    */ 
    public function render_content() { ?>

		<div class="clbr-control-gradient-color">

			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			</label>

			<input type="text" id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" />

			<?php if( !empty( $this->description ) ) { ?>
				<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php } ?>		

		</div>			

    <?php }	

}
