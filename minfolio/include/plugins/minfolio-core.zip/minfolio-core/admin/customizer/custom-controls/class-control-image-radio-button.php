<?php
/**
 * Customizer Control: Image Radio Button
 *
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Minfolio_Control_Image_Radio_Button extends WP_Customize_Control {

	/**
	* The control type.
	*/
	public $type = 'clbr-image-radio-button';
	

	/**
	* Render the control's content.	
	*/
	protected function render_content() { ?>		

		<div class="clbr-control-image-radio-button">

			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			</label>

			<?php foreach ( $this->choices as $key => $value ) { ?>
				<label class="clbr-radio-buttons">
					<input type="radio" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php $this->link(); ?> <?php checked( esc_attr( $key ), $this->value() ); ?>/>
					<img src="<?php echo esc_attr( $value['image'] ); ?>" alt="<?php echo esc_attr( $value['name'] ); ?>" title="<?php echo esc_attr( $value['name'] ); ?>" />
				</label>
			<?php } ?>

			<?php if( !empty( $this->description ) ) { ?>
				<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php } ?>

		</div>

	<?php

	}

}
