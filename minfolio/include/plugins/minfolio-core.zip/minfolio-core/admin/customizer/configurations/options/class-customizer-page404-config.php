<?php
/**
 * Theme Customizer for Page 404
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_Page404_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_Page404_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(				

				array(
                    'id'      => 'page404-label-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-page404',
					'label'   => esc_html__( 'Page 404 Labels', 'minfolio' ),     					
				),
				
				array(
                    'id'      => 'page-title',
					'default' => '404',
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-page404',
                    'label'   => esc_html__( 'Page Title', 'minfolio' ),	          					
				),

				array(
                    'id'      => 'page-subtitle',
					'default' => 'Sorry, the page requested couldn\'t be found.', 
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-page404',
                    'label'   => esc_html__( 'Page Subtitle', 'minfolio' ),	  			
				),

				array(
                    'id'      => 'page-desc',
					'default' => 'Sorry, the page The page you are looking for might have been removed had its name changed or its temporarily unavailable.',  
                    'type'    => 'control',
					'control' => 'textarea',                    
                    'section' => 'section-page404',
					'label'   => esc_html__( 'Page Description', 'minfolio' ),	   			
				),

				array(
                    'id'      => 'page-btn-text',
					'default' => 'Back to Home',   
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-page404',
                    'label'   => esc_html__( 'Button Text', 'minfolio' ),	  
				),

			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_Page404_Configs();
