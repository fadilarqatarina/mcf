<?php
/**
 * Theme Customizer for Menu
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_Menu_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_Menu_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(

				array(
                    'id'      => 'menu-settings-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-menu',
                    'label'     => esc_html__( 'Menu Settings', 'minfolio' ),                    					
				),

				array(
					'id'      	  => 'menu-type',
					'type'        => 'control',		
					'control'     => 'clbr-image-radio-button',			
					'label'       => esc_html__( 'Type', 'minfolio' ),										
					'choices'     => array(
                    				    'default-menu'  =>  array(
																'image' => MINFOLIO_CORE_URL . 'admin/assets/images/theme-options/standard.png',
																'name' => esc_html__( 'Default Menu', 'minfolio' )  
															),
                        				'centered-menu' =>  array(
																'image' => MINFOLIO_CORE_URL . 'admin/assets/images/theme-options/centered-menu.png',
																'name' => esc_html__( 'Centered Menu', 'minfolio' )  
															)
									),
					'section'     => 'section-menu',
					'default'     => 'default-menu',
				),

				array(
					'id'      	  => 'menu-layout',
					'type'        => 'control',		
					'control'     => 'clbr-text-radio-button',			
					'label'       => esc_html__( 'Layout', 'minfolio' ),										
					'choices'     => [
										'boxed'   => esc_html__( 'Boxed', 'minfolio' ),
										'full-width' => esc_html__( 'Full Width', 'minfolio' ),            
									],   
					'section'     => 'section-menu',
					'default'     => 'boxed',
				),

				array(
					'id'      	  => 'menu-display',
					'type'        => 'control',		
					'control'     => 'clbr-text-radio-button',			
					'label'       => esc_html__( 'Display', 'minfolio' ),										
					//'default'     => 'solid',      
					'choices'     => [
										'solid'			=> esc_html__( 'Solid', 'minfolio' ),
										'transparent'   => esc_html__( 'Transparent', 'minfolio' ),	 
									],   
					'section'     => 'section-menu',					
				),

				array(
					'id'      	  => 'menu-sticky',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',			
					'label'       => esc_html__( 'Sticky', 'minfolio' ),					
					'section'     => 'section-menu',
					'default'     => 0,
				),
				
				array(
                    'id'      => 'contact-email',
					'default' => 'hello@info.com',
                    'type'    => 'control',
					'control' => 'text',                   
                    'section'   => 'section-menu',
					'sanitize_callback' => 'sanitize_email',
					'label'     => esc_html__( 'Contact Email', 'minfolio' ),  
				),

				array(
                    'id'      => 'menu-style-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-menu',
                    'label'     => esc_html__( 'Menu Style', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'menu-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',     
					'input_attrs' => array( 'placement' => 'bottom' ),						         	              
                    'section'   => 'section-menu',
					'transport' => 'postMessage',
                    'label'     => esc_html__( 'Typography', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'menu-style-solid-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-menu',
                    'label'     => esc_html__( 'Solid Menu Style', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'menu-bg-color',
					'default' => '#ffffff',
                    'type'    => 'control',
					'control' => 'clbr-color',  
					'input_attrs' => array( 'placement' => 'top' ),			
					'placement' => 'top',   					
                    'section' => 'section-menu',
					'transport' => 'postMessage',
					'label'    => esc_html__( 'Background color', 'minfolio' ),						

				),

				array(
					'id'      	  => 'menu-solid-link-custom',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',			
					'label'       => esc_html__( 'Enable Custom Link Color', 'minfolio' ),					
					'section'     => 'section-menu',
					'default'     => 0,
				),

				array(
                    'id'      => 'menu-link-color',
					'default' => [
									'regular' => '#151515',
									'hover'   => '#f77f00',	
									'active' => '#151515',								
								],
                    'type'    => 'control',
					'control' => 'clbr-multi-colors',   
					'input_attrs' => array( 'placement' => 'top' ),			  					
                    'section' => 'section-menu',
					'transport' => 'postMessage',
					'label'    => esc_html__( 'Link Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'menu-style-transparent-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-menu',
                    'label'     => esc_html__( 'Transparent Menu Style', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'menu-transparent-link-color',
					'default' => [
									'regular' => 'rgba(255,255,255,1)',
									'hover'   => 'rgba(255,255,255,.5)',
									'active'  => 'rgba(255,255,255,1)',						
								],
                    'type'    => 'control',
					'control' => 'clbr-multi-colors',   
					'input_attrs' => array( 'placement' => 'top' ),			  					
                    'section' => 'section-menu',
					'transport' => 'postMessage',
					'label'    => esc_html__( 'Link Color', 'minfolio' ),	
				),

				

			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_Menu_Configs();
