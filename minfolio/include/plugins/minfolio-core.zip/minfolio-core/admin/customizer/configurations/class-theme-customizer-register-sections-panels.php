<?php


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'Minfolio_Customizer_Register_Sections_Panels' ) ) {

	
	class Minfolio_Customizer_Register_Sections_Panels extends Minfolio_Customizer_Config_Base {

       	/**
		 * Register Panels and Sections for Customizer.		 		
		 */
		public function register_configuration( $configurations, $wp_customize ) {

            $configs = array(

				/**
				* General section
				*/
				array(
					'id'     => 'section-general',
					'type' => 'section',
					'priority' => 10,
					'title'    => esc_html__( 'General', 'minfolio' ),
				),

				/**
				* Colors section
				*/
				array(
					'id'     => 'section-colors',
					'type'     => 'section',
					'priority' => 11,
					'title'    => esc_html__( 'Colors', 'minfolio' ),
				),

				/**
				* Branding section
				*/
				array(
					'id'     => 'section-branding',
					'type'     => 'section',
					'priority' => 12,
					'title'    => esc_html__( 'Branding', 'minfolio' ),
				),

				/**
				* Menu section
				*/
				array(
					'id'     => 'section-menu',
					'type'     => 'section',
					'priority' => 13,
					'title'    => esc_html__( 'Menu', 'minfolio' ),
				),

				/**
				* Blog Panel
				*/
				array(
					'id'     => 'panel-blog',
					'type'     => 'panel',
					'priority' => 14,
					'title'    => esc_html__( 'Blog', 'minfolio' ),
				),

				/**
				* Blog Archive section
				*/
				array(
					'id'     => 'section-blog-archive',
					'type'     => 'section',
					'panel'  => 'panel-blog',
					'priority' => 10,
					'title'    => esc_html__( 'Blog / Archive', 'minfolio' ),
				),

				/**
				* Blog Single section
				*/
				array(
					'id'     => 'section-blog-single',
					'type'     => 'section',
					'panel'  => 'panel-blog',
					'priority' => 10,
					'title'    => esc_html__( 'Single Post', 'minfolio' ),
				),

				/**
				* Blog Typography section
				*/
				array(
					'id'     => 'section-blog-typography',
					'type'   => 'section',
					'panel'  => 'panel-blog',
					'priority' => 10,
					'title'    => esc_html__( 'Typography', 'minfolio' ),
				),

				/**
				* Portfolio Panel
				*/
				array(
					'id'     => 'panel-portfolio',
					'type'     => 'panel',
					'priority' => 15,
					'title'    => esc_html__( 'Portfolio', 'minfolio' ),
				),

				/**
				* Portfolio Settings section
				*/
				array(
					'id'     => 'section-portfolio-settings',
					'type'   => 'section',
					'panel'  => 'panel-portfolio',
					'priority' => 10,
					'title'    => esc_html__( 'Portfolio Settings', 'minfolio' ),
				),


				/**
				* Portfolio Archive section
				*/
				array(
					'id'     => 'section-portfolio-archive',
					'type'   => 'section',
					'panel'  => 'panel-portfolio',
					'priority' => 10,
					'title'    => esc_html__( 'Portfolio / Archive', 'minfolio' ),
				),

				/**
				* Portfolio Single section
				*/
				array(
					'id'     => 'section-portfolio-single',
					'type'   => 'section',
					'panel'  => 'panel-portfolio',
					'priority' => 10,
					'title'    => esc_html__( 'Single Portfolio', 'minfolio' ),
				),

				/**
				* Portfolio Typography section
				*/
				array(
					'id'     => 'section-portfolio-typography',
					'type'   => 'section',
					'panel'  => 'panel-portfolio',
					'priority' => 10,
					'title'    => esc_html__( 'Typography', 'minfolio' ),
				),


				/**
				* Page 404 section
				*/
				array(
					'id'     => 'section-page404',
					'type'     => 'section',
					'priority' => 16,
					'title'    => esc_html__( 'Page 404', 'minfolio' ),
				),

				/**
				* Footer section
				*/
				array(
					'id'     => 'section-footer',
					'type'     => 'section',
					'priority' => 17,
					'title'    => esc_html__( 'Footer', 'minfolio' ),
				),				

			);

            return array_merge( $configurations, $configs );

        }


    }

}

new Minfolio_Customizer_Register_Sections_Panels();

