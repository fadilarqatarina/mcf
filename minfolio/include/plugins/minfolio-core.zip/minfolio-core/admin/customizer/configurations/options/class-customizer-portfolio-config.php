<?php
/**
 * Theme Customizer for Portfolio
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_Portfolio_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_Portfolio_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(	
				
				array(
                    'id'      => 'portfolio-settings-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section'   => 'section-portfolio-settings',
                    'label'     => esc_html__( 'Settings', 'minfolio' ),                    					
				),	

				array(
					'id'      => 'portfolio-nav-switch',
					'type'    => 'control',		
					'control' => 'clbr-toggle-switch',			
					'label'   => esc_html__( 'Navigation Bar', 'minfolio' ),					
					'description' => esc_html__( 'Activate to show the navigation bar in portfolio page.', 'minfolio' ),
					'section' => 'section-portfolio-settings',
					'default' => 1,
				),

				array(
					'id'      => 'portfolio-nav-type',
					'type'    => 'control',		
					'control' => 'select',		
					'choices' => [                       
									'' 	   => esc_html__( 'Default', 'minfolio' ),
									'loop' => esc_html__( 'Loop', 'minfolio' ),									
								],	
					'label'   => esc_html__( 'Navigation Type', 'minfolio' ),					
					'description' => esc_html__( 'Select the portfolio items navigation type.', 'minfolio' ),
					'section' => 'section-portfolio-settings',
					'default' => '',
				),

				array(
					'id'      => 'portfolio-nav-home',
					'type'    => 'control',		
					'control' => 'clbr-dropdown-post',			
					'label'   => esc_html__( 'Navigation Home', 'minfolio' ),					
					'description' => esc_html__( 'Specify the page you want to use as portfolio home.', 'minfolio' ),
					'section' => 'section-portfolio-settings',
					'input_attrs' => array(
										'post_type' => 'page',
										'posts_per_page' => -1,
										'orderby' => 'name',
										'order' => 'ASC',
									),
					'default' => '',
				),

				array(
					'id'      => 'portfolio-related-switch',
					'type'    => 'control',		
					'control' => 'clbr-toggle-switch',			
					'label'   => esc_html__( 'Related Portfolio', 'minfolio' ),					
					'description' => esc_html__( 'Activate to show the related portfolio items.', 'minfolio' ),
					'section' => 'section-portfolio-settings',
					'default' => 1,
				),

				array(
                    'id'      => 'portfolio-nav-order-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-settings',
					'label'   => esc_html__( 'Portfolio Navigation Order', 'minfolio' ),
				),

				array(	
                    'id'      => 'portfolio-order-by',					
                    'type'    => 'control',
					'control' => 'select',     				
					'section' => 'section-portfolio-settings',
					'label'   => esc_html__( 'Order By', 'minfolio' ),				
					'default' => 'date',
					'choices' => [                       
									'date' => esc_html__( 'Date', 'minfolio' ),
									'ID' => esc_html__( 'ID', 'minfolio' ),
									'title' => esc_html__( 'Title', 'minfolio' ),
									'modified' => esc_html__( 'Last Modified', 'minfolio' ),
									'rand' => esc_html__( 'Random',	 'minfolio' ),				
									'menu_order' => esc_html__( 'Custom Sort', 'minfolio' ),
								],
				),

				array(	
                    'id'      => 'portfolio-order-arrangement',					
                    'type'    => 'control',
					'control' => 'select',     				
					'section' => 'section-portfolio-settings',
					'label'   => esc_html__( 'Order Arrangement', 'minfolio' ),				
					'default' => 'ASC',
					'choices' => [                       
									'ASC' => esc_html__( 'Ascending', 'minfolio' ),
									'DESC' => esc_html__( 'Descending', 'minfolio' ),									
								],
				),

				array(
                    'id'      => 'portfolio-slug-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-settings',
					'label'   => esc_html__( 'Portfolio Slug', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-slug-name',					
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-portfolio-settings',
					'label'   => esc_html__( 'Portfolio Slug', 'minfolio' ),	
					'description' => esc_html__( 'The slug name cannot be the same name as a page name or the layout will break. This option changes the permalink when you use the permalink type as %postname%. Make sure to regenerate permalinks.', 'minfolio' ),
					'default'     => 'portfolio-item'   
				),

				array(
                    'id'      => 'portfolio-banner-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section'   => 'section-portfolio-archive',
                    'label'     => esc_html__( 'Archive Banner', 'minfolio' ),                    					
				),	
				
				array(
                    'id'      => 'portfolio-banner-title-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'												
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',     	
					'input_attrs' => array( 'placement' => 'bottom' ),						
                    'section' => 'section-portfolio-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Title Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-banner-title-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',    
					'input_attrs' => array( 'placement' => 'bottom' ),					    	             
                    'section' => 'section-portfolio-archive',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Title', 'minfolio' ),                    					
				),		

				array(
                    'id'      => 'portfolio-banner-desc-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',
									'value'    => '#151515'													
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'bottom' ),		  					
					'section' => 'section-portfolio-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Description Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-banner-desc-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',   
					'input_attrs' => array( 'placement' => 'bottom' ),					   
                    'section' => 'section-portfolio-archive',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Description', 'minfolio' ),                    					
				),			
				
				array(
                    'id'      => 'portfolio-archive-banner-bg-color',
					'default' => '#f9f9f9',
                    'type'    => 'control',
					'control' => 'clbr-color',     		
					'input_attrs' => array( 'placement' => 'bottom' ),						
					'section' => 'section-portfolio-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'BG color', 'minfolio' ),
					
				),

				array(
                    'id'      => 'portfolio-archive-banner-image',					
                    'type'    => 'control',
					'control' => 'image',     					
					'section' => 'section-portfolio-archive',
					'label'   => esc_html__( 'BG image', 'minfolio' ),	
 					'description' => esc_html__( 'Upload the banner image on blog home page, image size must be 1920x600 or above.', 'minfolio' ),					
				),

				array(
                    'id'      => 'portfolio-archive-banner-overlay-color',					
                    'type'    => 'control',
					'control' => 'clbr-gradient-color',    		
					'section' => 'section-portfolio-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Overlay color', 'minfolio' ),					
				),		
				
				array(
                    'id'      => 'portfolio-archive-banner-padding',
					'default' => json_encode(
										array(
											'desktop_top'    => 120,										
											'desktop_bottom' => 120,										
										)
									),				
                    'type'    => 'control',
					'control' => 'clbr-responsive-padding',    								
					'section' => 'section-portfolio-archive',				
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Padding', 'minfolio' ),	
				),			

				array(
                    'id'      => 'portfolio-single-hero-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Single Portfolio Hero', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-hero-slider-pag-color',
					'default' => '#333',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Pagination Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-hero-slider-pag-active-color',
					'default' => '#252525',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Pagination Active Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-media-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Single Portfolio Media', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-media-slider-pag-color',
					'default' => '#333',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Nav/Pagination Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-media-slider-pag-active-color',
					'default' => '#252525',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Pagination Active Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-meta-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Single Portfolio Meta', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-meta-title-color',
					'default' => '#252525',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Meta Title Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-meta-desc-color',
					'default' => '#656565',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Meta Desc Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-meta-desc-hover-color',
					'default' => '#252525',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Meta Desc Hover Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-related-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Single Portfolio Related', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-related-slider-pag-color',
					'default' => '#333',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Pagination Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-related-slider-pag-active-color',
					'default' => '#252525',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-portfolio-single',					
					'label'   => esc_html__( 'Pagination Active Color', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-single-label-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Single Portfolio Label', 'minfolio' ),
				),

				array(
                    'id'      => 'portfolio-next-text',					
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Next label', 'minfolio' ),	
					'description' => esc_html__( 'Enter a label for next button.', 'minfolio' ),
					'default'     => 'NEXT'   
				),

				array(
                    'id'      => 'portfolio-prev-text',					
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Previous label', 'minfolio' ),	
					'description' => esc_html__( 'Enter a label for prev button.', 'minfolio' ),
					'default'     => 'PREV'   
				),

				array(
                    'id'      => 'portfolio-single-sharing-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Single Portfolio Sharing', 'minfolio' ),
				),

				array(
					'id'      => 'portfolio-social-sharing',
					'type'    => 'control',		
					'control' => 'clbr-toggle-switch',			
					'label'   => esc_html__( 'Social Share Icons', 'minfolio' ),					
					'description' => esc_html__( 'You can show or hide the social sharing icons on your portfolio page.', 'minfolio' ),
					'section' => 'section-portfolio-single',
					'default' => 1,
				),

				array(
                    'id'      => 'portfolio-social-share-title',					
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Portfolio Share Label', 'minfolio' ),	
					'description' => esc_html__( 'Enter a label for portfolio share.', 'minfolio' ),
					'default'     => 'Share'   
				),

				array(	
                    'id'      => 'portfolio-share-icons',					
                    'type'    => 'control',
					'control' => 'clbr-sortable',     				
					'section' => 'section-portfolio-single',
					'label'   => esc_html__( 'Social Share Icons', 'minfolio' ),
					'input_attrs' => array(
										'sortable' => true,
										'fullwidth' => true,
									),
					'default' => 'fab fa-facebook-f,fab fa-twitter,fab fa-google-plus-g',
					'choices' => [                       
									'fab fa-facebook-f' => esc_html__( 'Facebook', 'minfolio' ),
									'fab fa-twitter' => esc_html__( 'Twitter', 'minfolio' ),
									'fab fa-google-plus-g' => esc_html__( 'Google+', 'minfolio' ),
									'fab fa-pinterest-p' => esc_html__( 'Pinterest', 'minfolio' ),
									'fab fa-linkedin-in' => esc_html__( 'Linkedin',	 'minfolio' ),				
									'fab fa-xing' => esc_html__( 'Xing', 'minfolio' ),
								],
				),				

				array(
                    'id'      => 'portfolio-hero-typo-title',
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-portfolio-typography',
                    'label'   => esc_html__( 'Portfolio Single Hero', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'portfolio-hero-title-color',
					'default' => [
									'local'    => 'rgba(255,255,255,0.7)',
									'global'   => 'transparent',	
									'value'    => 'rgba(255,255,255,0.7)'												
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Hero Title Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-hero-title-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',   
					'input_attrs' => array( 'placement' => 'bottom' ),				              
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Hero Title', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'portfolio-hero-desc-color',
					'default' => [
									'local'    => '#ffffff',
									'global'   => 'transparent',	
									'value'    => '#ffffff'												
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'bottom' ),		  					
					'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Hero Description Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-hero-desc-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography', 
					'input_attrs' => array( 'placement' => 'bottom' ),					              
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Hero Description', 'minfolio' ),                    					
				),				

				array(
                    'id'      => 'portfolio-single-typo-title',
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-portfolio-typography',
                    'label'   => esc_html__( 'Portfolio Single Post', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'portfolio-single-title-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'												
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Title Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-single-title-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography', 
					'input_attrs' => array( 'placement' => 'bottom' ),					                        
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Title', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'portfolio-single-subtitle-color',
					'default' => [
									'local'    => '#909090',
									'global'   => 'transparent',
									'value'    => '#909090'													
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Sub Title Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-single-subtitle-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',   
					'input_attrs' => array( 'placement' => 'bottom' ),			              
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Sub Title', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'portfolio-single-desc-color',
					'default' => [
									'local'    => '#606060',
									'global'   => 'transparent',		
									'value'    => '#606060'											
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',     
					'input_attrs' => array( 'placement' => 'bottom' ),							
					'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Description Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'portfolio-single-desc-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',  
					'input_attrs' => array( 'placement' => 'bottom' ),					 	                    
                    'section' => 'section-portfolio-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Description', 'minfolio' ),                    					
				),
			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_Portfolio_Configs();
