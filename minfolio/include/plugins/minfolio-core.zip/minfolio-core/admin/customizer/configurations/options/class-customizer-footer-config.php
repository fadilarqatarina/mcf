<?php
/**
 * Theme Customizer for Footer
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_Footer_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_Footer_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(

				array(
                    'id'      => 'footer-settings-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-footer',
                    'label'   => esc_html__( 'Footer Settings', 'minfolio' ),                   					
				),
			
				array(
					'id'      	  => 'footer-layout',
					'type'        => 'control',		
					'control'     => 'clbr-text-radio-button',			
					'label'       => esc_html__( 'Layout', 'minfolio' ),										
					'choices'     => [
										'boxed'   => esc_html__( 'Boxed', 'minfolio' ),
										'full-width' => esc_html__( 'Full Width', 'minfolio' ),            
									],   
					'section'     => 'section-footer',
					'default'     => 'boxed',
				),

				array(
					'id'      	  => 'footer-columns',
					'type'        => 'control',		
					'control'     => 'clbr-text-radio-button',			
					'label'       => esc_html__( 'Footer columns', 'minfolio' ),										
					'default'     => 'three-cols',      
					'choices'     => [
										'three-cols' => esc_html__( '3 Columns', 'minfolio' ),
										'four-cols'  => esc_html__( '4 Columns', 'minfolio' ),            
									],   
					'section'     => 'section-footer',					
				),

				array(
					'id'      	  => 'footer-scroll-top',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',			
					'label'       => esc_html__( 'Scroll Top', 'minfolio' ),
					'description' => esc_html__( 'You can activate/deactivate the scroll to top button.', 'minfolio' ),
					'section'     => 'section-footer',
					'default'     => 1,
				),


				array(
                    'id'      => 'footer-style-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-footer',
                    'label'     => esc_html__( 'Footer Style', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'footer-bg-color',
					'default' => '#1e1e1e',
                    'type'    => 'control',
					'control' => 'clbr-color', 
					'input_attrs' => array( 'placement' => 'bottom' ),			    					
                    'section' => 'section-footer',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Footer BG color', 'minfolio' ),
				),

				array(
                    'id'      => 'footer-border-color',
					'default' => 'rgba(255, 255, 255, 0.1)',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-footer',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Border Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'footer-data-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-footer',
                    'label'   => esc_html__( 'Footer Data', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'footer-author',					
                    'type'    => 'control',
					'control' => 'textarea',                   
                    'section' => 'section-footer',
					'label'   => esc_html__( 'Website author', 'minfolio' ),	   
					'default' => 'Designed by Caliberthemes.',       					
				),

				array(
                    'id'      => 'footer-copyright',					
                    'type'    => 'control',
					'control' => 'textarea',                   
                    'section' => 'section-footer',
					'label'   => esc_html__( 'Copyright', 'minfolio' ),		
					'default' => '© 2022 CaliberThemes',		
				),

				array(
                    'id'      => 'footer-typo-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-footer',
                    'label'   => esc_html__( 'Footer Widget Typography', 'minfolio' ),                    					
				),				

				array(
                    'id'      => 'footer-heading-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',  
					'input_attrs' => array( 'placement' => 'bottom' ),						      
                    'section' => 'section-footer',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Heading', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'footer-heading-color',
					'default' => [
									'local'    => '#ffffff',
									'global'   => 'transparent',	
									'value'    => '#ffffff'										
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',    
					'input_attrs' => array( 'placement' => 'top' ),		 					
                    'section' => 'section-footer',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Heading Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'footer-text-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',  
					'input_attrs' => array( 'placement' => 'bottom' ),					           	           
                    'section' => 'section-footer',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Text', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'footer-text-color',
					'default' => [
									'local'    => '#a0a0a0',
									'global'   => 'transparent',
									'value'    => '#a0a0a0'													
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',     	
					'input_attrs' => array( 'placement' => 'top' ),						
					'section' => 'section-footer',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Text Color', 'minfolio' ),	
				),
				
				array(
                    'id'      => 'footer-data-typo-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-footer',
                    'label'   => esc_html__( 'Footer Data Typography', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'footer-data-text-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',       
					'input_attrs' => array( 'placement' => 'bottom' ),					           	   
                    'section' => 'section-footer',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Text', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'footer-data-text-color',
					'default' => [
									'local'    => '#a0a0a0',
									'global'   => 'transparent',
									'value'    => '#a0a0a0'													
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'top' ),		  					
					'section' => 'section-footer',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Text Color', 'minfolio' ),	
				),			

			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_Footer_Configs();
