<?php
/**
 * Theme Customizer for Branding
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_Branding_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_Branding_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(	
							
				array(
                    'id'       => 'dark-logo-title',					
                    'type'     => 'control',
					'control'  => 'clbr-heading-title',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'Dark Logo', 'minfolio' ),                    					
				),

				array(
                    'id'       => 'menu-dark-logo',					
                    'type'     => 'control',
					'control'  => 'image',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'Logo', 'minfolio' ),                    					
					'default'  =>  MINFOLIO_CORE_URL . 'admin/assets/images/logo.png',
				),

				array(
                    'id'       => 'menu-dark-retina-logo',					
                    'type'     => 'control',
					'control'  => 'image',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'High-DPI (retina) logo', 'minfolio' ),	 					
					'default'  => MINFOLIO_CORE_URL . 'admin/assets/images/logo2x.png',
				),


				array(
                    'id'       => 'light-logo-title',					
                    'type'     => 'control',
					'control'  => 'clbr-heading-title',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'Light Logo', 'minfolio' ),                    					
				),

				array(
                    'id'       => 'menu-light-logo',					
                    'type'     => 'control',
					'control'  => 'image',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'Logo', 'minfolio' ),                    					
					'default'  =>  MINFOLIO_CORE_URL . 'admin/assets/images/light-logo.png',
				),

				array(
                    'id'       => 'menu-light-retina-logo',					
                    'type'     => 'control',
					'control'  => 'image',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'High-DPI (retina) logo', 'minfolio' ),	 					
					'default'  => MINFOLIO_CORE_URL . 'admin/assets/images/light-logo2x.png',
				),

				array(
                    'id'       => 'text-logo-title',					
                    'type'     => 'control',
					'control'  => 'clbr-heading-title',                    
                    'section'  => 'section-branding',
                    'label'    => esc_html__( 'Text Logo', 'minfolio' ),                    					
				),

				array(
					'id'      	  => 'menu-text-logo-switch',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',				
					'label'       => esc_html__( 'Enable Text Logo', 'minfolio' ),
					'section'     => 'section-branding',
					'default'     => 0,
				),

				array(
                    'id'       => 'menu-text-logo',					
                    'type'     => 'control',
					'control'  => 'text',                    
                    'section'  => 'section-branding',
					'label'    => esc_html__( 'Logo', 'minfolio' ),					
					'default'  => 'Minfolio',
				),	
				
				array(
                    'id'       => 'menu-text-logo-typo',					
                    'type'     => 'control',
					'control'  => 'clbr-typography',    
					'input_attrs' => array( 'placement' => 'top' ),					         
                    'section'  => 'section-branding',
					'transport' => 'postMessage',
					'label'    => esc_html__( 'Typography', 'minfolio' ),			
				),	
				
				array(
                    'id'      => 'menu-text-logo-dark-color',
					'default' => [
									'local'    => '#000000',
									'global'   => 'transparent',
									'value'    => '#000000'									
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors', 
					'input_attrs' => array( 'placement' => 'top' ),		    					
                    'section' => 'section-branding',
					'transport' => 'postMessage',
					'label'    => esc_html__( 'Dark Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'menu-text-logo-light-color',
					'default' => [
									'local'    => '#ffffff',
									'global'   => 'transparent',	
									'value'    => '#ffffff'								
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'top' ),		   					
                    'section' => 'section-branding',
					'transport' => 'postMessage',
					'label'    => esc_html__( 'Light Color', 'minfolio' ),	
				),

			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_Branding_Configs();
