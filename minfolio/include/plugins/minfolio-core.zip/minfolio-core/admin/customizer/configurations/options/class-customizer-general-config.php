<?php
/**
 * Theme Customizer for General
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_General_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_General_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(

				array(
                    'id'      => 'lazy-load-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',
                    'section'   => 'section-general',
                    'label'     => esc_html__( 'Lazy Load', 'minfolio' ),                    					
				),	
				
				array(
					'id'      	  => 'lazy-load-switch',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',			
					'label'       => esc_html__( 'Lazy load', 'minfolio' ),
					'description' => esc_html__( 'You can activate/deactivate the lazy load for images in portfolio section, listing, details.', 'minfolio' ),
					'section'     => 'section-general',
					'default'     => 1,
				),

				array(
                    'id'      => 'minify-js-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-general',
                    'label'     => esc_html__( 'Javascript', 'minfolio' ),                    					
				),
				
				array(
					'id'      	  => 'minify-js-switch',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',								
    				'label'       => esc_html__( 'Minify javascript', 'minfolio' ),
    				'description' => esc_html__( 'You can minify the javascript in a single minified file.', 'minfolio' ),
					'section'     => 'section-general',
					'default'     => 1,
				),

				array(
                    'id'      => 'elementor-global-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-general',
                    'label'     => esc_html__( 'Global Fonts and Colors', 'minfolio' ),                    					
				),
				
				array(
					'id'      	  => 'elementor-global-switch',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',								
    				'label'       => esc_html__( 'Use Elementor Global Fonts and Colors for theme', 'minfolio' ),
    				'description' => esc_html__( 'Elementor Global Fonts and Colors will be applied for blog and portfolio.', 'minfolio' ),
					'section'     => 'section-general',
					'default'     => 0,
				),

				array(
                    'id'      => 'multilingual-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-general',
                    'label'     => esc_html__( 'Multilingual', 'minfolio' ),                    					
				),
				
				array(
					'id'      	  => 'multilingual-switch',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',													
					'label'       => esc_html__( 'Use theme as multilingual', 'minfolio' ),
					'description' => esc_html__( 'Activate to use theme as multilingual.', 'minfolio' ),
					'section'     => 'section-general',
					'default'     => 0,
				),

				array(
                    'id'      => 'google-map-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section'   => 'section-general',
                    'label'     => esc_html__( 'Google Map', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'google-map-api-key',
					'default' => '',
                    'type'    => 'control',
					'control' => 'text',                    
                    'section'   => 'section-general',
                    'label'     => esc_html__( 'API Key', 'minfolio' ),                    					
				),

				array(
					'id'      	  => 'color-notice',
					'type'        => 'control',		
					'control'     => 'clbr-simple-notice',			
					'label'       => esc_html__( 'To set the colors please follow the instructions given below.', 'minfolio' ),
					'description' => '1. Edit the page using the Elementor.<br> 2. Click on the Hamburger on top left corner.<br> 3. Go to Site Settings.<br> 4. Go to Global Color.',
					'section'     => 'section-colors',	
					'sanitize_callback' => 'esc_html',				
				),

			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_General_Configs();
