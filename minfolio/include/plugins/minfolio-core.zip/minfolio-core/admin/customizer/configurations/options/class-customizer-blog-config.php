<?php
/**
 * Theme Customizer for Blog
 */

// No direct access, please.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Customizer Sanitizes 
 */

if ( ! class_exists( 'Minfolio_Customizer_Blog_Configs' ) ) {

	/**
	 * Register General Customizer Configurations.
	 */
	class Minfolio_Customizer_Blog_Configs extends Minfolio_Customizer_Config_Base {

		/**
		 * Register General Customizer Configurations.	
		 */
		public function register_configuration( $configurations, $wp_customize ) {

			$_configs = array(				

				array(
                    'id'      => 'blog-banner-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section'   => 'section-blog-archive',
                    'label'     => esc_html__( 'Blog Banner', 'minfolio' ),                    					
				),
				
				array(
                    'id'      => 'blog-banner-upper-heading',				
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-blog-archive',
                    'label'   => esc_html__( 'Upper Heading', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-banner-upper-heading-color',					
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors', 
					'input_attrs' => array( 'placement' => 'bottom' ),		    					
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'blog-banner-upper-heading-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',     
					'input_attrs' => array( 'placement' => 'bottom' ),				
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Typography', 'minfolio' ),                    					
				),
				
				array(
                    'id'      => 'blog-banner-heading',
					'default' => 'Blog',
                    'type'    => 'control',
					'control' => 'textarea',                  
                    'section'   => 'section-blog-archive',
                    'label'     => esc_html__( 'Heading', 'minfolio' ),     										
				),	

				array(
                    'id'      => 'blog-banner-heading-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
					'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Color', 'minfolio' ),	
				),
				
				array(
                    'id'      => 'blog-banner-heading-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography', 
					'input_attrs' => array( 'placement' => 'bottom' ),	  
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Typography', 'minfolio' ),                    					
				),				

				array(
                    'id'      => 'blog-banner-bg-color',
					'default' => '#f9f9f9',
                    'type'    => 'control',
					'control' => 'clbr-color',     
					'input_attrs' => array( 'placement' => 'bottom' ),					
					'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'BG color', 'minfolio' ),
					
				),

				array(
                    'id'      => 'blog-banner-bg-image',					
                    'type'    => 'control',
					'control' => 'image',     					
					'section' => 'section-blog-archive',
					'label'   => esc_html__( 'BG image', 'minfolio' ),	
 					'description' => esc_html__( 'Upload the banner image on blog home page, image size must be 1920x600 or above.', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-banner-bg-color-overlay',				
                    'type'    => 'control',
					'control' => 'clbr-gradient-color',    		
					'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Overlay color', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-banner-padding',
					'default' => json_encode(
									array(
										'desktop_top'    => 120,										
										'desktop_bottom' => 120,										
									)
								),			
                    'type'    => 'control',
					'control' => 'clbr-responsive-padding',    							
					'section' => 'section-blog-archive',					
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Padding', 'minfolio' ),	
				),			
				
				array(
                    'id'      => 'blog-archive-banner-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-blog-archive',
                    'label'   => esc_html__( 'Archive Banner', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-archive-banner-heading-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'			
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'bottom' ),		  					
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Heading Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'blog-archive-banner-heading-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',    
					'input_attrs' => array( 'placement' => 'bottom' ),		 					               
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Heading Typography', 'minfolio' ),                    					
				),				

				array(
                    'id'      => 'blog-archive-banner-desc-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'							
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'bottom' ),		  					
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Description Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'blog-archive-banner-desc-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',     
					'input_attrs' => array( 'placement' => 'bottom' ),						            
                    'section' => 'section-blog-archive',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Description Typography', 'minfolio' ),                    					
				),				

				array(
                    'id'      => 'blog-archive-banner-bg-color',
					'default' => '#f9f9f9',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'bottom' ),			 					
					'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'BG color', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-archive-banner-image',					
                    'type'    => 'control',
					'control' => 'image',     					
					'section' => 'section-blog-archive',
					'label'   => esc_html__( 'BG image', 'minfolio' ),	
 					'description' => esc_html__( 'Upload the banner image on blog archive page, image size must be 1920x600 or above.', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-archive-banner-overlay-color',					
                    'type'    => 'control',
					'control' => 'clbr-gradient-color',    		
					'section' => 'section-blog-archive',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Overlay color', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-archive-banner-padding',
					'default' => json_encode(
									array(
										'desktop_top'    => 120,										
										'desktop_bottom' => 120,										
									)
								),			
                    'type'    => 'control',
					'control' => 'clbr-responsive-padding',    							
					'section' => 'section-blog-archive',			
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Padding', 'minfolio' ),	
				),			

				array(
                    'id'      => 'blog-label-title',							
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-blog-archive',
                    'label'   => esc_html__( 'Blog Label', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-readmore-text',										
                    'type'    => 'control',
					'control' => 'text',        
					'default' => 'Read More',			            
                    'section' => 'section-blog-archive',
                    'label'   => esc_html__( 'Read more label', 'minfolio' ),	
    				'description' => esc_html__( 'Enter a label for read more button.', 'minfolio' ),
				),				

				array(
                    'id'      => 'blog-post-slider-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-blog-archive',
					'label'   => esc_html__( 'Blog Post Slider', 'minfolio' ),
				),

				array(
					'id'      	  => 'blog-post-slider-navigation',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',			
					'label'       => esc_html__( 'Slider Navigation', 'minfolio' ),
					'description' => esc_html__( 'Show / Hide post silder navigation.', 'minfolio' ),
					'section' 	  => 'section-blog-archive',
					'default'     => 1,
				),

				array(
					'id'      	  => 'blog-post-slider-pagination',
					'type'        => 'control',		
					'control'     => 'clbr-toggle-switch',			
					'label'       => esc_html__( 'Slider Pagination', 'minfolio' ),
					'description' => esc_html__( 'Show / Hide post silder pagination.', 'minfolio' ),
					'section'	  => 'section-blog-archive',
					'default'     => 0,
				),

				array(
                    'id'      => 'blog-post-slider-pag-color',
					'default' => '#333',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'top' ),			 					
					'section' => 'section-blog-archive',					
					'label'   => esc_html__( 'Color', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-post-slider-pag-active-color',
					'default' => '#252525',
                    'type'    => 'control',
					'control' => 'clbr-color',    
					'input_attrs' => array( 'placement' => 'top' ),			 					
					'section' => 'section-blog-archive',					
					'label'   => esc_html__( 'Active Color', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-single-banner-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-blog-single',
					'label'   => esc_html__( 'Single Post Banner', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-post-banner-upper-heading',				
                    'type'    => 'control',
					'control' => 'text',                    
					'section' => 'section-blog-single',
                    'label'     => esc_html__( 'Upper Heading', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-post-banner-upper-heading-color',					
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors', 
					'input_attrs' => array( 'placement' => 'bottom' ),		    					
					'section' => 'section-blog-single',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'blog-post-banner-upper-heading-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',   
					'input_attrs' => array( 'placement' => 'bottom' ),					  	                 
                    'section' => 'section-blog-single',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Typography', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-post-banner-title-color',					
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',	
									'value'    => '#151515'
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors', 
					'input_attrs' => array( 'placement' => 'bottom' ),		    					
					'section' => 'section-blog-single',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Post Title Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'blog-post-banner-title-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',  
					'input_attrs' => array( 'placement' => 'bottom' ),					                
                    'section' => 'section-blog-single',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Post Title Typography', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-post-banner-bg-color',
					'default' => '#f9f9f9',
                    'type'    => 'control',
					'control' => 'clbr-color',     
					'input_attrs' => array( 'placement' => 'bottom' ),					
					'section' => 'section-blog-single',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'BG color', 'minfolio' ),
					
				),

				array(
                    'id'      => 'blog-post-banner-use-featured-image',					
                    'type'    => 'control',
					'control' => 'checkbox',     					
					'section' => 'section-blog-single',
					'label'   => esc_html__( 'Use Post Featured Image on Banner', 'minfolio' ),	
 					'description' => esc_html__( 'Check to use blog post featured image as banner background image.', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-post-banner-bg-image',					
                    'type'    => 'control',
					'control' => 'image',     					
					'section' => 'section-blog-single',
					'label'   => esc_html__( 'BG image', 'minfolio' ),	
 					'description' => esc_html__( 'Upload the banner image on blog single post page, image size must be 1920x600 or above.', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-post-banner-bg-color-overlay',				
                    'type'    => 'control',
					'control' => 'clbr-gradient-color',    		
				    'section' => 'section-blog-single',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Overlay color', 'minfolio' ),					
				),

				array(
                    'id'      => 'blog-post-banner-padding',
					'default' => json_encode(
									array(
										'desktop_top'    => 120,										
										'desktop_bottom' => 120,										
									)
								),				
                    'type'    => 'control',
					'control' => 'clbr-responsive-padding',    							
					'section' => 'section-blog-single',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Padding', 'minfolio' ),	
				),		

				array(
                    'id'      => 'blog-single-label-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-blog-single',
					'label'   => esc_html__( 'Single Post Label', 'minfolio' ),
				),

				array(
                    'id'      => 'blog-next-text',					
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-blog-single',
					'label'   => esc_html__( 'Next post label', 'minfolio' ),	
					'description' => esc_html__( 'Enter a label for next button.', 'minfolio' ),
					'default'     => 'Next Post'   
				),

				array(
                    'id'      => 'blog-prev-text',					
                    'type'    => 'control',
					'control' => 'text',                    
                    'section' => 'section-blog-single',
					'label'   => esc_html__( 'Previous post label', 'minfolio' ),	
					'description' => esc_html__( 'Enter a label for prev button.', 'minfolio' ),
					'default'     => 'Prev Post'   
				),

				array(
                    'id'      => 'blog-single-sharing-title',					
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                    
                    'section' => 'section-blog-single',
					'label'   => esc_html__( 'Single Post Sharing', 'minfolio' ),
				),

				array(	
                    'id'      => 'blog-share-icons',					
                    'type'    => 'control',
					'control' => 'clbr-sortable',     				
					'section' => 'section-blog-single',
					'label'   => esc_html__( 'Social Share Icons', 'minfolio' ),
					'input_attrs' => array(
										'sortable' => true,
										'fullwidth' => true,
									),
					'default' => 'fab fa-facebook-f,fab fa-twitter,fab fa-google-plus-g',
					'choices' => [                       
									'fab fa-facebook-f' => esc_html__( 'Facebook', 'minfolio' ),
									'fab fa-twitter' => esc_html__( 'Twitter', 'minfolio' ),
									'fab fa-google-plus-g' => esc_html__( 'Google+', 'minfolio' ),
									'fab fa-pinterest-p' => esc_html__( 'Pinterest', 'minfolio' ),
									'fab fa-linkedin-in' => esc_html__( 'Linkedin',	 'minfolio' ),				
									'fab fa-xing' => esc_html__( 'Xing', 'minfolio' ),
								],
				),			
				
				array(
                    'id'      => 'blog-post-typo-title',
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-blog-typography',
                    'label'   => esc_html__( 'Blog Post', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-post-title-color',
					'default' => [
									'local'    => '#151515',
									'global'   => 'transparent',
									'value'    => '#151515'									
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Post Title Color', 'minfolio' ),	
				),	

				array(
                    'id'      => 'blog-post-title-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',    
					'input_attrs' => array( 'placement' => 'bottom' ),						          	              
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Post Title', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-post-meta-color',
					'default' => [
									'local'    => '#909090',
									'global'   => 'transparent',	
									'value'    => '#909090'								
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'bottom' ),		  					
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Post Meta Color', 'minfolio' ),	
				),	

				array(
                    'id'      => 'blog-post-meta-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography', 
					'input_attrs' => array( 'placement' => 'bottom' ),				
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Post Meta', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-post-content-color',
					'default' => [
									'local'    => '#606060',
									'global'   => 'transparent',
									'value'    => '#606060'									
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Post Content Color', 'minfolio' ),	
				),			
				
				array(
                    'id'      => 'blog-post-content-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',       
					'input_attrs' => array( 'placement' => 'bottom' ),					    
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Post Content', 'minfolio' ),                    					
				),							
				
				
				array(
                    'id'      => 'blog-single-post-typo-title',
                    'type'    => 'control',
					'control' => 'clbr-heading-title',                   
                    'section' => 'section-blog-typography',
                    'label'   => esc_html__( 'Blog Single Post', 'minfolio' ),                    					
				),								
				
				array(
                    'id'      => 'blog-single-post-meta-color',
					'default' => [
									'local'    => '#909090',
									'global'   => 'transparent',
									'value'    => '#909090'									
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',  
					'input_attrs' => array( 'placement' => 'bottom' ),		   					
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Single Post Meta Color', 'minfolio' ),	
				),

				array(
                    'id'      => 'blog-single-post-meta-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography',   
					'input_attrs' => array( 'placement' => 'bottom' ),					  
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Single Post Meta', 'minfolio' ),                    					
				),

				array(
                    'id'      => 'blog-single-post-content-color',
					'default' => [
									'local'    => '#606060',
									'global'   => 'transparent',		
									'value'    => '#606060'							
								],
                    'type'    => 'control',
					'control' => 'clbr-global-colors',   
					'input_attrs' => array( 'placement' => 'bottom' ),		  					
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
					'label'   => esc_html__( 'Single Post Content Color', 'minfolio' ),	
				),			

				array(
                    'id'      => 'blog-single-post-content-typo',					
                    'type'    => 'control',
					'control' => 'clbr-typography', 
					'input_attrs' => array( 'placement' => 'bottom' ),						
                    'section' => 'section-blog-typography',
					'transport' => 'postMessage',
                    'label'   => esc_html__( 'Single Post Content', 'minfolio' ),                    					
				),				
			
			);		

			return array_merge( $configurations, $_configs );

		}
	}
}

new Minfolio_Customizer_Blog_Configs();
