<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! class_exists( 'Minfolio_Customizer_Config_Base' ) ) {

	class Minfolio_Customizer_Config_Base {

       	/**
		* Constructor
		*/
		public function __construct() {
			add_filter( 'minfolio_customizer_configurations', array( $this, 'register_configuration' ), 30, 2 );
		}
        

        public function register_configuration( $configurations, $wp_customize ) {
			return $configurations;
		}


    }

}

new Minfolio_Customizer_Config_Base();