<?php
/**
 * Social Links Widget
 */

if ( ! class_exists( 'Minfolio_Social_Links_Widget' ) ) {

	class Minfolio_Social_Links_Widget extends WP_Widget {
		
		/**
		 * Register widget with WordPress.		
		 */
		public function __construct() {
			
			$widget_ops = array( 
							'classname'   => 'widget-social-links', 
				            'description' => esc_html__( 'Use this widget to add social links.', 'minfolio' ) 
							);
			
			parent::__construct(
				'minfolio_social_links',
				esc_html__( 'Minfolio - Social Links', 'minfolio' ),
				$widget_ops
			);
			
		}

		
		/**
		 * Front-end display of widget.		 		
		 */
		public function widget( $args, $instance ) {

			// Widget options
			$title       = isset( $instance['title'] ) ? apply_filters( 'widget_title', $instance['title'] ) : '';		
			$icon_1 	 = isset( $instance['icon_1'] ) ? $instance['icon_1'] : '';				
			$link_1      = isset( $instance['link_1'] ) ? $instance['link_1'] : '';	
			$icon_2 	 = isset( $instance['icon_2'] ) ? $instance['icon_2'] : '';				
			$link_2      = isset( $instance['link_2'] ) ? $instance['link_2'] : '';	
			$icon_3 	 = isset( $instance['icon_3'] ) ? $instance['icon_3'] : '';				
			$link_3      = isset( $instance['link_3'] ) ? $instance['link_3'] : '';	
			$icon_4 	 = isset( $instance['icon_4'] ) ? $instance['icon_4'] : '';				
			$link_4      = isset( $instance['link_4'] ) ? $instance['link_4'] : '';	
			$icon_5 	 = isset( $instance['icon_5'] ) ? $instance['icon_5'] : '';				
			$link_5      = isset( $instance['link_5'] ) ? $instance['link_5'] : '';	

			// Before widget hook
			echo $args['before_widget']; ?>
										
			<?php
			
			// Display widget title
			if ( $title ) {
				echo $args['before_title'] . esc_html( $title ) . $args['after_title'];
			} ?>

			<nav class="footer-socials" role="navigation" aria-label="<?php echo esc_attr__( 'Footer Social Links Menu', 'minfolio' ); ?>" >
			
				<ul id="social-media-footer" class="social-links-menu">				 
			
					<?php if( $icon_1 ) { ?>
						<li>	
							<a href="<?php echo esc_url( $link_1 ); ?>" >						
								<i class="<?php echo esc_attr( $icon_1 ); ?>"></i>
							</a>					
						</li>	
					<?php } ?>

					<?php if( $icon_2 ) { ?>
						<li>	
							<a href="<?php echo esc_url( $link_2 ); ?>" >						
								<i class="<?php echo esc_attr( $icon_2 ); ?>"></i>
							</a>					
						</li>	
					<?php } ?>

					<?php if( $icon_3 ) { ?>
						<li>	
							<a href="<?php echo esc_url( $link_3 ); ?>" >						
								<i class="<?php echo esc_attr( $icon_3 ); ?>"></i>
							</a>					
						</li>	
					<?php } ?>

					<?php if( $icon_4 ) { ?>
						<li>	
							<a href="<?php echo esc_url( $link_4 ); ?>" >						
								<i class="<?php echo esc_attr( $icon_4 ); ?>"></i>
							</a>					
						</li>	
					<?php } ?>

					<?php if( $icon_5 ) { ?>
						<li>	
							<a href="<?php echo esc_url( $link_5 ); ?>" >						
								<i class="<?php echo esc_attr( $icon_5 ); ?>"></i>
							</a>					
						</li>	
					<?php } ?>
				
				</ul>
				
			</nav>

			<?php
			// After widget hook
			echo $args['after_widget'];
		}

		/**
		 * Sanitize widget form values as they are saved.		
		 */
		public function update( $new_instance, $old_instance ) {
			
			$instance                = $old_instance;
			$instance['title']       = strip_tags( $new_instance['title'] );		
			$instance['icon_1']      = strip_tags( $new_instance['icon_1'] );		
			$instance['link_1']      = strip_tags( $new_instance['link_1'] );		
			$instance['icon_2']      = strip_tags( $new_instance['icon_2'] );		
			$instance['link_2']      = strip_tags( $new_instance['link_2'] );		
			$instance['icon_3']      = strip_tags( $new_instance['icon_3'] );		
			$instance['link_3']      = strip_tags( $new_instance['link_3'] );		
			$instance['icon_4']      = strip_tags( $new_instance['icon_4'] );		
			$instance['link_4']      = strip_tags( $new_instance['link_4'] );		
			$instance['icon_5']      = strip_tags( $new_instance['icon_5'] );		
			$instance['link_5']      = strip_tags( $new_instance['link_5'] );		
			
			return $instance;
		}

		/**
		 * Back-end widget form.
		 *		
		 */
		public function form( $instance ) {
			$instance = wp_parse_args( ( array ) $instance, array(
				'title'     => esc_html__( 'Socials', 'minfolio' ),
				'icon_1' 	=> '',		
				'link_1'    => '',
				'icon_2' 	=> '',		
				'link_2'    => '',
				'icon_3' 	=> '',		
				'link_3'    => '',
				'icon_4' 	=> '',		
				'link_4'    => '',
				'icon_5' 	=> '',		
				'link_5'    => '',
			) );

			$social_icons = minfolio_get_social_icons();
			
			extract( $instance ); ?>
			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'minfolio' ); ?>:</label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
			</p>

			<p>  
				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_1' ) ); ?>"><?php esc_html_e( 'Icon 1', 'minfolio' ); ?>:</label> 
               
				<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_1' ) ); ?>" >
                    
					<?php foreach ( $social_icons as $icon => $name ) { ?>
						<option <?php selected( $icon_1, $icon ); ?> value="<?php echo esc_attr( $icon ); ?>"><?php echo esc_html( $name ); ?></option>
					<?php } ?>
				                  
                </select>                            
            </p>	
			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'link_1' ) ); ?>"><?php esc_html_e( 'Link 1', 'minfolio' ); ?>:</label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_1' ) ); ?>" type="text" value="<?php echo esc_attr( $link_1 ); ?>" />
			</p>		
			
			<p>  
				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_2' ) ); ?>"><?php esc_html_e( 'Icon 2', 'minfolio' ); ?>:</label> 
               
				<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_2' ) ); ?>" >
                    
					<?php foreach ( $social_icons as $icon => $name ) { ?>
						<option <?php selected( $icon_2, $icon ); ?> value="<?php echo esc_attr( $icon ); ?>"><?php echo esc_html( $name ); ?></option>
					<?php } ?>
				                  
                </select>                            
            </p>	
			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'link_2' ) ); ?>"><?php esc_html_e( 'Link 2', 'minfolio' ); ?>:</label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_2' ) ); ?>" type="text" value="<?php echo esc_attr( $link_2 ); ?>" />
			</p>			
			
			<p>  
				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_3' ) ); ?>"><?php esc_html_e( 'Icon 3', 'minfolio' ); ?>:</label> 
               
				<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_3' ) ); ?>" >
                    
					<?php foreach ( $social_icons as $icon => $name ) { ?>
						<option <?php selected( $icon_3, $icon ); ?> value="<?php echo esc_attr( $icon ); ?>"><?php echo esc_html( $name ); ?></option>
					<?php } ?>
				                  
                </select>                            
            </p>	
			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'link_3' ) ); ?>"><?php esc_html_e( 'Link 3', 'minfolio' ); ?>:</label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_3' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_3' ) ); ?>" type="text" value="<?php echo esc_attr( $link_3 ); ?>" />
			</p>	
			
			<p>  
				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_4' ) ); ?>"><?php esc_html_e( 'Icon 4', 'minfolio' ); ?>:</label> 
               
				<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_4' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_4' ) ); ?>" >
                    
					<?php foreach ( $social_icons as $icon => $name ) { ?>
						<option <?php selected( $icon_4, $icon ); ?> value="<?php echo esc_attr( $icon ); ?>"><?php echo esc_html( $name ); ?></option>
					<?php } ?>
				                  
                </select>                            
            </p>	
			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'link_4' ) ); ?>"><?php esc_html_e( 'Link 4', 'minfolio' ); ?>:</label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_4' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_4' ) ); ?>" type="text" value="<?php echo esc_attr( $link_4 ); ?>" />
			</p>			

			<p>  
				<label for="<?php echo esc_attr( $this->get_field_id( 'icon_5' ) ); ?>"><?php esc_html_e( 'Icon 5', 'minfolio' ); ?>:</label> 
               
				<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_5' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_5' ) ); ?>" >
                    
					<?php foreach ( $social_icons as $icon => $name ) { ?>
						<option <?php selected( $icon_5, $icon ); ?> value="<?php echo esc_attr( $icon ); ?>"><?php echo esc_html( $name ); ?></option>
					<?php } ?>
				                  
                </select>                            
            </p>	
			
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'link_5' ) ); ?>"><?php esc_html_e( 'Link 5', 'minfolio' ); ?>:</label> 
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_5' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_5' ) ); ?>" type="text" value="<?php echo esc_attr( $link_5 ); ?>" />
			</p>			

			<?php
		}
	}
}

// Register the widget
if ( ! function_exists( 'minfolio_register_social_links_widget' ) ) {
	function minfolio_register_social_links_widget() {
		register_widget( 'Minfolio_Social_links_Widget' );
	}
}

add_action( 'widgets_init', 'minfolio_register_social_links_widget' );