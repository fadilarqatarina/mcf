<?php
/** 
 * Plugin Name: Minfolio Core
 * Plugin URI: https://minfolio2.caliberthemes.com
 * Description: Core Plugin for Minfolio Theme
 * Version: 1.0.6
 * Tested up to: 6.3
 * Requires PHP: 7.4+
 * Author: CaliberThemes
 * Author URI: http://themeforest.net/user/caliberthemes
 * License: custom
 * License URI: http://themeforest.net/licenses
 * Text Domain: minfolio  
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MINFOLIO_CORE_VERSION', '1.0.6' );


if ( ! defined( 'MINFOLIO_CORE_PATH' ) ) {
	define( 'MINFOLIO_CORE_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'MINFOLIO_CORE_URL' ) ) {
	define( 'MINFOLIO_CORE_URL', plugin_dir_url( __FILE__ ) );
}


/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require_once( MINFOLIO_CORE_PATH . 'includes/class-minfolio-core.php' );

add_action( 'plugins_loaded', array( 'Minfolio_Core', 'get_instance' ) );





