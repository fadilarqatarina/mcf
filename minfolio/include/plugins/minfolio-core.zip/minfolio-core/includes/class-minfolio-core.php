<?php
/**
 * Main plugin class file.
 * 
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin class.
 */

if ( ! class_exists( 'Minfolio_Core' ) ) {	

	class Minfolio_Core {

		/**
		 * The single instance of Minfolio_Core.	
		 */
		private static $_instance = null;

		/**
		 * Constructor function.
		 *
		 */
		public function __construct() {

			// Handle localisation.		
			add_action( 'init', array( $this, 'load_plugin_textdomain' ), 0 );

			// Load dependencies			
			$this -> load_dependencies();
			
			// Load admin JS & CSS.
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 10, 1 );	
			
			add_action( 'wp_enqueue_scripts', array( $this, 'front_enqueue_scripts' ) );		
			
			add_filter( 'body_class', array( $this, 'add_body_classes' ) );

		} // End __construct ()
		
		
		/**
		 * Load plugin textdomain	
		 */
		public function load_plugin_textdomain() {

			load_plugin_textdomain( 'minfolio', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

		} // End load_plugin_textdomain ()



		/**
		 * Load dependencies of plugin
		 *
		 */
		public function load_dependencies() {

			require_once( MINFOLIO_CORE_PATH . 'includes/functions/helper-functions.php' );
			
			$this -> register_custom_post_types();						
			$this -> register_meta_boxes();			
			
			require_once( MINFOLIO_CORE_PATH . 'admin/load.php' );
			require_once( MINFOLIO_CORE_PATH . 'public/load.php' );

		}		

		/**
		* Include Meta Box for theme metaboxes
		*/
		private function register_meta_boxes() {

			if( ! defined( 'MINFOLIO_META_PREFIX' )) {
				define( 'MINFOLIO_META_PREFIX', 'clbr_meta_' );
			}

			require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/meta-box.php' );				

			if( is_admin() ) {		

				require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/extension/meta-box-conditional-logic/meta-box-conditional-logic.php' );
				require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/extension/meta-box-group/meta-box-group.php' );
				require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/extension/meta-box-show-hide/meta-box-show-hide.php' );
				require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/extension/meta-box-tabs/meta-box-tabs.php' );
				require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/extension/meta-box-columns/meta-box-columns.php' );				
				require_once( MINFOLIO_CORE_PATH . 'includes/vendor/meta-box/extension/meta-box-term-meta/mb-term-meta.php' );				
			}

		}

		
		/**
		* Include custom post types
		*/
		private function register_custom_post_types() {			

			require_once( MINFOLIO_CORE_PATH . 'includes/lib/class-custom-post-type.php');		

		}			

		/**
		 * Load admin Style & Javascript.	 	
		 */
		public function admin_enqueue_scripts() {

			wp_enqueue_style( 'minfolio-admin', MINFOLIO_CORE_URL . 'admin/assets/css/admin.min.css', array(), MINFOLIO_CORE_VERSION );				
									
		} // End admin_enqueue_scripts ()

		
		public function front_enqueue_scripts() {
			
			$suffix = '';

			$minify_js_switch  = minfolio_get_core_option( 'minify-js-switch' );
			$api_key 		   = minfolio_get_core_option( 'google-map-api-key' );
			
			if( $minify_js_switch == 1 ) {
				$suffix = '.min';
			}

			wp_enqueue_style( 'cubeportfolio', MINFOLIO_CORE_URL . 'public/assets/js/vendor/cubeportfolio/css/cubeportfolio.min.css', array(), MINFOLIO_CORE_VERSION ); 
			wp_enqueue_style( 'cocoen', MINFOLIO_CORE_URL . 'public/assets/js/vendor/cocoen/css/cocoen.min.css', array(), MINFOLIO_CORE_VERSION );       
			wp_enqueue_style( 'magnific-popup', MINFOLIO_CORE_URL . 'public/assets/js/vendor/magnific-popup/magnific-popup.css', array(), MINFOLIO_CORE_VERSION );
			wp_enqueue_style( 'flickity', MINFOLIO_CORE_URL . 'public/assets/js/vendor/flickity/flickity.min.css', array(), MINFOLIO_CORE_VERSION );
			wp_enqueue_style( 'flickity-fade', MINFOLIO_CORE_URL . 'public/assets/js/vendor/flickity/flickity-fade.css', array(), MINFOLIO_CORE_VERSION );
			
			wp_enqueue_style( 'minfolio-core-style', MINFOLIO_CORE_URL . 'public/assets/css/core-style.min.css', array(), MINFOLIO_CORE_VERSION );

			wp_register_script( 'google-map-api', 'https://maps.googleapis.com/maps/api/js?key=' . $api_key, array( 'jquery') , false, true );
			wp_register_script( 'gmaps',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/gmaps.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'magnific-popup',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/magnific-popup/jquery.magnific-popup.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'flickity',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/flickity/flickity.pkgd.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'flickity-fade',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/flickity/flickity-fade.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'cubeportfolio',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/cubeportfolio/js/jquery.cubeportfolio.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'jarallax',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/jarallax.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'jarallax-video',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/jarallax-video.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'jquery-sticky-kit',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/jquery.sticky-kit.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	
			wp_register_script( 'cocoen',  MINFOLIO_CORE_URL . 'public/assets/js/vendor/cocoen/js/cocoen.min.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );	

			wp_register_script( 'minfolio-social-share',  MINFOLIO_CORE_URL . 'public/assets/js/social-share' . $suffix . '.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );				
			wp_register_script( 'minfolio-blog-script', MINFOLIO_CORE_URL . 'public/assets/js/blog-script' . $suffix . '.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );				
			wp_register_script( 'minfolio-portfolio-script', MINFOLIO_CORE_URL . 'public/assets/js/portfolio-script' . $suffix . '.js', array( 'jquery' ), MINFOLIO_CORE_VERSION, true );							
			wp_register_script( 'minfolio-frontend', MINFOLIO_CORE_URL . 'public/assets/js/frontend-script' . $suffix . '.js', array( 'jquery', 'elementor-frontend' ), MINFOLIO_CORE_VERSION, true );				
						
			wp_localize_script( 'minfolio-portfolio-script', 'minfolioVar', [
			 	'homeUrl' => home_url()
			] );
			
		}

		public function add_body_classes( $classes ) {

			$classes[] = 'minfolio-core-active';		

			return $classes;

		}
		
		/**
		 * Main Minfolio_Core Instance
		 *
		 * Ensures only one instance of Minfolio_Core is loaded or can be loaded.	  	
		 */
		public static function get_instance() {

			if ( is_null( self::$_instance ) ) {		

				try {
					self::$_instance = new self;
				} catch ( Exception $err ) {
					do_action( 'minfolio_initialize_failed', $err );
					if ( WP_DEBUG ) {
						throw $err->getMessage();
					}
				}
			}

			return self::$_instance;

		} // End get_instance ()

	}

}
