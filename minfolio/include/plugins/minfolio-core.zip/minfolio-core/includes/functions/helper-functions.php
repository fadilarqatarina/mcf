<?php 
/* 
 * Helper functions for plugin
 *  
 */


if ( ! function_exists( 'minfolio_get_core_option' ) ) {		

	function minfolio_get_core_option( $key ) {

		return get_theme_mod( $key, minfolio_theme_core_default_options( $key ) );		

	}

}

if ( ! function_exists( 'minfolio_get_post_meta' ) ) {
	
	function minfolio_get_post_meta( $meta_key, $multiple = false, $post_id = null ) {

		if( class_exists( 'RWMB_Core' ) ) {  
			$meta_value  = rwmb_meta( MINFOLIO_META_PREFIX . $meta_key, array( 'multiple' => $multiple ), $post_id );
		}
		else {
			return false;
		}

		return $meta_value;
	} 
}


if ( ! function_exists( 'minfolio_build_inline_style' ) ) {
	
	function minfolio_build_inline_style( $css_properties ) {

		$inline_style = array();

		foreach ( $css_properties as $key => $value ) {

			if ( ! empty( $value ) ) {			
				$inline_style[] = $key . ':' . $value;				
			}
		}

		if ( ! empty( $inline_style ) ) {

			$inline_style = implode( ';', $inline_style );
			return ' style="'. esc_attr( $inline_style ) .';"';

		} else {
			return '';
		}
	}
}

if ( ! function_exists( 'minfolio_get_image_attributes' ) ) {
	
	function minfolio_get_image_attributes( $image_id, $image_caption_src ) {
		
		$attributes = [];	
		
		$attachment = get_post( $image_id );
		
		$image_data = [
			'alt' => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
			'caption' => $attachment->post_excerpt,
			'description' => $attachment->post_content,
			'title' => $attachment->post_title,
		];

		if ( $image_caption_src &&  isset( $image_data[ $image_caption_src ] ) ) {
			$attributes[ 'caption' ] = $image_data[ $image_caption_src ];
		}	

		return $attributes;
	}
}

/* 
 * Return slider revolution sliders list if plugin is active
 *  
 */

if ( ! function_exists( 'minfolio_get_revslider_list' ) ) {
	
	function minfolio_get_revslider_list() {

		if( class_exists( 'RevSlider' ) ) {		

			$slider = new RevSlider();
			$arrSliders = $slider->getArrSliders();

			$revsliders = array();
			if ( $arrSliders ) {
				foreach ( $arrSliders as $slider ) {
					/** @var $slider RevSlider */
					$revsliders[ $slider->getAlias() ] = $slider->getTitle();
				}
			} 
			else {
				$revsliders[ 'NO_SLIDER' ] = esc_html__( 'No sliders found', 'minfolio' );
			}
		}
		else {
			$revsliders[ 'NO_SLIDER' ] = esc_html__( 'Slider Revolution is not active.', 'minfolio' );
		}

		return $revsliders;
	}
}	


if ( ! function_exists( 'minfolio_get_social_icons' ) ) {
	
	function minfolio_get_social_icons() {	

		$social_icons = array(		
			'' 	=> 'None',
			'fab fa-facebook-f' => 'Facebook',
			'fab fa-twitter' => 'Twitter',
			'fab fa-google-plus-g' => 'Google+',
			'fab fa-linkedin-in' => 'Linkedin',
			'fab fa-tumblr' => 'Tumblr',
			'fab fa-dribbble' => 'Dribbble',
			'fab fa-pinterest-p' => 'Pinterest',
			'fab fa-youtube' => 'Youtube',
			'fab fa-vimeo-square' => 'Vimeo',
			'fab fa-flickr' => 'Flickr',
			'fab fa-github' => 'Github',
			'fab fa-instagram'	=> 'Instagram',
			'fab fa-dropbox' => 'Dropbox',										
			'far fa-envelope' => 'Mail',
			'fab fa-skype' => 'Skype',
			'fab fa-behance' => 'Behance',
			'fab fa-soundcloud' => 'Soundcloud',
			'fab fa-stack-overflow' => 'Stackoverflow',
			'fab fa-stack-exchange' => 'Stack-exchange',
			'fab fa-xing' => 'Xing',
			'fab fa-imdb' => 'IMDb',
			'fab fa-medium' => 'Medium',
			'fab fa-weixin' => 'WeChat'
		);

		return $social_icons;

	}

}



/* 
 * Return defualt values of theme options
 *  
 */

if ( ! function_exists( 'minfolio_theme_core_default_options' ) ) {
	
	function minfolio_theme_core_default_options( $key ) {	

		$defaults = array( 

			//General			
			'lazy-load-switch' => 1,														
			'minify-js-switch' => 1,														
			'multilingual-switch' => 0,	
			'google-map-api-key' => '',

			//Blog
			'blog-social-sharing' => 1,		
			'blog-share-icons' => 'fab fa-facebook-f,fab fa-twitter,fab fa-google-plus-g',		

			//Portfolio
			'portfolio-nav-switch' => 1,
			'portfolio-nav-type' => '',
			'portfolio-nav-home' => '',
			'portfolio-related-switch' => 1,
						
			'portfolio-order-by' => 'date',
			'portfolio-order-arrangement' => 'ASC',	
			'portfolio-slug-name' => 'portfolio-item',
			'portfolio-next-text' => esc_html__( 'NEXT', 'minfolio' ),		
			'portfolio-prev-text' => esc_html__( 'PREV', 'minfolio' ),		
			'portfolio-social-sharing' => 1,
			'portfolio-social-share-title' => esc_html__( 'Share', 'minfolio' ),		
			'portfolio-share-icons' => 'fab fa-facebook-f,fab fa-twitter,fab fa-google-plus-g',
						
			'portfolio-archive-banner-bg-color' => '#f9f9f9',		
			
			'portfolio-banner-title-color' => array( 'value' => '#151515' ),    
			'portfolio-banner-desc-color' => array( 'value' => 'rgba(255, 255, 255, 0.5)' ),    

			'portfolio-hero-title-color' => array( 'value' => 'rgba(255,255,255,0.7)' ),    
			'portfolio-hero-desc-color' => array( 'value' => '#ffffff' ),    

			'portfolio-single-title-color' => array( 'value' => '#151515' ),    
			'portfolio-single-subtitle-color' => array( 'value' => '#909090' ),    
			'portfolio-single-desc-color' => array( 'value' => '#606060' ),    

		);	

		if( !empty( $defaults[ $key ] ) ) {
            return $defaults[ $key ];
        }

        return false;
	}
}

if ( ! function_exists( 'build_responsive_padding_control_css' ) ) {

	function build_responsive_padding_control_css( $device, $control_field, $selector ) {

		$padding_css = '';

		$control_value = minfolio_get_core_option( $control_field );	

		if( !empty( $control_value ) ) {

			$control_value = json_decode( $control_value );

			$padding_css  .= $selector  . ' { ';

			$padding_css  .= !empty( $control_value->{ $device . '_top' } )    ? 'padding-top : ' . $control_value->{ $device . '_top' } . 'px;' : '';
			$padding_css  .= !empty( $control_value->{ $device . '_right' } )  ? 'padding-right : ' . $control_value->{ $device . '_right' } . 'px;' : '';
			$padding_css  .= !empty( $control_value->{ $device . '_bottom' } ) ? 'padding-bottom : ' . $control_value->{ $device . '_bottom' } . 'px;' : '';
			$padding_css  .= !empty( $control_value->{ $device . '_left' } )   ? 'padding-left : ' . $control_value->{ $device . '_left' } . 'px;' : '';

			$padding_css  .= ' } ';

		}

		return $padding_css;

	} 

}


if ( ! function_exists( 'build_responsive_typography_control_css' ) ) {

	function build_responsive_typography_control_css( $device, $control_field, $color_control_field, $selector ) {

		$typography_css = '';

		$control_value = minfolio_get_core_option( $control_field );	
		$color_control_value = minfolio_get_core_option( $color_control_field );	
		
        if( !empty( $color_control_value ) && $device == 'desktop' ) {

			$typography_css  .= $selector  . ' { ';      
            $typography_css  .= 'color : ' . $color_control_value[ 'value' ] . ';'; 
			$typography_css  .= ' } ';                   

        }

		if( !empty( $control_value ) ) {

			$control_value = json_decode( $control_value );			                                        

			$typography_css  .= $selector  . ' { ';      

			if( $device == 'desktop' ) {				

				$typography_css  .= !empty( $control_value->{ 'font-family' } )    ? 'font-family : var(--e-global-typography-' . $control_value->{ 'font-family' } . '-font-family);' : '';
				$typography_css  .= !empty( $control_value->{ 'font-weight' } )    ? 'font-weight : ' . $control_value->{ 'font-weight' } . ';' : '';
				$typography_css  .= !empty( $control_value->{ 'text-transform' } ) ? 'text-transform : ' . $control_value->{ 'text-transform' } . ';' : '';
				$typography_css  .= !empty( $control_value->{ 'font-style' } )     ? 'font-style : ' . $control_value->{ 'font-style' } . ';' : '';
				$typography_css  .= !empty( $control_value->{ 'desktop-font-size' } ) ? 'font-size : ' . $control_value->{ 'desktop-font-size' } . 'px;' : '';
				$typography_css  .= !empty( $control_value->{ 'desktop-line-height' } ) ? 'line-height : ' . $control_value->{ 'desktop-line-height' } . 'px;' : '';
				$typography_css  .= !empty( $control_value->{ 'desktop-letter-spacing' } ) ? 'letter-spacing : ' . $control_value->{ 'desktop-letter-spacing' } . 'px;' : '';                                       

			}
			elseif( $device == 'tablet' ) {

				$typography_css  .= !empty( $control_value->{ 'tablet-font-size' } ) ? 'font-size : ' . $control_value->{ 'tablet-font-size' } . 'px;' : '';
				$typography_css  .= !empty( $control_value->{ 'tablet-line-height' } ) ? 'line-height : ' . $control_value->{ 'tablet-line-height' } . 'px;' : '';
				$typography_css  .= !empty( $control_value->{ 'tablet-letter-spacing' } ) ? 'letter-spacing : ' . $control_value->{ 'tablet-letter-spacing' } . 'px;' : '';                    

			}
			elseif( $device == 'mobile' ) {

				$typography_css  .= !empty( $control_value->{ 'mobile-font-size' } ) ? 'font-size : ' . $control_value->{ 'mobile-font-size' } . 'px;' : '';
				$typography_css  .= !empty( $control_value->{ 'mobile-line-height' } ) ? 'line-height : ' . $control_value->{ 'mobile-line-height' } . 'px;' : '';
				$typography_css  .= !empty( $control_value->{ 'mobile-letter-spacing' } ) ? 'letter-spacing : ' . $control_value->{ 'mobile-letter-spacing' } . 'px;' : '';                    

			}

			$typography_css  .= ' } ';

		}		

		return $typography_css;
	
	}

}  


if ( ! function_exists( 'minfolio_post_social_share' ) ) {	

	function minfolio_post_social_share() {
		
			wp_enqueue_script( 'minfolio-social-share' );		
			
			$allow_social_sharing = minfolio_get_core_option( 'blog-social-sharing' );
			$social_sharing_markup = ''; 
			
			$icons = minfolio_get_core_option( 'blog-share-icons' );

		    if ( $allow_social_sharing == 1 ) {
				
				$icons = explode ( ',', $icons ); 

				$social_sharing_markup .= '<div class="socials-share-links">';
				
				$social_sharing_markup .= '<span class="screen-reader-text">' . esc_html__( 'Share this article', 'minfolio' ) . '</span>';
				
				$social_sharing_markup .= '<ul class="post-share" >';			

				foreach ( $icons as $icon ) {										

					$social_sharing_markup .= '<li>';

					$social_sharing_markup .= '<a href="#" data-network="' . esc_attr( $icon ) . '" data-shareurl="' . esc_url( get_the_permalink() ) . '" >';												
					
					$social_sharing_markup .= '<i class="' . esc_attr( $icon ) . '"></i>';						
						
					$social_sharing_markup .= '</a>';

					$social_sharing_markup .= '</li>';
					
				}

				$social_sharing_markup .= '</ul>';

				$social_sharing_markup .= '</div>';

			} 
			
			echo apply_filters( 'minfolio_post_social_share', $social_sharing_markup );
			
	}

	add_action( 'minfolio_action_post_social_share', 'minfolio_post_social_share' );
	
}

if ( ! function_exists( 'get_contact_form_7_posts' ) ) {

	function get_contact_form_7_posts(){
  
		$args = array( 'post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1 );
	
		$cf7_form_list = [];
		
		if( $cf7_forms = get_posts( $args ) ) {

		  	foreach ( $cf7_forms as $form ) {

				$cf7_form_list[ $form->ID ] = $form->post_title;
		  	}
		}
		else {
			$cf7_form_list[ '0' ] = esc_html__( 'No contect From 7 form found', 'void' );
		}

	  	return $cf7_form_list;
	}

}

?>